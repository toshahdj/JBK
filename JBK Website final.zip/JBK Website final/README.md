
  # JBK Website

  This is a code bundle for JBK Website. The original project is available at https://www.figma.com/design/nO256eyUjIBy9HO7qcAi8r/JBK-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  