import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";
const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-c285fd22/health", (c) => {
  return c.json({ status: "ok" });
});

// Email sending endpoint
app.post("/make-server-c285fd22/send-email", async (c) => {
  try {
    const body = await c.req.json();
    const { formType, ...formData } = body;

    const resendApiKey = Deno.env.get("RESEND_API");
    if (!resendApiKey) {
      console.log("Error: RESEND_API not found in environment variables");
      return c.json({ error: "Email service not configured" }, 500);
    }

    // Build email content based on form type
    let subject = "";
    let htmlContent = "";

    if (formType === "contact") {
      subject = `New Contact Form Submission from ${formData.name}`;
      htmlContent = `
        <h2>New Contact Form Submission</h2>
        <p><strong>Name:</strong> ${formData.name}</p>
        <p><strong>Company:</strong> ${formData.company}</p>
        <p><strong>Email:</strong> ${formData.email}</p>
        <p><strong>Phone:</strong> ${formData.phone || "Not provided"}</p>
        <p><strong>Country:</strong> ${formData.country || "Not provided"}</p>
        <p><strong>Inquiry Type:</strong> ${formData.inquiryType}</p>
        <p><strong>Message:</strong></p>
        <p>${formData.message}</p>
      `;
    } else if (formType === "product") {
      subject = `New Product Request from ${formData.name}`;
      htmlContent = `
        <h2>New Product Sourcing Request</h2>
        <p><strong>Name:</strong> ${formData.name}</p>
        <p><strong>Company:</strong> ${formData.company}</p>
        <p><strong>Email:</strong> ${formData.email}</p>
        <p><strong>Phone:</strong> ${formData.phone || "Not provided"}</p>
        <p><strong>Product Description:</strong> ${formData.productDescription}</p>
      `;
    }

    // Send email via Resend API
    const resendResponse = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${resendApiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: "noreply@jbkhokhani.com",
        to: "sahil@jbkhokhani.com",
        subject: subject,
        html: htmlContent,
      }),
    });

    const resendData = await resendResponse.json();

    if (!resendResponse.ok) {
      console.log(`Resend API error: ${JSON.stringify(resendData)}`);
      return c.json({ error: "Failed to send email", details: resendData }, 500);
    }

    console.log(`Email sent successfully: ${JSON.stringify(resendData)}`);
    return c.json({ success: true, messageId: resendData.id });
  } catch (error) {
    console.log(`Error in send-email endpoint: ${error}`);
    return c.json({ error: "Internal server error", message: error.message }, 500);
  }
});

Deno.serve(app.fetch);