# JBK Website — Phase 1 + Phase 2 Changes

Generated 2026-04-23. All changes are ready to review and merge. Run
`npm install` (or `pnpm install`) before building — `node_modules` is
deliberately not included.

---

## Summary by file

### New files

| File | Purpose |
|---|---|
| `src/app/components/HeroCarousel.tsx` | 9-slide scroll-driven hero/carousel with fixed docked-mini on scroll-past |
| `src/app/hooks/useReducedMotion.ts` | Reactive hook for `prefers-reduced-motion` |
| `src/imports/people/jagdishbhai-khokhani.jpg` | Compressed founder photo (110 KB, 1200×1047) |
| `src/imports/people/mahesh-khokhani.jpg` | Compressed partner photo (55 KB, 583×900) |
| `src/imports/people/dinesh-khokhani.jpg` | Compressed partner photo (66 KB, 593×900) |
| `src/imports/people/mehul-khokhani.jpg` | Compressed partner photo (75 KB, 589×900) |

### Modified files

| File | Changes |
|---|---|
| `src/styles/theme.css` | Added `@media (prefers-reduced-motion: reduce)` global suppression block |
| `src/app/components/Navigation.tsx` | Toggle icon centering polished (12px icons, stroke 2.5, `lineHeight:0` + `flexShrink:0` to kill baseline drift); `aria-label`/`aria-pressed` accessibility pass; body-scroll-lock when mobile menu open; route-change auto-close; **mobile hamburger menu rebuilt** as full-screen slide-up overlay with numbered items (01, 02…) and 80 ms stagger per item |
| `src/app/components/FloatingButtons.tsx` | WhatsApp bubble made mode-aware: sage-tinted ring + shadow in light mode, warmer gold-inflected glow in dark mode |
| `src/app/pages/Home.tsx` | Domain → `www.jbkhokhani.com`, `sales@` → `info@` in JSON-LD, dramatic gold-gradient brand mark in hero, **Product Range moved directly below Stats Bar**, hero wrapped with `<HeroCarousel>` scroll-morph |
| `src/app/pages/About.tsx` | Domain replace, **founder photo added** in Our Story (sticky-pinned on desktop, gold-framed figure), founder-name styling differentiated (italic 600 weight), **partner photos installed** in Faces of JBK (replaces initials-on-navy placeholder, preserves fallback), **SRLC key-fact chip row** added below Love & Care copy (3M+ / 10M+ / UN ECOSOC / 13× marathon); 1990s timeline entry softened (no city names) |
| `src/app/pages/Quality.tsx` | Domain replace. **Meta title + description + OG + Twitter all rewritten** — removed WHO-GMP / HPLC / ICP-MS, now reads "USP · BP · EP · IP pharmacopoeia". Body content untouched. |
| `src/app/pages/Services.tsx` | Domain replace; `SamplingIcon` renamed to `DocumentationIcon` (definition + array reference) |
| `src/app/pages/Products.tsx` | Domain replace; `sales@` → `info@` in error copy; **visible manufacturer block removed** from product cards (replaced with explanatory comment — manufacturer data retained in products.json + ProductsIndex hidden page + JSON-LD); search placeholder no longer mentions manufacturer |
| `src/app/pages/ProductsIndex.tsx` | Domain replace; `sales@` → `info@` in mailto + display text |
| `src/app/pages/Contact.tsx` | Domain replace |
| `src/app/pages/Presence.tsx` | Domain replace |
| `src/imports/pasted_text/*.md` | Domain + email replaces in reference docs |

---

## Change-log item mapping

| Item | Status | Where |
|---|---|---|
| Phase 1: 56 domain replaces | ✅ | Every `.tsx` page file + 2 reference `.md` docs |
| Phase 1: 4 `sales@` → `info@` | ✅ | Home.tsx, Products.tsx, ProductsIndex.tsx ×2 |
| Phase 1: Quality meta scrub | ✅ | Quality.tsx lines 11–50 |
| Phase 1: Depot text rewrite | ✅ | About.tsx timeline 1990s |
| Phase 1: SamplingIcon rename | ✅ | Services.tsx |
| Phase 1: Manufacturer strip from cards | ✅ | Products.tsx |
| Phase 1: Dramatic hero brand mark | ✅ | Home.tsx hero |
| Phase 1: `useReducedMotion` + CSS globals | ✅ | hooks/useReducedMotion.ts + theme.css |
| Phase 1: Toggle icon centering | ✅ | Navigation.tsx (desktop + mobile) |
| Phase 1: FloatingButtons mode-aware | ✅ | FloatingButtons.tsx |
| Item 2: 9-slide homepage carousel | ✅ | HeroCarousel.tsx + Home.tsx integration |
| Item 3: Product Range below Stats | ✅ | Home.tsx section order |
| Item 9: Company-vs-founder name styling | ✅ | About.tsx (was already gold-bold vs plain navy; upgraded to gold-700 vs italic-600 for clearer differentiation) |
| Item 12: Timeline entries | ✅ | About.tsx (1990s entry is the only one that needed changing — rest already matched) |
| Item 13: Founder photo | ✅ | About.tsx Our Story (sticky-pinned with caption) |
| Item 14: Partner photos | ✅ | About.tsx Faces of JBK |
| Item 15: Love & Care section | ✅ | Already existed in correct position — enhanced with 4 key-fact chips |
| Item 28: Mobile hamburger animation | ✅ | Navigation.tsx (full-screen slide-up overlay) |
| Item 30: Metallic toggle polish | ✅ | Navigation.tsx |

---

## HeroCarousel — how it works

### Architecture (option a, agreed in chat)

1. **Sticky scroll region** — 220 vh tall `<div>` wrapping everything. Inside it a
   `position: sticky; top: 80px` inner container pinned to viewport below the nav.
2. **Two morphing layers** inside the sticky container, controlled by
   `useScroll` progress (0 → 1 across the 220 vh region):
   - `0.00 → 0.12` — original hero fades out
   - `0.12 → 0.24` — carousel fades in full-screen
   - `0.24 → 0.55` — carousel steady at full-screen; autoplay advancing slides
   - `0.55 → 0.88` — carousel scales down toward a ~55% preview size
3. **Fixed docked mini-carousel** — a separate `position: fixed; top: 80px`
   `<aside>` that mounts when the user has scrolled *past* the bottom of the
   sticky region. Sized at 33vh height (top third of viewport). Persists as
   subsequent sections scroll beneath it. Shares slide state with the full
   carousel — both advance together, dots/arrows work from both.

### Controls

- **Autoplay** — 4 s interval. Paused on hover of either carousel. Disabled
  entirely under `prefers-reduced-motion`.
- **Arrows** — `<` and `>` buttons, 44 px in the full carousel, 32 px in the
  docked. Gold-on-transparent pill with hover scale.
- **Dots** — active dot is a longer gold pill; inactive are small gold-tinted
  circles. `role="tab"` + `aria-selected` for screen readers.
- **Keyboard** — `←` / `→` arrow keys cycle slides; ignored inside form fields.

### Dummy content

All 9 slides use placeholder copy + a single generic `GeometricVisual`
component (seeded SVG with concentric rings, molecular dots, compass diamonds,
and an optional central numeral like "60" or "300+"). No manufacturer names
appear. Ready to be replaced when Darshan supplies final slide copy + imagery.

### Nav-height constant

The sticky `top` offset and the docked-carousel `top` are both `80px` —
matching the desktop nav `md:h-20`. On mobile (nav `h-16 = 64 px`) this leaves
a 16 px gap that reads as intentional breathing space. If you'd like a
perfectly flush layout on mobile, swap the `NAV_TOP_PX` constant at the top of
`HeroCarousel.tsx` for a CSS variable set by Navigation.tsx — I'd recommend
doing that in a dedicated cleanup pass rather than now.

---

## Caveats / known limitations

1. **I could not run `tsc --noEmit` in this environment** — the sandbox
   blocked me from reinstalling `node_modules` after a partial failure.
   All files pass syntactic brace/paren balance checks, all imports resolve
   to deps already in `package.json` (`motion`, `react-router`, `lucide-react`),
   and the edits are mechanical. But if your local `tsc` flags anything,
   send me the message and I'll fix it in the next pass.

2. **HeroCarousel and the docked overlay cover the top 33 vh of viewport
   when active.** Page content (Stats Bar etc.) scrolls beneath it — this
   matches the spec ("bottom 2/3 shows page content scrolling normally").
   I did NOT add `padding-top: 33vh` to subsequent sections, because that
   would cause a visible content jump at the exact moment the user crosses
   the boundary. If you'd prefer subsequent content to be pushed fully below
   the docked bar (no overlap), that's a one-line change — tell me and I'll
   apply it.

3. **Love & Care image is still a placeholder** — a warm gradient card with
   the SRLC name. The change log says "Add a relevant image from
   https://loveandcare.srmd.org/". I did not auto-download an image to avoid
   copyright concerns. Once you pick one (or ask SRLC for approved usage),
   swap the placeholder `<div>` for an `<img>`.

4. **Photos are JPEG, not WebP.** Compressed from 4–5 MB PNGs to 55–110 KB
   JPEGs at quality 85, long-side 900–1200 px. If you want WebP for ~30%
   further reduction, I can regenerate in a follow-up.

5. **`node_modules` not shipped.** Run `npm install` (or `pnpm install`)
   before `npm run build`.

---

## Files NOT touched (per hard constraint)

- `src/app/data/products.json` — 219 product entries preserved verbatim
- `supabase/functions/server/**` — edge function left alone
- `utils/supabase/info.tsx` — projectId + publicAnonKey unchanged
