/** Ambient declarations for Vite asset imports. */

declare module "*.png" {
  const src: string;
  export default src;
}
declare module "*.jpg" {
  const src: string;
  export default src;
}
declare module "*.jpeg" {
  const src: string;
  export default src;
}
declare module "*.svg" {
  const src: string;
  export default src;
}
declare module "*.webp" {
  const src: string;
  export default src;
}
declare module "*.gif" {
  const src: string;
  export default src;
}
declare module "*.css";

/**
 * react-dom/client's `exports` field in package.json sometimes isn't
 * resolved correctly by standalone tsc. Re-declare the minimal API
 * surface we actually use (createRoot). Runtime resolution is unchanged.
 */
declare module "react-dom/client" {
  import type { ReactNode } from "react";
  export interface Root {
    render(children: ReactNode): void;
    unmount(): void;
  }
  export function createRoot(
    container: Element | DocumentFragment,
    options?: unknown
  ): Root;
}
