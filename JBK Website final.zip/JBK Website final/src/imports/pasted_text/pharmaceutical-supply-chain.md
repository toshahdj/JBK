
NAV STRUCTURE
Home | About & Quality | Products | Services & Global Reach | Contact
[Light/Dark toggle icon — top right of nav]


PAGE 1: HOME

HERO SECTION
Headline: Your Trusted Partner in Pharmaceutical Supply
Subheadline: Over 60 years of connecting the world's pharmaceutical industry with quality APIs, ingredients, and sourcing solutions — from India and beyond.
Primary CTA: Explore Our Products → /products
Secondary CTA: Get in Touch → /contact

STATS BAR (count-up animation on scroll)
60+ | Years in Business
150+ | Products
300+ | Client Companies

WHAT WE DO — 3 COLUMNS
[Icon] API Trading & Distribution
We supply Active Pharmaceutical Ingredients, bulk drug intermediates, nutraceuticals, and veterinary drugs — sourced from trusted manufacturers across India, China, Europe, and the USA.

[Icon] Global Sourcing & Indenting
We act as your sourcing office in India. Whether you're an international buyer or a domestic formulator, we connect you to the right supply at the right price.

[Icon] Regulatory & Documentation Support
From DMF filings to GMP-compliant documentation, we help you navigate the paperwork so your supply chain stays compliant and audit-ready.

WHY JBK — TRUST SECTION
Pull quote: "We don't just supply ingredients — we build supply chains."

Established 1965, Mumbai
Serving 300+ pharma companies across India and 15+ countries
GMP-compliant sourcing with multi-stage quality checks
Group turnover: $50+ million
Depots in Bhiwandi, Baddi, and Haridwar

PRODUCT CATEGORIES PREVIEW — 6 CLICKABLE TILES
Antibiotics & Anti-infectives
Analgesics & NSAIDs
Cardiovascular & Metabolic
Nutraceuticals & Vitamins
Veterinary APIs
Plant Extracts
CTA below tiles: View Full Product List →

INQUIRY CTA BANNER
Heading: Can't find what you're looking for?
Body: We source beyond our listed products. Tell us what you need.
Button: Submit a Sourcing Request → /contact?type=sourcing


PAGE 2: ABOUT & QUALITY

SECTION 1 — OUR STORY
J. B. Khokhani & Co. was founded in 1965 by J. B. Khokhani in Mumbai, with a simple but powerful idea: be the most reliable link between pharmaceutical manufacturers and the companies that need their products.

Six decades later, that idea has grown into one of India's leading pharmaceutical trading and distribution firms — serving 300+ clients across India and exporting to markets across Africa, the Middle East, Southeast Asia, and Europe.

Today, JBK is managed by the second generation of the Khokhani family — Mahesh, Mehul, and Dinesh J. Khokhani — who have expanded the company's reach while staying true to its founding values: reliability, quality, and long-term relationships.

We are not a pure trader. We are not a manufacturer. We are a pharmaceutical supply chain integrator — combining deep supplier networks, regulatory expertise, and multi-market access to deliver end-to-end sourcing solutions.

SECTION 2 — OUR APPROACH — 3 COLUMNS
One-Stop Sourcing
Whether you need a single API or a full product basket, we consolidate supply from multiple manufacturers so you don't have to manage multiple vendors.

Relationship-First
We've built 60 years of trust with manufacturers and clients alike. That network is your advantage.

Regulatory Readiness
We understand what regulated markets require. Our documentation support — DMFs, NDA filings, GMP certificates — means your supply is always audit-ready.

SECTION 3 — QUALITY & COMPLIANCE
Intro: At JBK, quality is not a checkbox — it's built into every step of how we work.

Our Quality Framework:
GMP-compliant sourcing from verified manufacturers
Multi-stage quality checks from raw material to final delivery
Microbiological and chemical testing support
Heavy metal testing (Lead, Arsenic, Cadmium, Mercury) via ICP-MS
Stability testing and shelf-life documentation

Documentation We Support:
Drug Master Files (DMFs)
NDA filings
Certificate of Analysis (CoA)
GMP compliance certificates

Standards We Work To:
USP / BP / EP pharmacopeial standards
WHO-GMP aligned manufacturing partners
HPLC, ICP-MS, and other validated test methods

Pull quote: "We supply regulatory-grade material to markets that demand it — and we have the paperwork to prove it."

SECTION 4 — THE PEOPLE BEHIND JBK

OUR INSPIRATION
Section label: Our Inspiration

At J. B. Khokhani & Co., business is not just about transactions — it is about how we conduct ourselves in every one of them.

Our work is guided by the teachings of Pujya Gurudevshri Rakeshji, an enlightened spiritual master, visionary, and the founder of Shrimad Rajchandra Mission Dharampur (https://www.srmd.org) — a global spiritual organisation with over 206 centres across six continents.

Pujya Gurudevshri's teachings centre on inner transformation, integrity, compassion, and selfless service. He teaches that true progress — in life and in work — comes not from what we achieve, but from how we achieve it.

These principles are not separate from how we do business. They are the foundation of it.

Pull quote: "The way you conduct yourself in every interaction is a reflection of your inner values."

At JBK, this translates into the way we treat our clients, our suppliers, and our partners — with honesty, accountability, and a genuine commitment to their success.

THE FACES OF J. B. KHOKHANI & CO.
Section label: The Faces of J. B. Khokhani & Co.
Subtext: Six decades of trust, built by people who care.

[Photo card grid — photos to be uploaded in Figma]

PARTNERS
Mahesh J. Khokhani — Partner
Mehul J. Khokhani — Partner
Dinesh J. Khokhani — Partner

DOMESTIC SALES
Kunal Doshi — Domestic Sales
Bhavin Vaidya — Domestic Sales
Manan Jogani — Domestic Sales
Sharan Desai — Domestic Sales

EXPORTS
Sahil Shah — Exports
Neha Sharma — Exports
Bhavna Kadam — Exports

OPERATIONS
Bhavin Mehta — Operations
Riya Durve — Operations
Darshan Shah — Operations


PAGE 3: PRODUCTS

PAGE INTRO
Heading: Our Products
Subtext: 150+ pharmaceutical ingredients across APIs, nutraceuticals, and veterinary drugs — sourced from India's leading manufacturers and global suppliers.

SEARCH BAR (live, filters JSON data in real time)
Placeholder: Search by product name, category, or manufacturer...

CATEGORY FILTER TABS
All | APIs (Export) | APIs (Domestic) | Manufacturing | Veterinary | Nutraceuticals

PRODUCT CARDS (rendered from products.json — see Section C)
Each card displays:
Product Name (bold, Playfair Display)
Manufacturer (if applicable, DM Sans smaller text)
Category badge (colour-coded pill, DM Mono or DM Sans uppercase)

BADGE COLOURS BY CATEGORY:
APIs (Export): Navy #0A1628 background, white text
APIs (Domestic): Teal #0D7377 background, white text
Manufacturing: Purple #5C4B8A background, white text
Veterinary: Sage Green #6B8F71 background, white text
Nutraceuticals: Gold #C9A84C background, navy text

CUSTOM SOURCING FORM (bottom of page)
Heading: Can't find what you need?
Subtext: We source beyond our listed products. If you're looking for a specific API, intermediate, or ingredient not listed here, tell us — we'll find it.

Form fields:
Name *
Company Name *
Email Address *
Phone Number
Country
Inquiry Type (dropdown): Product Inquiry / Custom Sourcing Request / Partnership / General
Product Name or Description *
Message
[Send Request] button (Terracotta #C4714A background, white text)

Note below form: We typically respond within 24–48 hours.


PAGE 4: SERVICES & GLOBAL REACH

SECTION 1 — WHAT WE DO — 5 SERVICE BLOCKS

Trading & Distribution
We maintain active supply relationships with India's leading API manufacturers and distribute across domestic and international markets. Our network means faster sourcing, better pricing, and reliable availability.

Indenting & Global Sourcing
We act as a sourcing office for international buyers looking to procure from India. We identify the right manufacturer, negotiate pricing, manage documentation, and coordinate logistics — so you don't have to.

Import & Export
We handle both directions. Importing APIs and ingredients from China, Europe, and the USA for Indian formulators. Exporting Indian-manufactured APIs to regulated and semi-regulated markets worldwide.

Contract Manufacturing Coordination
Need finished formulations? We coordinate with WHO-GMP aligned manufacturing partners for tablets, capsules, and other dosage forms — including Tramadol, Diclofenac combinations, and multivitamins.

Regulatory & Documentation Support
We assist with Drug Master Files (DMFs), NDA filing documentation, Certificate of Analysis (CoA), GMP compliance certificates, and quality control lab coordination (chemical + microbiological).

SECTION 2 — GLOBAL REACH

Where We Export To:
Africa — Multiple markets
Middle East — UAE, Iran, Iraq, Syria
Southeast Asia — Vietnam, Philippines, Thailand, Singapore, Indonesia
Europe — Multiple markets
South Asia — India, Pakistan
Others — Israel and more

Where We Source From:
India — Primary manufacturing base
China — APIs and nutraceutical ingredients
Europe — Specialty ingredients and branded products
USA — Regulated-market grade materials

SECTION 3 — OUR INFRASTRUCTURE

Headquarters: B-207, Neelam Centre, Worli, Mumbai — 400030
Depot: Bhiwandi, Maharashtra
Depot: Baddi, Himachal Pradesh
Depot: Haridwar, Uttarakhand

Body: This multi-location presence ensures faster delivery across India and efficient export logistics.


PAGE 5: CONTACT

INTRO
Heading: Let's Talk
Subtext: Whether you're looking to source a product, explore a partnership, or just have a question — we'd love to hear from you.

CONTACT FORM
Name *
Company Name *
Email Address *
Phone Number
Country
Inquiry Type (dropdown): Product Inquiry / Custom Sourcing Request / Partnership / General
Message *
[Send Message] button (Terracotta #C4714A background, white text)

DIRECT CONTACT DETAILS
Address: B-207, Neelam Centre, Hind Cycle Road, Behind Doordarshan Tower, Worli, Mumbai — 400030
Phone: 022-40441234
Email: info@jbkhokhani.com | info@jbkhokhani.com
Website: www.jbkhokhani.com


FOOTER (all pages)
J. B. Khokhani & Co. | Est. 1965 | Mumbai, India
Links: Home | About & Quality | Products | Services & Global Reach | Contact
© 2025 J. B. Khokhani & Co. All rights reserved.
Disclaimer: API/Substances covered by patent are not offered to countries where patent law is in force. Final responsibility lies with the customer.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SECTION C — PRODUCTS.JSON STRUCTURE & DATA
(Save this as products.json in your project root)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

HOW TO USE:
Save the JSON below as products.json in your project.
In your Products page JavaScript, fetch it with:
fetch('./products.json').then(r => r.json()).then(data => renderProducts(data));
The search bar filters across "name", "manufacturer", and "category" fields.
The tab filters match the "category" field exactly.

CATEGORY VALUES (use these exactly in the JSON):
"APIs (Export)"
"APIs (Domestic)"
"Manufacturing"
"Veterinary"
"Nutraceuticals"


PRODUCTS.JSON:

[
{ "name": "Amoxycillin Trihydrate", "manufacturer": "Syschem (India) Ltd.", "category": "APIs (Export)" },
{ "name": "Ampicillin Trihydrate", "manufacturer": "Syschem (India) Ltd.", "category": "APIs (Export)" },
{ "name": "Cefadroxil", "manufacturer": "Syschem (India) Ltd.", "category": "APIs (Export)" },
{ "name": "Cephalexin", "manufacturer": "Syschem (India) Ltd.", "category": "APIs (Export)" },
{ "name": "Cloxacillin Sodium", "manufacturer": "Syschem (India) Ltd.", "category": "APIs (Export)" },
{ "name": "Dicloxacillin Sodium", "manufacturer": "Syschem (India) Ltd.", "category": "APIs (Export)" },
{ "name": "Flucloxacillin Sodium", "manufacturer": "Syschem (India) Ltd.", "category": "APIs (Export)" },
{ "name": "Paracetamol", "manufacturer": "Farmson Basic Drugs", "category": "APIs (Export)" },
{ "name": "Cinacalcet", "manufacturer": "Solara Active Pharma Sciences", "category": "APIs (Export)" },
{ "name": "Citicoline", "manufacturer": "Solara Active Pharma Sciences", "category": "APIs (Export)" },
{ "name": "Cycloserine", "manufacturer": "Solara Active Pharma Sciences", "category": "APIs (Export)" },
{ "name": "Gabapentin", "manufacturer": "Solara Active Pharma Sciences", "category": "APIs (Export)" },
{ "name": "Ibuprofen", "manufacturer": "Solara Active Pharma Sciences", "category": "APIs (Export)" },
{ "name": "Mirabegron", "manufacturer": "Solara Active Pharma Sciences", "category": "APIs (Export)" },
{ "name": "Mycophenolate", "manufacturer": "Solara Active Pharma Sciences", "category": "APIs (Export)" },
{ "name": "Oseltamivir", "manufacturer": "Solara Active Pharma Sciences", "category": "APIs (Export)" },
{ "name": "Sevelamer", "manufacturer": "Solara Active Pharma Sciences", "category": "APIs (Export)" },
{ "name": "Succinylcholine Chloride", "manufacturer": "Solara Active Pharma Sciences", "category": "APIs (Export)" },
{ "name": "Cefdinir", "manufacturer": "Covalent Laboratories", "category": "APIs (Export)" },
{ "name": "Cefditoren Pivoxil", "manufacturer": "Covalent Laboratories", "category": "APIs (Export)" },
{ "name": "Cefixime", "manufacturer": "Covalent Laboratories", "category": "APIs (Export)" },
{ "name": "Cefotaxime", "manufacturer": "Covalent Laboratories", "category": "APIs (Export)" },
{ "name": "Cefpodoxime", "manufacturer": "Covalent Laboratories", "category": "APIs (Export)" },
{ "name": "Cefprozil", "manufacturer": "Covalent Laboratories", "category": "APIs (Export)" },
{ "name": "Ceftibuten", "manufacturer": "Covalent Laboratories", "category": "APIs (Export)" },
{ "name": "Ceftriaxone", "manufacturer": "Covalent Laboratories", "category": "APIs (Export)" },
{ "name": "Cefuroxime Axetil", "manufacturer": "Covalent Laboratories", "category": "APIs (Export)" },
{ "name": "Cefuroxime Sodium", "manufacturer": "Covalent Laboratories", "category": "APIs (Export)" },
{ "name": "Sulfapyridine", "manufacturer": "Virchow Laboratories", "category": "APIs (Export)" },
{ "name": "Sulfasalazine", "manufacturer": "Virchow Laboratories", "category": "APIs (Export)" },
{ "name": "Sulphamethoxazole", "manufacturer": "Virchow Laboratories", "category": "APIs (Export)" },
{ "name": "Trimethoprim", "manufacturer": "Virchow Laboratories", "category": "APIs (Export)" },
{ "name": "Itraconazole", "manufacturer": "Andhra Organics", "category": "APIs (Export)" },
{ "name": "Olmesartan", "manufacturer": "Andhra Organics", "category": "APIs (Export)" },
{ "name": "Sildenafil Citrate", "manufacturer": "Andhra Organics", "category": "APIs (Export)" },
{ "name": "Sulfadiazine", "manufacturer": "Andhra Organics", "category": "APIs (Export)" },
{ "name": "Telmisartan", "manufacturer": "Andhra Organics", "category": "APIs (Export)" },
{ "name": "Gabapentin", "manufacturer": "Saraca Laboratories", "category": "APIs (Export)" },
{ "name": "Pantoprazole Sodium", "manufacturer": "Saraca Laboratories", "category": "APIs (Export)" },
{ "name": "Pregabalin", "manufacturer": "Saraca Laboratories", "category": "APIs (Export)" },
{ "name": "Ranitidine", "manufacturer": "Saraca Laboratories", "category": "APIs (Export)" },
{ "name": "Acotiamide", "manufacturer": "Emnar Pharma", "category": "APIs (Export)" },
{ "name": "Bupropion", "manufacturer": "Emnar Pharma", "category": "APIs (Export)" },
{ "name": "Dapagliflozin", "manufacturer": "Emnar Pharma", "category": "APIs (Export)" },
{ "name": "Empagliflozin", "manufacturer": "Emnar Pharma", "category": "APIs (Export)" },
{ "name": "Lacosamide", "manufacturer": "Emnar Pharma", "category": "APIs (Export)" },
{ "name": "Levetiracetam", "manufacturer": "Emnar Pharma", "category": "APIs (Export)" },
{ "name": "Pitolisant", "manufacturer": "Emnar Pharma", "category": "APIs (Export)" },
{ "name": "Tapentadol", "manufacturer": "Emnar Pharma", "category": "APIs (Export)" },
{ "name": "Tramadol HCl", "manufacturer": "Emnar Pharma", "category": "APIs (Export)" },
{ "name": "Allopurinol", "manufacturer": "Indoco Remedies", "category": "APIs (Export)" },
{ "name": "Dicyclomine HCl", "manufacturer": "Indoco Remedies", "category": "APIs (Export)" },
{ "name": "Gliclazide", "manufacturer": "Indoco Remedies", "category": "APIs (Export)" },
{ "name": "Cefazolin", "manufacturer": "Indoco Remedies", "category": "APIs (Export)" },
{ "name": "Cefepime + L-Arginine", "manufacturer": "Indoco Remedies", "category": "APIs (Export)" },
{ "name": "Ceftriaxone Sodium Sterile", "manufacturer": "Indoco Remedies", "category": "APIs (Export)" },
{ "name": "Tazobactam + Piperacillin", "manufacturer": "Indoco Remedies", "category": "APIs (Export)" },
{ "name": "Cefalothin", "manufacturer": "Ceph Lifesciences", "category": "APIs (Export)" },
{ "name": "Cefazolin", "manufacturer": "Ceph Lifesciences", "category": "APIs (Export)" },
{ "name": "Cefepime + L-Arginine", "manufacturer": "Ceph Lifesciences", "category": "APIs (Export)" },
{ "name": "Ceftriaxone Sodium Sterile", "manufacturer": "Ceph Lifesciences", "category": "APIs (Export)" },
{ "name": "Tazobactam + Piperacillin", "manufacturer": "Ceph Lifesciences", "category": "APIs (Export)" },
{ "name": "Glycopyrrolate", "manufacturer": "Alkaloids Pvt. Ltd.", "category": "APIs (Export)" },
{ "name": "Hyoscine Butylbromide", "manufacturer": "Alkaloids Pvt. Ltd.", "category": "APIs (Export)" },
{ "name": "Tiotropium Bromide Monohydrate", "manufacturer": "Alkaloids Pvt. Ltd.", "category": "APIs (Export)" },
{ "name": "Atorvastatin Calcium", "manufacturer": "Arch Pharmalabs", "category": "APIs (Export)" },
{ "name": "Meloxicam", "manufacturer": "Arch Pharmalabs", "category": "APIs (Export)" },
{ "name": "Nabumetone", "manufacturer": "Arch Pharmalabs", "category": "APIs (Export)" },
{ "name": "Nitrofurantoin", "manufacturer": "Arch Pharmalabs", "category": "APIs (Export)" },
{ "name": "Piroxicam", "manufacturer": "Arch Pharmalabs", "category": "APIs (Export)" },
{ "name": "Caffeine Anhydrous", "manufacturer": "Deft Chemicals", "category": "APIs (Export)" },
{ "name": "Calcium Citrate", "manufacturer": "Oceanic Laboratories", "category": "APIs (Export)" },
{ "name": "Citric Acid", "manufacturer": "Oceanic Laboratories", "category": "APIs (Export)" },
{ "name": "Iodine", "manufacturer": "Oceanic Laboratories", "category": "APIs (Export)" },
{ "name": "Magnesium Citrate", "manufacturer": "Oceanic Laboratories", "category": "APIs (Export)" },
{ "name": "Potassium Citrate", "manufacturer": "Oceanic Laboratories", "category": "APIs (Export)" },
{ "name": "Sodium Citrate", "manufacturer": "Oceanic Laboratories", "category": "APIs (Export)" },
{ "name": "Carbamazepine", "manufacturer": "Adani Pharmachem", "category": "APIs (Export)" },
{ "name": "Chromium Picolinate", "manufacturer": "Adani Pharmachem", "category": "APIs (Export)" },
{ "name": "Gliclazide", "manufacturer": "Adani Pharmachem", "category": "APIs (Export)" },
{ "name": "Glipizide", "manufacturer": "Adani Pharmachem", "category": "APIs (Export)" },
{ "name": "Kojic Acid Dipalmitate", "manufacturer": "Adani Pharmachem", "category": "APIs (Export)" },
{ "name": "Mesalamine", "manufacturer": "Adani Pharmachem", "category": "APIs (Export)" },
{ "name": "Povidone Iodine", "manufacturer": "Adani Pharmachem", "category": "APIs (Export)" },
{ "name": "Warfarin Sodium", "manufacturer": "Adani Pharmachem", "category": "APIs (Export)" },
{ "name": "Zinc Picolinate", "manufacturer": "Adani Pharmachem", "category": "APIs (Export)" },
{ "name": "Aceclofenac", "manufacturer": "", "category": "APIs (Export)" },
{ "name": "Amlodipine", "manufacturer": "", "category": "APIs (Export)" },
{ "name": "Azithromycin", "manufacturer": "", "category": "APIs (Export)" },
{ "name": "Colchicine", "manufacturer": "", "category": "APIs (Export)" },
{ "name": "Diclofenac", "manufacturer": "", "category": "APIs (Export)" },
{ "name": "Doxycycline", "manufacturer": "", "category": "APIs (Export)" },
{ "name": "Folic Acid", "manufacturer": "", "category": "APIs (Export)" },
{ "name": "Metformin", "manufacturer": "", "category": "APIs (Export)" },
{ "name": "Metronidazole", "manufacturer": "", "category": "APIs (Export)" },
{ "name": "Norfloxacin", "manufacturer": "", "category": "APIs (Export)" },
{ "name": "Sertraline", "manufacturer": "", "category": "APIs (Export)" },
{ "name": "Tramadol", "manufacturer": "", "category": "APIs (Export)" },
{ "name": "Aceclofenac", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Allopurinol", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Ambroxol HCl", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Artemether", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Atorvastatin Calcium", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Bromhexine HCl", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Caffeine Anhydrous", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Calcium Citrate", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Carbamazepine", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Carvedilol", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Cefixime", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Cefotaxime Sodium Sterile", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Cefpodoxime Proxetil", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Ceftriaxone Sodium Sterile", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Cefuroxime Axetil DC", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Cefuroxime Sodium Sterile", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Celecoxib", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Chlorzoxazone", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Chromium Picolinate", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Ciprofloxacin HCl", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Clioquinol", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Clotrimazole", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Diclofenac Potassium", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Diclofenac Sodium", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Dicyclomine HCl", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Erythromycin Phosphate", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Erythromycin Estolate", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Erythromycin Ethyl Succinate", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Erythromycin Stearate", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Etophylline", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Ferrous Fumarate", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Fexofenadine HCl", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Folic Acid", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Gabapentin", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Gliclazide", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Glimepiride", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Hyoscine Butylbromide", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Ibuprofen", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Isosorbide Dinitrate", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Itraconazole", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Lacosamide", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Levetiracetam", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Levofloxacin", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Lumefantrine", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Magnesium Citrate", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Mefenamic Acid", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Meropenem", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Mesalamine", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Metformin", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Metronidazole", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Nimesulide", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Norepinephrine Bitartrate", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Norfloxacin", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Nystatin", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Ofloxacin", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Ondansetron", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Ornidazole", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Pantoprazole Sodium", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Paracetamol", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Potassium Citrate", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Povidone Iodine", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Pregabalin", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Ranitidine", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Rivaroxaban", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Rivastigmine", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Sertraline", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Sildenafil Citrate", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Sodium Bicarbonate", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Sodium Citrate", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Sodium Iodide", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Sodium Valproate", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Sulfadiazine", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Sulfamethoxazole", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Telmisartan", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Theophylline", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Tolnaftate", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Tramadol HCl", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Trimethoprim", "manufacturer": "", "category": "APIs (Domestic)" },
{ "name": "Amoxycillin Trihydrate", "manufacturer": "Syschem (India) Ltd.", "category": "Manufacturing" },
{ "name": "Ampicillin Trihydrate", "manufacturer": "Syschem (India) Ltd.", "category": "Manufacturing" },
{ "name": "Cefadroxil", "manufacturer": "Syschem (India) Ltd.", "category": "Manufacturing" },
{ "name": "Cephalexin Monohydrate", "manufacturer": "Syschem (India) Ltd.", "category": "Manufacturing" },
{ "name": "Cloxacillin Sodium", "manufacturer": "Syschem (India) Ltd.", "category": "Manufacturing" },
{ "name": "Dicloxacillin Sodium", "manufacturer": "Syschem (India) Ltd.", "category": "Manufacturing" },
{ "name": "Flucloxacillin Sodium", "manufacturer": "Syschem (India) Ltd.", "category": "Manufacturing" },
{ "name": "Albendazole", "manufacturer": "", "category": "Veterinary" },
{ "name": "Amoxicillin Trihydrate", "manufacturer": "", "category": "Veterinary" },
{ "name": "Ampicillin Trihydrate", "manufacturer": "", "category": "Veterinary" },
{ "name": "Buparvaquone", "manufacturer": "", "category": "Veterinary" },
{ "name": "Butaphosphan", "manufacturer": "", "category": "Veterinary" },
{ "name": "Ciprofloxacin", "manufacturer": "", "category": "Veterinary" },
{ "name": "Clorsulon", "manufacturer": "", "category": "Veterinary" },
{ "name": "Closantel Amine", "manufacturer": "", "category": "Veterinary" },
{ "name": "Closantel Base", "manufacturer": "", "category": "Veterinary" },
{ "name": "Closantel Sodium", "manufacturer": "", "category": "Veterinary" },
{ "name": "Closantel Sodium Dihydrate", "manufacturer": "", "category": "Veterinary" },
{ "name": "Diminazene Aceturate", "manufacturer": "", "category": "Veterinary" },
{ "name": "Enrofloxacin", "manufacturer": "", "category": "Veterinary" },
{ "name": "Fenbendazole", "manufacturer": "", "category": "Veterinary" },
{ "name": "Halquinol", "manufacturer": "", "category": "Veterinary" },
{ "name": "Niclosamide", "manufacturer": "", "category": "Veterinary" },
{ "name": "Niclosamide Piperazine Salt", "manufacturer": "", "category": "Veterinary" },
{ "name": "Nitroxynil", "manufacturer": "", "category": "Veterinary" },
{ "name": "Oxfendazole", "manufacturer": "", "category": "Veterinary" },
{ "name": "Oxyclozanide", "manufacturer": "", "category": "Veterinary" },
{ "name": "Phenylbutazone", "manufacturer": "", "category": "Veterinary" },
{ "name": "Piperazine Citrate", "manufacturer": "", "category": "Veterinary" },
{ "name": "Praziquantel", "manufacturer": "", "category": "Veterinary" },
{ "name": "Rafoxanide", "manufacturer": "", "category": "Veterinary" },
{ "name": "Ricobendazole", "manufacturer": "", "category": "Veterinary" },
{ "name": "Triclabendazole", "manufacturer": "", "category": "Veterinary" },
{ "name": "Vegan Vitamin D3 Oil (1,000,000 IU)", "manufacturer": "China origin", "category": "Nutraceuticals" },
{ "name": "MenaquinGold (Natural Vitamin K2-7)", "manufacturer": "Novozymes, Denmark", "category": "Nutraceuticals" },
{ "name": "Alpha Lipoic Acid", "manufacturer": "", "category": "Nutraceuticals" },
{ "name": "Methylcobalamin", "manufacturer": "", "category": "Nutraceuticals" }
]
