Implement complete SEO for the entire website. This is the highest priority prompt. Execute every part precisely.

══════════════════════════════
PART 1: VERIFY PAGE TITLES & META DESCRIPTIONS
══════════════════════════════
These are already set but confirm they are correct on every page:

/ (Home): 
  title: JBK — Pharmaceutical API Supplier Since 1965 | J. B. Khokhani & Co.
  description: J. B. Khokhani & Co. is a trusted pharmaceutical API supplier with 60+ years of experience. Supplying 150+ APIs and intermediates to 300+ clients across 60+ countries. USP, BP, EP, WHO-GMP certified.

/about:
  title: About JBK | 60 Years of Pharmaceutical Excellence | J. B. Khokhani & Co.
  description: Founded in 1965, J. B. Khokhani & Co. has built six decades of expertise in pharmaceutical API sourcing, quality assurance, and global distribution. Learn our story.

/products:
  title: Pharmaceutical APIs & Intermediates | Product Catalogue | J. B. Khokhani & Co.
  description: Browse 150+ pharmaceutical APIs and intermediates across antibiotics, cardiovascular, oncology, respiratory, CNS, and more. USP/BP/EP grade. Request samples and quotes.

/services:
  title: Pharmaceutical Sourcing & Supply Services | J. B. Khokhani & Co.
  description: End-to-end pharmaceutical API sourcing, quality testing, regulatory documentation, and global logistics. Trusted by 300+ clients worldwide since 1965.

/presence:
  title: Global Presence | API Exports to 60+ Countries | J. B. Khokhani & Co.
  description: J. B. Khokhani & Co. exports pharmaceutical APIs to clients across Europe, the Americas, Southeast Asia, the Middle East, and Africa. Sourcing from India, China, and Europe.

/quality:
  title: Quality Assurance | USP · BP · EP · WHO-GMP Certified | J. B. Khokhani & Co.
  description: JBK maintains rigorous quality standards with USP, BP, EP, and WHO-GMP certifications. HPLC and ICP-MS testing. CoA, MSDS, and full regulatory documentation available.

/contact:
  title: Contact JBK | Request a Quote or Sample | J. B. Khokhani & Co.
  description: Get in touch with J. B. Khokhani & Co. for pharmaceutical API enquiries, sample requests, pricing, and regulatory documentation. Based in Mumbai, India.

══════════════════════════════
PART 2: ADD TO EVERY PAGE <head>
══════════════════════════════
Add these tags to the <head> of every single page:

<html lang="en"> — set this attribute on the root html element

<meta name="robots" content="index, follow">
<meta name="author" content="J. B. Khokhani & Co.">
<meta name="geo.region" content="IN-MH">
<meta name="geo.placename" content="Mumbai">
<meta name="geo.position" content="19.0176;72.8562">
<meta name="ICBM" content="19.0176, 72.8562">

Canonical tag — unique per page:
/ → <link rel="canonical" href="https://www.jbkhokhani.com/">
/about → <link rel="canonical" href="https://www.jbkhokhani.com/about">
/products → <link rel="canonical" href="https://www.jbkhokhani.com/products">
/services → <link rel="canonical" href="https://www.jbkhokhani.com/services">
/presence → <link rel="canonical" href="https://www.jbkhokhani.com/presence">
/quality → <link rel="canonical" href="https://www.jbkhokhani.com/quality">
/contact → <link rel="canonical" href="https://www.jbkhokhani.com/contact">

Open Graph tags — unique per page (og:title and og:description match the page title/description above):
<meta property="og:type" content="website">
<meta property="og:site_name" content="J. B. Khokhani & Co.">
<meta property="og:image" content="[use the gold horizontal logo URL already in the project]">
<meta property="og:url" content="[the canonical URL for that page]">
<meta property="og:title" content="[same as page title]">
<meta property="og:description" content="[same as meta description]">

Twitter card tags (same on every page):
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="[same as page title]">
<meta name="twitter:description" content="[same as meta description]">
<meta name="twitter:image" content="[same logo URL as og:image]">

══════════════════════════════
PART 3: SCHEMA MARKUP — HOME PAGE
══════════════════════════════
Add this JSON-LD block to the <head> of the home page (/ only):

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "J. B. Khokhani & Co.",
  "alternateName": "JBK",
  "url": "https://www.jbkhokhani.com",
  "logo": "[gold horizontal logo URL from the project]",
  "foundingDate": "1965",
  "description": "Pharmaceutical API supplier and distributor with 60+ years of experience. Supplying 150+ APIs and intermediates to 300+ clients across 60+ countries.",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "B-207, Neelam Centre, Hind Cycle Road, Behind Doordarshan Tower, Worli",
    "addressLocality": "Mumbai",
    "postalCode": "400030",
    "addressCountry": "IN"
  },
  "contactPoint": [
    {
      "@type": "ContactPoint",
      "telephone": "+91-22-40441234",
      "contactType": "customer service",
      "availableLanguage": ["English", "Hindi"]
    },
    {
      "@type": "ContactPoint",
      "email": "info@jbkhokhani.com",
      "contactType": "sales"
    }
  ],
  "foundingLocation": {
    "@type": "Place",
    "name": "Mumbai, India"
  }
}
</script>

══════════════════════════════
PART 4: SCHEMA MARKUP — PRODUCTS PAGE
══════════════════════════════
Add this JSON-LD block to the <head> of /products:

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "ItemList",
  "name": "Pharmaceutical APIs and Intermediates — J. B. Khokhani & Co.",
  "description": "Complete catalogue of 162 pharmaceutical APIs and intermediates supplied by J. B. Khokhani & Co. across 6 therapeutic categories.",
  "numberOfItems": 162,
  "itemListElement": [
    {"@type": "ListItem", "position": 1, "name": "Antibiotics & Anti-Infectives APIs"},
    {"@type": "ListItem", "position": 2, "name": "Analgesics & NSAIDs APIs"},
    {"@type": "ListItem", "position": 3, "name": "Cardiovascular & Metabolic APIs"},
    {"@type": "ListItem", "position": 4, "name": "Nutraceuticals & Vitamins"},
    {"@type": "ListItem", "position": 5, "name": "Veterinary APIs"},
    {"@type": "ListItem", "position": 6, "name": "Plant Extracts"}
  ]
}
</script>

══════════════════════════════
PART 5: IMAGE ALT TEXT — ALL PAGES
══════════════════════════════
Add descriptive alt attributes to every image on the site:

Logo (header, all pages): alt="J. B. Khokhani & Co. — Pharmaceutical API Supplier Since 1965"
Logo (footer, all pages): alt="J. B. Khokhani & Co. — Est. 1965, Mumbai"
Gurudevshri photo (About page): alt="Pujya Gurudevshri Rakeshji — Spiritual Guide, Shrimad Rajchandra Mission Dharampur"
India flag (Presence page): alt="India — Primary pharmaceutical API manufacturing source"
China flag (Presence page): alt="China — API and nutraceutical ingredient source"
Europe flag (Presence page): alt="Europe — Specialty pharmaceutical ingredient source"
USA flag (Presence page): alt="USA — Regulated-market grade pharmaceutical materials"
Partner card logos (if any images): alt="[Partner/certification name] — J. B. Khokhani & Co. certified supplier"
Any other image: alt="J. B. Khokhani & Co. — Pharmaceutical API supplier since 1965, Mumbai"

══════════════════════════════
PART 6: HIDDEN PRODUCTS INDEX PAGE
══════════════════════════════
Create a new page at route /products-index with the following:

- Do NOT add it to the navigation menu — it must be invisible to regular visitors
- Page <head>:
  <title>Complete Pharmaceutical API Product Index | J. B. Khokhani & Co.</title>
  <meta name="description" content="Full index of 162 pharmaceutical APIs and intermediates supplied by J. B. Khokhani & Co. Antibiotics, cardiovascular, analgesics, nutraceuticals, veterinary APIs, plant extracts and more.">
  <meta name="robots" content="index, follow">
  <link rel="canonical" href="https://www.jbkhokhani.com/products-index">

- Page body must be plain static HTML — no JavaScript rendering, no pagination. All content must be in the HTML source so Google can crawl it in a single pass.

- Page content:
  <h1>Pharmaceutical API Product Index — J. B. Khokhani & Co.</h1>
  <p>J. B. Khokhani & Co. supplies 162 pharmaceutical APIs and intermediates across 6 therapeutic categories. All products are available in USP, BP, and EP grades with full regulatory documentation including CoA, DMF, and GMP certificates. Based in Mumbai, India. Exporting to 60+ countries since 1965.</p>

  Then list ALL 162 products from the existing product database, grouped under H2 category headings, as plain <ul><li> lists. Every product name must appear as static text in the HTML — not loaded by JavaScript. This is the entire purpose of this page: to give Google a single crawlable page with every product name indexed.

  Format:
  <h2>Antibiotics & Anti-Infectives</h2>
  <ul>
    <li>Amoxicillin Trihydrate</li>
    <li>Ampicillin Trihydrate</li>
    ... (all products in this category)
  </ul>
  <h2>Analgesics & NSAIDs</h2>
  <ul>
    <li>Paracetamol</li>
    <li>Ibuprofen</li>
    ... (all products in this category)
  </ul>
  ... (continue for all 6 categories)

  At the bottom:
  <p>For enquiries, contact J. B. Khokhani & Co. at info@jbkhokhani.com or +91-22-40441234. Address: B-207, Neelam Centre, Hind Cycle Road, Worli, Mumbai 400030, India.</p>
  <a href="/">Return to homepage</a>

══════════════════════════════
PART 7: SITEMAP
══════════════════════════════
If Figma Make supports sitemap.xml, generate one with these URLs:
https://www.jbkhokhani.com/
https://www.jbkhokhani.com/about
https://www.jbkhokhani.com/quality
https://www.jbkhokhani.com/products
https://www.jbkhokhani.com/services
https://www.jbkhokhani.com/presence
https://www.jbkhokhani.com/contact
https://www.jbkhokhani.com/products-index

If sitemap.xml is not supported natively, add this comment to the site's main HTML file:
<!-- sitemap.xml: submit manually to Google Search Console after deployment -->