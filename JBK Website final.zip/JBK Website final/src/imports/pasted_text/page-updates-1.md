ake the following improvements to the About, Quality, and Services pages. Apply all changes to both light mode and dark mode.

---

ABOUT PAGE

1. COMPANY STORY SECTION
- Add a section heading above the story text: "Our Story" — small all-caps DM Mono label (12px, gold, letter-spacing 0.15em) above a Playfair Display Bold 44px heading "Six Decades of Pharmaceutical Excellence"
- Add a thin animated gold line (60px, 2px) that draws in from left on scroll, below the heading

2. COMPANY TIMELINE
Add a vertical timeline section below the story text, before the Gurudevshri section:
- Section heading: "Our Journey" — Playfair Display Bold, 36px
- Vertical timeline with alternating left/right layout on desktop, single left-aligned on mobile
- Timeline line: 2px solid gold (#C9A84C) running vertically through the centre
- Each milestone: a gold circle node (12px diameter) on the line, year label in DM Sans Bold 14px gold, milestone text in DM Sans Regular 15px
- Milestones:
  - 1965: "Founded by J. B. Khokhani in Mumbai — beginning with domestic API distribution"
  - 1980s: "Expanded into export markets across Africa and the Middle East"
  - 1990s: "Second generation joins — Mahesh, Mehul, and Dinesh Khokhani"
  - 2000s: "Established depots in Bhiwandi, Baddi, and Haridwar for pan-India reach"
  - 2010s: "Expanded into nutraceuticals and veterinary APIs — product range crosses 100+"
  - Today: "300+ client companies, 15+ countries, $50M+ group turnover"
- Animate: each milestone fades in and slides up as user scrolls, 150ms stagger, cubic-bezier(0.16, 1, 0.3, 1)
- Light mode: timeline line gold, node gold, year text gold, milestone text navy
- Dark mode: same gold, milestone text #F0F4FF

3. GURUDEVSHRI SECTION
Full redesign:
- Full-width section with a distinct warm background:
  - Light mode: #EAE6DD (slightly deeper warm tone, like aged parchment)
  - Dark mode: #111E33
- 80px padding top and bottom
- Layout: two columns on desktop — left column has the photo (already in place), right column has the text
- Section label above heading: "Our Inspiration" — DM Mono, 12px, gold, letter-spacing 0.15em
- Heading: "Guided by Timeless Values" — Playfair Display Bold, 40px
- Body text: DM Sans Regular, 16px, line-height 1.85 — keep existing copy
- Pull quote: "The way you conduct yourself in every interaction is a reflection of your inner values."
  - Playfair Display Bold Italic, 24px
  - 4px solid left border in gold (#C9A84C), 24px left padding
  - Light mode: #0A1628. Dark mode: #F0F4FF
  - 32px margin above and below
- Link to srmd.org: styled as a small gold underlined text link, opens in new tab
- Fade-in animation on scroll: opacity 0 → 1, 0.6s ease-out

4. TEAM SECTION
- Section heading: "The Faces of J. B. Khokhani & Co." — Playfair Display Bold, 40px
- Subtext: "Six decades of trust, built by people who care." — DM Sans Regular, 18px, muted
- Team cards in a grid: 3 columns on desktop, 2 on tablet, 1 on mobile
- Each card:
  - Light mode: white background, 1px solid #E2DDD4 border, border-radius 10px, overflow hidden
  - Dark mode: #162236 background, 1px solid #1E3050 border, border-radius 10px
  - Photo area: square aspect ratio (1:1), placeholder is a circle with initials in gold on navy background, centred
  - Below photo: 20px padding, name in Playfair Display SemiBold 18px, role in DM Sans Medium 13px uppercase letter-spacing 0.08em gold
  - Department label: small pill badge (DM Mono 11px) — "Partner", "Domestic Sales", "Exports", "Operations"
  - Hover: card lifts translateY -6px, box-shadow deepens, 0.25s cubic-bezier(0.16, 1, 0.3, 1)
- Group cards by department with a small department heading above each group (DM Sans Bold, 14px, uppercase, gold, letter-spacing 0.1em)

---

QUALITY PAGE

1. SECTION HEADER
- Add: small DM Mono label "OUR COMMITMENT" above the main heading
- Main heading: "Quality at Every Step" — Playfair Display Bold, 48px
- Animated gold underline on scroll

2. QUALITY FRAMEWORK — Convert from list to icon card grid
- 3-column grid on desktop, 1 column on mobile
- Each quality point becomes a card:
  - Light mode: white background, 1px border #E2DDD4, border-radius 8px, 28px padding
  - Dark mode: #162236 background, 1px border #1E3050
  - Top: SVG icon (gold stroke, 32px) relevant to each point
  - Title: DM Sans Bold, 17px
  - Description: DM Sans Regular, 14px, muted, line-height 1.7
  - 3px gold top border on each card
  - Hover: translateY -4px, 0.2s ease
- Cards:
  - Shield icon: "GMP-Compliant Sourcing" — "All manufacturers are verified against GMP standards before onboarding"
  - Microscope icon: "Multi-Stage Quality Checks" — "From raw material to final delivery, every batch is verified"
  - Flask icon: "Microbiological & Chemical Testing" — "Full lab testing support including heavy metal analysis via ICP-MS"
  - Document icon: "Stability Testing" — "Shelf-life documentation and accelerated stability data available"
  - Certificate icon: "Pharmacopeial Standards" — "USP, BP, and EP grade materials with validated test methods"
  - Checkmark icon: "Regulatory Documentation" — "DMFs, CoAs, GMP certificates — all audit-ready"

3. STANDARDS BADGES
- Display USP / BP / EP / WHO-GMP / HPLC / ICP-MS as pill badges
- Same style as homepage category pills
- Light mode: navy background, white text. Dark mode: #162236 background, gold text, gold border

4. DOCUMENTATION SECTION
- Heading: "Documentation We Support" — Playfair Display SemiBold, 32px
- 4 document cards in a row (2×2 on mobile):
  - Document icon + "Drug Master Files (DMFs)"
  - Document icon + "NDA Filing Documentation"
  - Document icon + "Certificate of Analysis (CoA)"
  - Document icon + "GMP Compliance Certificates"
- Card style: same as quality framework cards but smaller (20px padding)

---

SERVICES PAGE

1. SECTION HEADER
- Small DM Mono label "WHAT WE OFFER" above heading
- Main heading: "Our Services" — Playfair Display Bold, 48px
- Animated gold underline

2. SERVICE CARDS — Convert from plain text blocks to cards
- Each service becomes a card (same card style as What We Do on homepage — white/dark bg, gold top border, icon, hover lift)
- Icons (SVG, gold stroke, 36px):
  - Trading & Distribution: bar chart / supply chain icon
  - Indenting & Global Sourcing: globe with arrows icon
  - Import & Export: two-way arrows / shipping icon
  - Contract Manufacturing: factory/gear icon
  - Regulatory & Documentation: shield with document icon
- Card title: Playfair Display SemiBold, 22px
- Card body: DM Sans Regular, 15px, line-height 1.75
- Layout: 2 columns on desktop (with the 5th card centred below), 1 column on mobile
- Stagger animation: 100ms delay between cards, same cubic-bezier as homepage

3. HOW IT WORKS — Process Flow
Add below the service cards:
- Section heading: "How We Work" — Playfair Display Bold, 36px
- 4-step horizontal process flow on desktop, vertical on mobile:
  - Step 1: Inquiry — "Tell us what you need — product, quantity, market, and timeline"
  - Step 2: Sourcing — "We identify the right manufacturer and negotiate pricing on your behalf"
  - Step 3: Documentation — "We prepare all regulatory and quality documentation required"
  - Step 4: Delivery — "Coordinated logistics to your location, with full tracking support"
- Each step: numbered circle (gold border, gold number, 48px diameter) + step title (DM Sans Bold, 16px) + description (DM Sans Regular, 14px)
- Steps connected by a thin gold dashed line on desktop
- Animate: steps appear one by one, 150ms stagger, fade-in + slide-up
- Light mode: navy text. Dark mode: white text. Gold accents throughout