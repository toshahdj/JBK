PROMPT 1 — Homepage Redesign

Redesign the Homepage with the following changes. Apply all changes to BOTH light mode and dark mode unless specified otherwise.

---

HERO SECTION

Replace the current flat background with a geometric pattern background:
- Pattern: a subtle, low-opacity grid of thin diagonal lines or a hexagonal dot-grid pattern
- Light mode: pattern colour #C9A84C at 6% opacity on #F4F1EC background — very subtle, almost invisible but adds texture
- Dark mode: pattern colour #C9A84C at 5% opacity on #0A1628 background
- The pattern should be a CSS background-pattern (SVG or CSS repeating-linear-gradient) — no images

Hero layout changes:
- Add a small all-caps label above the main headline: "PHARMACEUTICAL API SUPPLIER · EST. 1965" in DM Mono, 12px, letter-spacing 0.15em, gold colour (#C9A84C), with a thin 1px gold line on each side of the text (like a ruled label)
- Increase the main headline "YOUR TRUSTED PARTNER IN PHARMACEUTICAL SUPPLY" to 68px on desktop, 38px on mobile, Playfair Display Bold
- Add a thin animated gold underline (width: 0 → 80px, transition 0.8s ease-out, delay 0.5s) beneath the headline — centred if headline is centred, left-aligned if left-aligned
- Increase the subheadline "Over 60 years..." to 20px, DM Sans Regular, line-height 1.8, max-width 600px, slightly more breathing room above and below
- CTA Buttons: 
  - Primary button "Explore Our Products": solid background #C4714A (terracotta), white text, DM Sans Medium, 16px, padding 14px 32px, border-radius 4px, no border. Hover: background darkens to #A85C38, scale(1.03), transition 0.2s
  - Secondary button "Get in Touch": transparent background, 1.5px solid border #C9A84C (gold), gold text, same sizing. Hover: background fills to #C9A84C, text turns navy #0A1628, transition 0.2s
  - Add 16px gap between the two buttons
- Add 120px padding top and bottom to the hero section on desktop, 80px on mobile

---

STATS BAR

Complete redesign of the stats section:
- Full-width band with a distinct background:
  - Light mode: #0A1628 (deep navy) — makes it stand out from the warm off-white page
  - Dark mode: #060F1E (deeper navy)
- Layout: 3 stats in a horizontal row, separated by thin 1px vertical dividers in gold (#C9A84C) at 30% opacity
- Each stat:
  - Number: 72px, Playfair Display Bold, gold (#C9A84C), count-up animation on scroll (Intersection Observer, duration 2s, ease-out)
  - Label: 14px, DM Sans Medium, white (#F0F4FF), uppercase, letter-spacing 0.08em, displayed below the number
  - 48px padding top and bottom per stat
- Fix the stat values: "60+" Years in Business, "150+" Products, "300+" Client Companies
- On mobile: stack vertically, remove vertical dividers, add thin horizontal gold divider between each stat

---

WHAT WE DO SECTION

Redesign inspired by Balchem.com's clean corporate card style:

Section header:
- Small all-caps label above: "OUR CAPABILITIES" in DM Mono, 12px, gold, letter-spacing 0.15em
- Main heading: "What We Do" in Playfair Display Bold, 44px
- Thin gold animated line (60px wide, 2px height) that draws in from left on scroll, appearing just below the heading

Cards (3 columns on desktop, 1 column on mobile):
- Light mode card: white (#FFFFFF) background, subtle box-shadow (0 2px 16px rgba(10,22,40,0.07)), border-radius 8px
- Dark mode card: #162236 background, box-shadow (0 2px 20px rgba(0,0,0,0.3)), border-radius 8px
- Each card has a 3px solid gold (#C9A84C) top border
- Hover state: card lifts (translateY -6px), box-shadow deepens, gold top border brightens — transition 0.25s cubic-bezier(0.16, 1, 0.3, 1)
- Inside each card: 32px padding all sides

Icons (above each card title):
- Use SVG line icons, stroke style (not filled), stroke colour gold (#C9A84C), 36px × 36px
- Card 1 "API Trading & Distribution": molecule/atom icon (hexagonal ring with nodes)
- Card 2 "Global Sourcing & Indenting": globe with a location pin icon
- Card 3 "Regulatory & Documentation Support": document with a checkmark/shield icon
- Icon sits 24px above the card title
- Icon background: a soft circle, 64px × 64px
  - Light mode: #F4F1EC (warm off-white)
  - Dark mode: #0A1628 (navy)

Card title: Playfair Display SemiBold, 22px, navy (#0A1628) in light mode, #F0F4FF in dark mode
Card body: DM Sans Regular, 15px, line-height 1.75, #4A5568 in light mode, #A0AEC0 in dark mode

Stagger animation: each card fades in and slides up (translateY 30px → 0, opacity 0 → 1) on scroll, with 100ms delay between each card, easing: cubic-bezier(0.16, 1, 0.3, 1), duration 0.6s

---

PRODUCT CATEGORIES SECTION

Remove the 6 individual category tiles that redirect to /products.

Replace with a single clean section:
- Section heading: "Our Product Range" in Playfair Display Bold, 44px
- Subtext: "150+ pharmaceutical ingredients across APIs, nutraceuticals, and veterinary drugs — sourced from India's leading manufacturers and global suppliers." DM Sans, 17px, max-width 640px, centred
- Below the subtext, display the 6 category names as horizontal pill badges (not clickable tiles):
  - Antibiotics & Anti-infectives · Analgesics & NSAIDs · Cardiovascular & Metabolic · Nutraceuticals & Vitamins · Veterinary APIs · Plant Extracts
  - Each pill: DM Mono 12px uppercase, letter-spacing 0.1em, 8px 20px padding, border-radius 100px
  - Light mode: #0A1628 background, #F0F4FF text
  - Dark mode: #162236 background, #C9A84C text, 1px solid #C9A84C border
  - Pills wrap naturally on mobile
- Below the pills, a single prominent CTA button: "View Full Product List →"
  - Style: same as primary CTA (terracotta #C4714A, white text)
  - Centred, 48px margin top

---

WHY JBK — TRUST SECTION

Redesign the trust section:

Pull quote:
- "We don't just supply ingredients — we build supply chains."
- Playfair Display Bold Italic, 32px on desktop, 24px on mobile
- 4px solid left border in gold (#C9A84C), 24px left padding
- Light mode: text colour #0A1628. Dark mode: #F0F4FF
- Fade-in + slide-right animation on scroll (translateX -20px → 0, opacity 0 → 1, 0.6s)
- 48px margin above and below

Trust points — replace the plain list with a 2×2 icon card grid:
- 4 cards in a 2-column grid on desktop, 1 column on mobile
- Each card: icon (SVG, 28px, gold stroke) + bold stat/title + 1-line description
  - Card 1: Building/calendar icon · "Established 1965, Mumbai" · "Six decades of pharmaceutical supply expertise"
  - Card 2: People/network icon · "300+ Client Companies" · "Serving pharma firms across India and 15+ countries"
  - Card 3: Shield/checkmark icon · "GMP-Compliant Sourcing" · "Multi-stage quality checks from source to delivery"
  - Card 4: Location pin icon · "Multi-Location Presence" · "Depots in Bhiwandi, Baddi, and Haridwar"
- Card style:
  - Light mode: #F4F1EC background (same as page), 1px solid #E2DDD4 border, border-radius 8px, 28px padding
  - Dark mode: #111E33 background, 1px solid #1E3050 border, border-radius 8px, 28px padding
  - No hover effect needed — these are informational, not interactive
- Stat/title: DM Sans Bold, 18px, navy in light mode, white in dark mode
- Description: DM Sans Regular, 14px, #6B7280 in light mode, #8A9BB0 in dark mode

---

INQUIRY CTA BANNER

Full redesign:
- Full-width section with a strong background:
  - Light mode: deep navy #0A1628 with the same subtle geometric dot-grid pattern from the hero (gold at 5% opacity)
  - Dark mode: #060F1E with the same pattern
- All text white (#F0F4FF)
- Heading: "Can't find what you're looking for?" — Playfair Display Bold, 40px
- Body: "We source beyond our listed products. Tell us what you need." — DM Sans Regular, 18px, opacity 0.85, max-width 520px
- Button: "Submit a Sourcing Request →" — same terracotta style (#C4714A, white text) but slightly larger: 16px, padding 16px 36px
- Layout: centred, 80px padding top and bottom
- Fade-in animation on scroll: opacity 0 → 1, translateY 20px → 0, 0.5s ease-out

