Build a complete, production-ready multi-page website for J. B. Khokhani & Co., a Mumbai-based pharmaceutical API trading and distribution company established in 1965.

DESIGN REQUIREMENTS:

THEME — DUAL MODE
Build both a Light Mode and a Dark Mode version of every page.

LIGHT MODE PALETTE:
Page background: #F4F1EC (warm off-white, like aged parchment — not pure white)
Primary text: #0A1628 (deep navy)
Section background (alternating): #EAE6DD (slightly deeper warm tone for contrast)
Card background: #FFFFFF (pure white cards on the warm background — creates depth)
Accent / Gold: #C9A84C
Accent / Sage Green: #6B8F71 (trust, calm, health — used sparingly for icons and badges)
Accent / Terracotta: #C4714A (warmth, energy — used very sparingly for CTAs and highlights)
Nav background: #0A1628 (deep navy, same in both modes)
Footer background: #0A1628

DARK MODE PALETTE:
Page background: #0A1628 (deep navy)
Primary text: #F0F4FF
Section background (alternating): #111E33
Card background: #162236
Accent / Gold: #C9A84C
Accent / Sage Green: #6B8F71
Accent / Terracotta: #C4714A
Nav background: #060F1E
Footer background: #060F1E

COLOUR PSYCHOLOGY NOTES (for the AI to apply correctly):
Navy (#0A1628): Authority, trust, stability — dominant in nav, headings, and dark sections.
Gold (#C9A84C): Prestige, quality, heritage — used for accents, underlines, CTA borders, and highlights.
Warm Off-White (#F4F1EC): Approachability, warmth, calm — the light mode page background. Avoids the clinical coldness of pure white.
Sage Green (#6B8F71): Health, nature, reliability — used for category badges (Nutraceuticals, Veterinary), icons, and subtle section dividers. Never dominant.
Terracotta (#C4714A): Energy, confidence, human warmth — used only for primary CTA buttons and key highlights. Max 2-3 uses per page.

Include a smooth toggle button (sun/moon icon) in the top navigation bar to switch between modes.
Mode preference should persist across pages using localStorage.
All transitions between light and dark mode must be smooth (CSS transition: all 0.3s ease).

TYPOGRAPHY — EDITORIAL SERIF + CLEAN SANS
Use a Serif + Sans-Serif pairing for an editorial, premium feel (inspired by high-end agency templates like Framer's Magnet template).

PRIMARY HEADING FONT: Playfair Display (Google Fonts)
Use for: H1, H2, section titles, pull quotes
Weight: Bold (700) for H1, SemiBold (600) for H2/H3
Style: Italic variant for pull quotes and hero subheadings
This gives the site a prestigious, editorial quality — trusted by luxury and professional brands

SECONDARY / BODY FONT: DM Sans (Google Fonts)
Use for: body text, nav links, labels, form fields, card text, captions
Weight: Regular (400) for body, Medium (500) for labels and nav, Bold (700) for stat numbers
Clean, modern, highly legible — pairs beautifully with Playfair Display

ACCENT / LABEL FONT: DM Mono (Google Fonts) — optional
Use for: category badges, technical labels (e.g. "USP / BP / EP"), small caps labels
Adds a precise, scientific feel appropriate for pharma

FONT SIZES:
H1 (Hero): 56–72px desktop, 36px mobile — Playfair Display Bold
H2 (Section titles): 40–48px desktop, 28px mobile — Playfair Display SemiBold
H3 (Card titles): 24px — Playfair Display SemiBold
Body: 16px, line-height 1.7 — DM Sans Regular
Labels/Badges: 12px uppercase, letter-spacing 0.1em — DM Sans Medium or DM Mono
Stat numbers: 48–64px — DM Sans Bold
Nav links: 15px — DM Sans Medium

ANIMATIONS & INTERACTIONS
Hero section: Fade-in headline on load (opacity 0 to 1, translateY 20px to 0, duration 0.8s).
Stats bar: Count-up animation when scrolled into view (e.g. "0" counting up to "60+").
Cards and sections: Subtle fade-in + slide-up on scroll (Intersection Observer, staggered 0.1s delay per card).
Navigation: Sticky top nav with a subtle box-shadow that appears on scroll.
Buttons: Smooth hover state — background colour shift + slight scale (transform: scale(1.03)).
Page transitions: Smooth fade between pages (opacity transition).
Team cards: Hover lifts the card slightly (translateY -4px, box-shadow deepens).
Product list: Smooth filter/search animation — items fade out/in when filtered.
Pull quotes: Subtle left border in gold (#C9A84C), italic Playfair Display, slight fade-in on scroll.

MOBILE-FIRST & RESPONSIVE
Design mobile-first. All layouts must work perfectly on 375px (iPhone SE), 390px (iPhone 14), 768px (iPad), and 1440px (desktop).
Navigation: Hamburger menu on mobile, collapsing to a full-width slide-down menu.
Stats bar: Stack vertically on mobile, horizontal on desktop.
Product tabs: Horizontal scroll on mobile, full tabs on desktop.
Team grid: 1 column on mobile, 2 on tablet, 3-4 on desktop.
Contact form: Full width on mobile.
Touch-friendly tap targets (minimum 44x44px).

PAGES (5 total)
Home | About & Quality | Products | Services & Global Reach | Contact

PRODUCT LIST — JSON-POWERED SEARCH
The Products page must load product data from a local products.json file (structure defined in Section C below).
Render the product list dynamically from this JSON — do not hardcode products in HTML.
Implement a live search bar at the top: filters products in real time as the user types (searches across name, category, and manufacturer fields).
Implement category filter tabs: All | APIs (Export) | APIs (Domestic) | Manufacturing | Veterinary | Nutraceuticals.
Smooth filter animation: items fade out/in when category or search changes.
Each product card shows: Product Name, Manufacturer (if applicable), Category badge.
At the bottom of the Products page, include a Custom Sourcing Request form (fields defined in Section B, Page 3).

FOOTER
Consistent footer on all pages.
Dark background in both light and dark mode (navy #0A1628 in light mode, #060F1E in dark mode).
White text, gold hover on nav links.
