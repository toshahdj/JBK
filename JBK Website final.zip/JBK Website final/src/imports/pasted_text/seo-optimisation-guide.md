Implement complete SEO optimisation across the entire website. This is the most important prompt — execute every instruction precisely.

═══════════════════════════════
PART 1: UNIQUE PAGE TITLES & META DESCRIPTIONS
═══════════════════════════════

Set a unique <title> and <meta name="description"> for every page. Do not use "JBK Website" as a title anywhere.

HOME PAGE:
Title: JBK — Pharmaceutical API Supplier Since 1965 | J. B. Khokhani & Co.
Meta description: J. B. Khokhani & Co. is a trusted pharmaceutical API supplier with 60+ years of experience. Supplying 150+ APIs and intermediates to 300+ clients across 60+ countries. USP, BP, EP, WHO-GMP certified.

ABOUT PAGE:
Title: About JBK | 60 Years of Pharmaceutical Excellence | J. B. Khokhani & Co.
Meta description: Founded in 1965, J. B. Khokhani & Co. has built six decades of expertise in pharmaceutical API sourcing, quality assurance, and global distribution. Learn our story.

PRODUCTS PAGE:
Title: Pharmaceutical APIs & Intermediates | Product Catalogue | J. B. Khokhani & Co.
Meta description: Browse 150+ pharmaceutical APIs and intermediates across antibiotics, cardiovascular, oncology, respiratory, CNS, and more. USP/BP/EP grade. Request samples and quotes.

SERVICES PAGE:
Title: Pharmaceutical Sourcing & Supply Services | J. B. Khokhani & Co.
Meta description: End-to-end pharmaceutical API sourcing, quality testing, regulatory documentation, and global logistics. Trusted by 300+ clients worldwide since 1965.

GLOBAL PRESENCE PAGE:
Title: Global Presence | API Exports to 60+ Countries | J. B. Khokhani & Co.
Meta description: J. B. Khokhani & Co. exports pharmaceutical APIs to clients across Europe, the Americas, Southeast Asia, the Middle East, and Africa. Sourcing from India, China, and Europe.

CONTACT PAGE:
Title: Contact JBK | Request a Quote or Sample | J. B. Khokhani & Co.
Meta description: Get in touch with J. B. Khokhani & Co. for pharmaceutical API enquiries, sample requests, pricing, and regulatory documentation. Based in Mumbai, India.

QUALITY PAGE (if separate):
Title: Quality Assurance | USP · BP · EP · WHO-GMP Certified | J. B. Khokhani & Co.
Meta description: JBK maintains rigorous quality standards with USP, BP, EP, and WHO-GMP certifications. HPLC and ICP-MS testing. CoA, MSDS, and full regulatory documentation available.

═══════════════════════════════
PART 2: OPEN GRAPH & TWITTER CARD TAGS
═══════════════════════════════

Add these to every page's <head>:

<meta property="og:type" content="website">
<meta property="og:site_name" content="J. B. Khokhani & Co.">
<meta property="og:image" content="[use the JBK logo URL already in the project]">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:site" content="@JBKhokhani">

Per-page og:title and og:description should match the page title and meta description above exactly.
Per-page og:url should be the canonical URL of that page.

═══════════════════════════════
PART 3: SCHEMA MARKUP (JSON-LD)
═══════════════════════════════

Add a <script type="application/ld+json"> block to the <head> of the HOME PAGE with this Organisation schema:

{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "J. B. Khokhani & Co.",
  "alternateName": "JBK",
  "url": "https://www.jbkhokhani.com",
  "logo": "[JBK logo URL from the project]",
  "foundingDate": "1965",
  "description": "Pharmaceutical API supplier and distributor with 60+ years of experience. Supplying 150+ APIs and intermediates to 300+ clients across 60+ countries.",
  "address": {
    "@type": "PostalAddress",
    "addressLocality": "Mumbai",
    "addressCountry": "IN"
  },
  "contactPoint": {
    "@type": "ContactPoint",
    "telephone": "+91-98333-22211",
    "contactType": "sales",
    "availableLanguage": ["English", "Hindi"]
  },
  "sameAs": []
}

Add a second JSON-LD block to the PRODUCTS PAGE with ItemList schema:

{
  "@context": "https://schema.org",
  "@type": "ItemList",
  "name": "Pharmaceutical APIs and Intermediates",
  "description": "Complete catalogue of pharmaceutical APIs and intermediates supplied by J. B. Khokhani & Co.",
  "numberOfItems": 162,
  "itemListElement": [
    {"@type": "ListItem", "position": 1, "name": "Antibiotics APIs"},
    {"@type": "ListItem", "position": 2, "name": "Cardiovascular APIs"},
    {"@type": "ListItem", "position": 3, "name": "Oncology APIs"},
    {"@type": "ListItem", "position": 4, "name": "Respiratory APIs"},
    {"@type": "ListItem", "position": 5, "name": "CNS APIs"},
    {"@type": "ListItem", "position": 6, "name": "Anti-Infective APIs"},
    {"@type": "ListItem", "position": 7, "name": "Vitamins and Nutraceuticals"},
    {"@type": "ListItem", "position": 8, "name": "Plant Extracts"},
    {"@type": "ListItem", "position": 9, "name": "Hormones and Steroids"},
    {"@type": "ListItem", "position": 10, "name": "Antifungals"}
  ]
}

═══════════════════════════════
PART 4: HIDDEN PRODUCTS INDEX PAGE (/products-index)
═══════════════════════════════

Create a new page at the route /products-index with the following:

- This page is for search engine crawling only — it must NOT appear in the main navigation
- Add a <meta name="robots" content="index, follow"> tag so Google crawls it
- Add a <link rel="canonical" href="/products-index"> tag
- Page title: "Complete Pharmaceutical API Product Index | J. B. Khokhani & Co."
- Meta description: "Full index of 162+ pharmaceutical APIs and intermediates supplied by J. B. Khokhani & Co. Antibiotics, cardiovascular, oncology, respiratory, CNS, antifungals, plant extracts and more."

Page content (plain HTML, no JavaScript rendering — must be server-side rendered or static):
- H1: "Pharmaceutical API Product Index — J. B. Khokhani & Co."
- A short paragraph: "J. B. Khokhani & Co. supplies 162+ pharmaceutical APIs and intermediates across 10 therapeutic categories. All products are available in USP, BP, and EP grades with full regulatory documentation."
- Then list ALL 162 products from the existing product catalogue as plain HTML — one <p> or <li> per product, with the product name as text
- Group them under H2 headings by category (e.g. <h2>Antibiotics</h2>, <h2>Cardiovascular & Metabolic</h2> etc.)
- No pagination, no JavaScript — all 162 products must be in the static HTML of this single page so Google can crawl them in one pass
- Minimal styling — this page does not need to look beautiful, it needs to be crawlable

═══════════════════════════════
PART 5: ADDITIONAL SEO TAGS
═══════════════════════════════

Add to every page's <head>:
- <meta name="robots" content="index, follow">
- <meta name="author" content="J. B. Khokhani & Co.">
- <meta name="geo.region" content="IN-MH">
- <meta name="geo.placename" content="Mumbai">
- <html lang="en"> attribute on the root element

Add to every image on the site:
- A descriptive alt attribute. Examples:
  - Logo: alt="J. B. Khokhani & Co. — Pharmaceutical API Supplier Since 1965"
  - Any product image: alt="[Product name] pharmaceutical API — J. B. Khokhani & Co."
  - Any team photo: alt="[Person name], [Role] — J. B. Khokhani & Co."
  - Any certification badge: alt="[Certification name] certified — J. B. Khokhani & Co."
  - Hero/banner images: alt="J. B. Khokhani & Co. pharmaceutical API manufacturing and supply"

═══════════════════════════════
PART 6: SITEMAP & CANONICAL TAGS
═══════════════════════════════

- Add <link rel="canonical"> to every page pointing to its own URL
- If Figma Make supports sitemap.xml generation, create one listing all pages including /products-index
- If not supported natively, add a comment in the code: <!-- sitemap.xml to be added at deployment -->