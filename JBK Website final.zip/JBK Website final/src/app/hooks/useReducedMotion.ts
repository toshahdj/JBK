import { useEffect, useState } from "react";

/**
 * React hook that reflects the user's `prefers-reduced-motion` OS-level setting.
 *
 * Returns `true` when the user has requested reduced motion. Components should
 * use this to disable autoplay, skip entrance slides, and swap dramatic motion
 * for instant snaps.
 *
 * Updates reactively if the user changes their preference mid-session.
 *
 * @example
 *   const prefersReducedMotion = useReducedMotion();
 *   const autoplay = prefersReducedMotion ? false : 4000;
 */
export default function useReducedMotion(): boolean {
  const [prefersReduced, setPrefersReduced] = useState<boolean>(() => {
    if (typeof window === "undefined" || !window.matchMedia) return false;
    return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  });

  useEffect(() => {
    if (typeof window === "undefined" || !window.matchMedia) return;

    const mediaQuery = window.matchMedia("(prefers-reduced-motion: reduce)");
    const handleChange = (event: MediaQueryListEvent) => {
      setPrefersReduced(event.matches);
    };

    // Older Safari uses addListener/removeListener
    if (mediaQuery.addEventListener) {
      mediaQuery.addEventListener("change", handleChange);
      return () => mediaQuery.removeEventListener("change", handleChange);
    } else {
      mediaQuery.addListener(handleChange);
      return () => {
        mediaQuery.removeListener(handleChange);
      };
    }
  }, []);

  return prefersReduced;
}
