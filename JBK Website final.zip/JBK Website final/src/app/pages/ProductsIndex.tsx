import { Link } from "react-router";
import { useEffect } from "react";
import productsData from "../data/products.json";

export default function ProductsIndex() {
  useEffect(() => {
    document.title = "Complete Pharmaceutical Product Index — 247 APIs, Veterinary & Nutraceuticals | J. B. Khokhani & Co.";

    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute("content", "Full index of 247 pharmaceutical APIs, veterinary products, and nutraceutical ingredients supplied by J. B. Khokhani & Co. Antibiotics, cardiovascular, nutraceuticals, veterinary and more.");
    } else {
      const meta = document.createElement('meta');
      meta.name = "description";
      meta.content = "Full index of 247 pharmaceutical APIs, veterinary products, and nutraceutical ingredients supplied by J. B. Khokhani & Co. Antibiotics, cardiovascular, nutraceuticals, veterinary and more.";
      document.head.appendChild(meta);
    }

    const metaRobots = document.querySelector('meta[name="robots"]');
    if (metaRobots) {
      metaRobots.setAttribute("content", "index, follow");
    } else {
      const meta = document.createElement('meta');
      meta.name = "robots";
      meta.content = "index, follow";
      document.head.appendChild(meta);
    }

    // Canonical link
    let canonical = document.querySelector('link[rel="canonical"]');
    if (canonical) {
      canonical.setAttribute("href", "https://www.jbkhokhani.com/products-index");
    } else {
      canonical = document.createElement('link');
      canonical.setAttribute("rel", "canonical");
      canonical.setAttribute("href", "https://www.jbkhokhani.com/products-index");
      document.head.appendChild(canonical);
    }

    // Add additional SEO tags
    const additionalTags = [
      { name: "author", content: "J. B. Khokhani & Co." },
      { name: "geo.region", content: "IN-MH" },
      { name: "geo.placename", content: "Mumbai" },
      { name: "geo.position", content: "19.0176;72.8562" },
      { name: "ICBM", content: "19.0176, 72.8562" },
    ];

    additionalTags.forEach(({ name, content }) => {
      let tag = document.querySelector(`meta[name="${name}"]`);
      if (tag) {
        tag.setAttribute("content", content);
      } else {
        tag = document.createElement('meta');
        tag.setAttribute("name", name);
        tag.setAttribute("content", content);
        document.head.appendChild(tag);
      }
    });
  }, []);

  const categories = [
    "APIs",
    "Veterinary",
    "Nutraceuticals"
  ];

  const getProductsByCategory = (category: string) => {
    return productsData.filter(product => product.category === category);
  };

  return (
    <div className="min-h-screen py-16 md:py-24 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto">
        <h1
          className="text-3xl md:text-4xl mb-6"
          style={{
            fontFamily: "var(--font-heading)",
            fontWeight: 700,
            color: "var(--color-foreground)",
          }}
        >
          Pharmaceutical API Product Index — J. B. Khokhani & Co.
        </h1>

        <p
          className="text-lg mb-12"
          style={{
            fontFamily: "var(--font-body)",
            color: "var(--color-foreground)",
          }}
        >
          J. B. Khokhani & Co. supplies 247 pharmaceutical APIs, veterinary products, and nutraceutical ingredients across three categories. All products are available in IP, BP, EP, and USP grades with full regulatory documentation including CoA, DMF, and GMP certificates. Based in Mumbai, India. Exporting to 60+ countries since 1965.
        </p>

        {categories.map((category) => {
          const products = getProductsByCategory(category);
          return (
            <section key={category} className="mb-12">
              <h2
                className="text-2xl md:text-3xl mb-6"
                style={{
                  fontFamily: "var(--font-heading)",
                  fontWeight: 600,
                  color: "var(--color-foreground)",
                }}
              >
                {category}
              </h2>
              <ul
                className="space-y-3"
                style={{
                  fontFamily: "var(--font-body)",
                  color: "var(--color-foreground)",
                }}
              >
                {products.map((product, index) => (
                  <li key={index} className="text-base">
                    <strong>{product.name}</strong>
                    {product.manufacturer && (
                      <span style={{ color: "var(--color-muted-foreground)" }}>
                        {" "}— {product.manufacturer}
                      </span>
                    )}
                  </li>
                ))}
              </ul>
            </section>
          );
        })}

        <div
          className="mt-16 pt-8 border-t"
          style={{ borderColor: "var(--color-border)" }}
        >
          <p
            className="text-base mb-4"
            style={{
              fontFamily: "var(--font-body)",
              color: "var(--color-foreground)",
            }}
          >
            For enquiries, contact J. B. Khokhani & Co. at{" "}
            <a
              href="mailto:info@jbkhokhani.com"
              style={{ color: "#C9A84C", textDecoration: "underline" }}
            >
              info@jbkhokhani.com
            </a>{" "}
            or{" "}
            <a
              href="tel:+912240441234"
              style={{ color: "#C9A84C", textDecoration: "underline" }}
            >
              +91-22-40441234
            </a>
            . Address: B-207, Neelam Centre, Hind Cycle Road, Worli, Mumbai 400030, India.
          </p>
          <Link
            to="/"
            style={{
              fontFamily: "var(--font-body)",
              color: "#C9A84C",
              textDecoration: "underline",
            }}
          >
            Return to homepage
          </Link>
        </div>
      </div>
    </div>
  );
}
