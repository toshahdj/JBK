import {
  BarChart3,
  Globe2,
  ArrowLeftRight,
  Factory,
  ShieldCheck,
} from "lucide-react";
import ScrollReveal from "../components/ScrollReveal";
import { useState, useEffect } from "react";

// Process step icons
const InquiryIcon = () => (
  <svg width="22" height="22" viewBox="3 3 20 20" fill="none" stroke="#C9A84C" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M22 16a2 2 0 0 1-2 2H8l-4 4V6a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
    <line x1="8" y1="10" x2="18" y2="10" />
    <line x1="8" y1="14" x2="16" y2="14" />
    <line x1="8" y1="18" x2="14" y2="18" />
  </svg>
);

const EvaluationIcon = () => (
  <svg width="22" height="22" viewBox="3 3 20 20" fill="none" stroke="#C9A84C" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="11" cy="11" r="7" />
    <line x1="16" y1="16" x2="22" y2="22" />
  </svg>
);

const DocumentationIcon = () => (
  <svg width="22" height="22" viewBox="5 3 18 20" fill="none" stroke="#C9A84C" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M8 4h12a2 2 0 0 1 2 2v16a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z" />
    <line x1="10" y1="10" x2="18" y2="10" />
    <line x1="10" y1="14" x2="18" y2="14" />
    <line x1="10" y1="18" x2="14" y2="18" />
  </svg>
);

const DispatchIcon = () => (
  <svg width="22" height="22" viewBox="1 8 24 14" fill="none" stroke="#C9A84C" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="2" y="10" width="16" height="10" rx="2" />
    <path d="M18 10h3l3 3v7h-6" />
    <circle cx="7" cy="20" r="2" />
    <circle cx="20" cy="20" r="2" />
  </svg>
);

export default function Services() {
  const [lineVisible, setLineVisible] = useState(false);

  // SEO: Set page title and meta tags
  useEffect(() => {
    document.title = "Pharmaceutical Sourcing & Supply Services | J. B. Khokhani & Co.";

    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute("content", "End-to-end pharmaceutical API sourcing, quality testing, regulatory documentation, and global logistics. Trusted by 300+ clients worldwide since 1965.");
    } else {
      const meta = document.createElement('meta');
      meta.name = "description";
      meta.content = "End-to-end pharmaceutical API sourcing, quality testing, regulatory documentation, and global logistics. Trusted by 300+ clients worldwide since 1965.";
      document.head.appendChild(meta);
    }

    // Open Graph tags
    const ogTags = [
      { property: "og:title", content: "Pharmaceutical Sourcing & Supply Services | J. B. Khokhani & Co." },
      { property: "og:description", content: "End-to-end pharmaceutical API sourcing, quality testing, regulatory documentation, and global logistics. Trusted by 300+ clients worldwide since 1965." },
      { property: "og:type", content: "website" },
      { property: "og:site_name", content: "J. B. Khokhani & Co." },
      { property: "og:url", content: "https://www.jbkhokhani.com/services" },
      { property: "og:image", content: "https://www.jbkhokhani.com/assets/1_without_background.png" },
    ];

    ogTags.forEach(({ property, content }) => {
      let tag = document.querySelector(`meta[property="${property}"]`);
      if (tag) {
        tag.setAttribute("content", content);
      } else {
        tag = document.createElement('meta');
        tag.setAttribute("property", property);
        tag.setAttribute("content", content);
        document.head.appendChild(tag);
      }
    });

    // Twitter Card tags
    const twitterTags = [
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "Pharmaceutical Sourcing & Supply Services | J. B. Khokhani & Co." },
      { name: "twitter:description", content: "End-to-end pharmaceutical API sourcing, quality testing, regulatory documentation, and global logistics. Trusted by 300+ clients worldwide since 1965." },
      { name: "twitter:image", content: "https://www.jbkhokhani.com/assets/1_without_background.png" },
    ];

    twitterTags.forEach(({ name, content }) => {
      let tag = document.querySelector(`meta[name="${name}"]`);
      if (tag) {
        tag.setAttribute("content", content);
      } else {
        tag = document.createElement('meta');
        tag.setAttribute("name", name);
        tag.setAttribute("content", content);
        document.head.appendChild(tag);
      }
    });

    // Canonical link
    let canonical = document.querySelector('link[rel="canonical"]');
    if (canonical) {
      canonical.setAttribute("href", "https://www.jbkhokhani.com/services");
    } else {
      canonical = document.createElement('link');
      canonical.setAttribute("rel", "canonical");
      canonical.setAttribute("href", "https://www.jbkhokhani.com/services");
      document.head.appendChild(canonical);
    }

    // Add additional SEO tags
    const additionalTags = [
      { name: "robots", content: "index, follow" },
      { name: "author", content: "J. B. Khokhani & Co." },
      { name: "geo.region", content: "IN-MH" },
      { name: "geo.placename", content: "Mumbai" },
      { name: "geo.position", content: "19.0176;72.8562" },
      { name: "ICBM", content: "19.0176, 72.8562" },
    ];

    additionalTags.forEach(({ name, content }) => {
      let tag = document.querySelector(`meta[name="${name}"]`);
      if (tag) {
        tag.setAttribute("content", content);
      } else {
        tag = document.createElement('meta');
        tag.setAttribute("name", name);
        tag.setAttribute("content", content);
        document.head.appendChild(tag);
      }
    });
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      setLineVisible(true);
    }, 300);
    return () => clearTimeout(timer);
  }, []);

  const services = [
    {
      icon: BarChart3,
      title: "Trading & Distribution",
      description:
        "We maintain active supply relationships with India's leading API manufacturers and distribute across domestic and international markets. Our network means faster sourcing, better pricing, and reliable availability.",
    },
    {
      icon: Globe2,
      title: "Indenting & Global Sourcing",
      description:
        "We act as a sourcing office for international buyers looking to procure from India. We identify the right manufacturer, negotiate pricing, manage documentation, and coordinate logistics — so you don't have to.",
    },
    {
      icon: ArrowLeftRight,
      title: "Import & Export",
      description:
        "We handle both directions. Importing APIs and ingredients from China, Europe, and the USA for Indian formulators. Exporting Indian-manufactured APIs to regulated and semi-regulated markets worldwide.",
    },
    {
      icon: Factory,
      title: "Contract Manufacturing Coordination",
      description:
        "Need finished formulations? We coordinate with WHO-GMP aligned manufacturing partners for tablets, capsules, and other dosage forms — including Tramadol, Diclofenac combinations, and multivitamins.",
    },
    {
      icon: ShieldCheck,
      title: "Regulatory & Documentation Support",
      description:
        "We assist with Drug Master Files (DMFs), NDA filing documentation, Certificate of Analysis (CoA), GMP compliance certificates, and quality control lab coordination (chemical + microbiological).",
    },
  ];

  const processSteps = [
    {
      icon: InquiryIcon,
      title: "Inquiry",
      description: "Tell us what you need — product, quantity, market, and timeline",
    },
    {
      icon: EvaluationIcon,
      title: "Evaluation",
      description: "We identify the right manufacturer and negotiate pricing on your behalf",
    },
    {
      icon: DocumentationIcon,
      title: "Documentation",
      description: "We prepare all regulatory and quality documentation required",
    },
    {
      icon: DispatchIcon,
      title: "Dispatch",
      description: "Coordinated logistics to your location, with full tracking support",
    },
  ];


  return (
    <div className="min-h-screen">
      {/* Our Services */}
      <section className="py-16 md:py-24 px-4 sm:px-6 lg:px-8 relative overflow-visible">
        <div
          className="absolute inset-0 dark:hidden pointer-events-none"
          style={{
            backgroundImage: `repeating-linear-gradient(
              45deg,
              rgba(10, 22, 40, 0.04),
              rgba(10, 22, 40, 0.04) 1px,
              transparent 1px,
              transparent 20px
            ),
            repeating-linear-gradient(
              -45deg,
              rgba(10, 22, 40, 0.04),
              rgba(10, 22, 40, 0.04) 1px,
              transparent 1px,
              transparent 20px
            )`,
          }}
        />
        <div
          className="absolute inset-0 hidden dark:block pointer-events-none"
          style={{
            backgroundImage: `repeating-linear-gradient(
              45deg,
              rgba(240, 244, 255, 0.03),
              rgba(240, 244, 255, 0.03) 1px,
              transparent 1px,
              transparent 20px
            ),
            repeating-linear-gradient(
              -45deg,
              rgba(240, 244, 255, 0.03),
              rgba(240, 244, 255, 0.03) 1px,
              transparent 1px,
              transparent 20px
            )`,
          }}
        />
        <div className="max-w-6xl mx-auto relative z-10">
          <div className="mb-16">
            <div
              className="text-xs uppercase mb-4 text-center"
              style={{
                fontFamily: "var(--font-mono)",
                letterSpacing: "0.15em",
                color: "#C9A84C",
              }}
            >
              What We Offer
            </div>
            <h1
              className="text-3xl md:text-[44px] mb-4 text-center"
              style={{
                fontFamily: "var(--font-heading)",
                fontWeight: 700,
                color: "var(--color-foreground)",
              }}
            >
              Our Services
            </h1>
            <div
              className="h-0.5 transition-all duration-800 mx-auto"
              style={{
                backgroundColor: "#C9A84C",
                width: lineVisible ? "60px" : "0px",
                transitionTimingFunction: "ease-out",
              }}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            {services.slice(0, 4).map((service, index) => (
              <ScrollReveal key={index} delay={index * 0.08}>
                <div
                  className="rounded-lg p-8 transition-all duration-300"
                  style={{
                    backgroundColor: "var(--color-card)",
                    border: "1px solid var(--color-border)",
                    position: "relative",
                    height: "auto",
                    overflow: "visible",
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.transform = "translateY(-6px)";
                    e.currentTarget.style.boxShadow = "0 12px 32px rgba(10,22,40,0.15)";
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.transform = "translateY(0)";
                    e.currentTarget.style.boxShadow = "none";
                  }}
                >
                  <svg width="22" height="22" viewBox="0 0 22 22"
                    style={{ position: "absolute", top: "12px", left: "12px", pointerEvents: "none" }}
                    aria-hidden="true">
                    <path d="M2 22 L2 2 L22 2" stroke="#C9A84C" strokeWidth="1.5" fill="none" />
                  </svg>
                  <service.icon
                    className="w-9 h-9 mb-4"
                    style={{ color: "#C9A84C", marginLeft: "12px", marginTop: "8px" }}
                    strokeWidth={1.5}
                  />
                  <h3
                    className="text-[22px] mb-2 min-h-[2lh]"
                    style={{
                      fontFamily: "var(--font-heading)",
                      fontWeight: 600,
                      color: "var(--color-foreground)",
                    }}
                  >
                    {service.title}
                  </h3>
                  <div
                    aria-hidden="true"
                    style={{
                      height: "1px",
                      backgroundColor: "rgba(201, 168, 76, 0.35)",
                      marginBottom: "14px",
                    }}
                  />
                  <p
                    className="text-[15px] leading-[1.75] min-h-[6lh]"
                    style={{
                      fontFamily: "var(--font-body)",
                      color: "var(--color-foreground)",
                    }}
                  >
                    {service.description}
                  </p>
                </div>
              </ScrollReveal>
            ))}
          </div>

          {/* Fifth card centered */}
          <div className="max-w-full md:max-w-[calc(50%-12px)] mx-auto">
            <ScrollReveal delay={0.4}>
              {(() => {
                const FifthIcon = services[4].icon;
                return (
                  <div
                    className="rounded-lg p-8 transition-all duration-300"
                    style={{
                      backgroundColor: "var(--color-card)",
                      border: "1px solid var(--color-border)",
                      position: "relative",
                      height: "auto",
                      overflow: "visible",
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.transform = "translateY(-6px)";
                      e.currentTarget.style.boxShadow = "0 12px 40px rgba(10,22,40,0.12)";
                      e.currentTarget.style.transition = "all 0.25s cubic-bezier(0.16, 1, 0.3, 1)";
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.transform = "translateY(0)";
                      e.currentTarget.style.boxShadow = "none";
                      e.currentTarget.style.transition = "all 0.25s cubic-bezier(0.16, 1, 0.3, 1)";
                    }}
                  >
                    <svg width="22" height="22" viewBox="0 0 22 22"
                      style={{ position: "absolute", top: "12px", left: "12px", pointerEvents: "none" }}
                      aria-hidden="true">
                      <path d="M2 22 L2 2 L22 2" stroke="#C9A84C" strokeWidth="1.5" fill="none" />
                    </svg>
                    <FifthIcon
                      className="w-9 h-9 mb-4"
                      style={{ color: "#C9A84C", marginLeft: "12px", marginTop: "8px" }}
                      strokeWidth={1.5}
                    />
                    <h3
                      className="text-[22px] mb-2 min-h-[2lh]"
                      style={{
                        fontFamily: "var(--font-heading)",
                        fontWeight: 600,
                        color: "var(--color-foreground)",
                      }}
                    >
                      {services[4].title}
                    </h3>
                    <div
                      aria-hidden="true"
                      style={{
                        height: "1px",
                        backgroundColor: "rgba(201, 168, 76, 0.35)",
                        marginBottom: "14px",
                      }}
                    />
                    <p
                      className="text-[15px] leading-[1.75] min-h-[6lh]"
                      style={{
                        fontFamily: "var(--font-body)",
                        color: "var(--color-foreground)",
                      }}
                    >
                      {services[4].description}
                    </p>
                  </div>
                );
              })()}
            </ScrollReveal>
          </div>
        </div>
      </section>

      {/* How We Work */}
      <section
        className="py-16 md:py-24 px-4 sm:px-6 lg:px-8 relative"
        style={{ backgroundColor: "var(--color-section-bg)" }}
      >
        <div
          className="absolute inset-0 dark:hidden"
          style={{
            backgroundImage: `repeating-linear-gradient(
              45deg,
              rgba(10, 22, 40, 0.04),
              rgba(10, 22, 40, 0.04) 1px,
              transparent 1px,
              transparent 20px
            ),
            repeating-linear-gradient(
              -45deg,
              rgba(10, 22, 40, 0.04),
              rgba(10, 22, 40, 0.04) 1px,
              transparent 1px,
              transparent 20px
            )`,
          }}
        />
        <div
          className="absolute inset-0 hidden dark:block"
          style={{
            backgroundImage: `repeating-linear-gradient(
              45deg,
              rgba(240, 244, 255, 0.03),
              rgba(240, 244, 255, 0.03) 1px,
              transparent 1px,
              transparent 20px
            ),
            repeating-linear-gradient(
              -45deg,
              rgba(240, 244, 255, 0.03),
              rgba(240, 244, 255, 0.03) 1px,
              transparent 1px,
              transparent 20px
            )`,
          }}
        />
        <div className="max-w-6xl mx-auto relative z-10">
          <h2
            className="text-3xl md:text-[36px] mb-16 text-center"
            style={{
              fontFamily: "var(--font-heading)",
              fontWeight: 700,
              color: "var(--color-foreground)",
            }}
          >
            How We Work
          </h2>

          <div className="relative">
            {/* Dashed connecting line - desktop only */}
            <div
              className="hidden md:block absolute top-6 left-0 right-0 h-0.5"
              style={{
                backgroundImage: "repeating-linear-gradient(to right, #C9A84C 0px, #C9A84C 8px, transparent 8px, transparent 16px)",
                zIndex: 0,
              }}
            />

            <div className="grid grid-cols-1 md:grid-cols-4 gap-8 md:gap-6">
              {processSteps.map((step, index) => {
                const Icon = step.icon;
                return (
                  <ScrollReveal key={index} delay={index * 0.08}>
                    <div className="relative z-10">
                      {/* Process icon */}
                      <div
                        className="w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4"
                        style={{
                          border: "2px solid #C9A84C",
                          backgroundColor: "var(--color-card)",
                        }}
                      >
                        <Icon />
                      </div>

                      {/* Step content */}
                      <div className="text-center">
                        <h3
                          className="text-base mb-2"
                          style={{
                            fontFamily: "var(--font-body)",
                            fontWeight: 700,
                            color: "var(--color-foreground)",
                          }}
                        >
                          {step.title}
                        </h3>
                        <p
                          className="text-sm leading-relaxed"
                          style={{
                            fontFamily: "var(--font-body)",
                            color: "var(--color-foreground)",
                          }}
                        >
                          {step.description}
                        </p>
                      </div>
                    </div>
                  </ScrollReveal>
                );
              })}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
