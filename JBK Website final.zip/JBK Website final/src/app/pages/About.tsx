import { useState, useEffect } from "react";
import ScrollReveal from "../components/ScrollReveal";
import PullQuote from "../components/PullQuote";
import { motion } from "motion/react";
import gurudevshriImage from "../../imports/Pujya-Gurudevshri-1.jpg";
import jagdishbhaiImage from "../../imports/people/jagdishbhai-khokhani.jpg";
import maheshImage from "../../imports/people/mahesh-khokhani.jpg";
import dineshImage from "../../imports/people/dinesh-khokhani.jpg";
import mehulImage from "../../imports/people/mehul-khokhani.jpg";
import srlc10FoldImage from "../../imports/srlc-10fold.png";

export default function About() {
  const [lineVisible, setLineVisible] = useState(false);

  // SEO: Set page title and meta tags
  useEffect(() => {
    document.title = "About JBK | 60 Years of Pharmaceutical Excellence | J. B. Khokhani & Co.";

    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute("content", "Founded in 1965, J. B. Khokhani & Co. has built six decades of expertise in pharmaceutical API sourcing, quality assurance, and global distribution. Learn our story.");
    } else {
      const meta = document.createElement('meta');
      meta.name = "description";
      meta.content = "Founded in 1965, J. B. Khokhani & Co. has built six decades of expertise in pharmaceutical API sourcing, quality assurance, and global distribution. Learn our story.";
      document.head.appendChild(meta);
    }

    // Open Graph tags
    const ogTags = [
      { property: "og:title", content: "About JBK | 60 Years of Pharmaceutical Excellence | J. B. Khokhani & Co." },
      { property: "og:description", content: "Founded in 1965, J. B. Khokhani & Co. has built six decades of expertise in pharmaceutical API sourcing, quality assurance, and global distribution. Learn our story." },
      { property: "og:type", content: "website" },
      { property: "og:site_name", content: "J. B. Khokhani & Co." },
      { property: "og:url", content: "https://www.jbkhokhani.com/about" },
      { property: "og:image", content: "https://www.jbkhokhani.com/assets/1_without_background.png" },
    ];

    ogTags.forEach(({ property, content }) => {
      let tag = document.querySelector(`meta[property="${property}"]`);
      if (tag) {
        tag.setAttribute("content", content);
      } else {
        tag = document.createElement('meta');
        tag.setAttribute("property", property);
        tag.setAttribute("content", content);
        document.head.appendChild(tag);
      }
    });

    // Twitter Card tags
    const twitterTags = [
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "About JBK | 60 Years of Pharmaceutical Excellence | J. B. Khokhani & Co." },
      { name: "twitter:description", content: "Founded in 1965, J. B. Khokhani & Co. has built six decades of expertise in pharmaceutical API sourcing, quality assurance, and global distribution. Learn our story." },
      { name: "twitter:image", content: "https://www.jbkhokhani.com/assets/1_without_background.png" },
    ];

    twitterTags.forEach(({ name, content }) => {
      let tag = document.querySelector(`meta[name="${name}"]`);
      if (tag) {
        tag.setAttribute("content", content);
      } else {
        tag = document.createElement('meta');
        tag.setAttribute("name", name);
        tag.setAttribute("content", content);
        document.head.appendChild(tag);
      }
    });

    // Canonical link
    let canonical = document.querySelector('link[rel="canonical"]');
    if (canonical) {
      canonical.setAttribute("href", "https://www.jbkhokhani.com/about");
    } else {
      canonical = document.createElement('link');
      canonical.setAttribute("rel", "canonical");
      canonical.setAttribute("href", "https://www.jbkhokhani.com/about");
      document.head.appendChild(canonical);
    }

    // Add additional SEO tags
    const additionalTags = [
      { name: "robots", content: "index, follow" },
      { name: "author", content: "J. B. Khokhani & Co." },
      { name: "geo.region", content: "IN-MH" },
      { name: "geo.placename", content: "Mumbai" },
      { name: "geo.position", content: "19.0176;72.8562" },
      { name: "ICBM", content: "19.0176, 72.8562" },
    ];

    additionalTags.forEach(({ name, content }) => {
      let tag = document.querySelector(`meta[name="${name}"]`);
      if (tag) {
        tag.setAttribute("content", content);
      } else {
        tag = document.createElement('meta');
        tag.setAttribute("name", name);
        tag.setAttribute("content", content);
        document.head.appendChild(tag);
      }
    });
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      setLineVisible(true);
    }, 300);
    return () => clearTimeout(timer);
  }, []);

  const timeline = [
    {
      year: "1965",
      text: "Founded by Jagdishbhai B. Khokhani in Mumbai — beginning with domestic API distribution",
    },
    {
      year: "1980s",
      text: "Second generation joins — Mahesh, Dinesh, and Mehul J. Khokhani",
    },
    {
      year: "1990s",
      text: "Strategic depot network established across India for pan-India distribution",
    },
    {
      year: "2000s",
      text: "Expanded into export markets across Africa and the Middle East",
    },
    {
      year: "2010s",
      text: "Expanded into nutraceuticals and veterinary APIs — product range crosses 100+",
    },
    {
      year: "Today",
      text: "300+ client companies, 15+ countries, $50M+ group turnover",
    },
  ];

  const teamMembers: Array<{ name: string; role: string; initials: string; department: string; photo?: string; alt?: string }> = [
    {
      name: "Mahesh J. Khokhani",
      role: "Partner",
      initials: "MK",
      department: "Partners",
      photo: maheshImage,
      alt: "Mahesh J. Khokhani — Partner at J. B. Khokhani & Co., second-generation leadership overseeing pharmaceutical API sourcing and client relationships",
    },
    {
      name: "Dinesh J. Khokhani",
      role: "Partner",
      initials: "DK",
      department: "Partners",
      photo: dineshImage,
      alt: "Dinesh J. Khokhani — Partner at J. B. Khokhani & Co., second-generation leadership overseeing regulatory and quality documentation",
    },
    {
      name: "Mehul J. Khokhani",
      role: "Partner",
      initials: "MK",
      department: "Partners",
      photo: mehulImage,
      alt: "Mehul J. Khokhani — Partner at J. B. Khokhani & Co., second-generation leadership overseeing export markets and nutraceutical division",
    },
  ];

  const departments = Array.from(new Set(teamMembers.map((m) => m.department)));

  return (
    <div className="min-h-screen">
      {/* Our Story */}
      <section className="py-16 md:py-24 px-4 sm:px-6 lg:px-8 relative">
        <div
          className="absolute inset-0 dark:hidden"
          style={{
            backgroundImage: `repeating-linear-gradient(
              45deg,
              rgba(10, 22, 40, 0.04),
              rgba(10, 22, 40, 0.04) 1px,
              transparent 1px,
              transparent 20px
            ),
            repeating-linear-gradient(
              -45deg,
              rgba(10, 22, 40, 0.04),
              rgba(10, 22, 40, 0.04) 1px,
              transparent 1px,
              transparent 20px
            )`,
          }}
        />
        <div
          className="absolute inset-0 hidden dark:block"
          style={{
            backgroundImage: `repeating-linear-gradient(
              45deg,
              rgba(240, 244, 255, 0.03),
              rgba(240, 244, 255, 0.03) 1px,
              transparent 1px,
              transparent 20px
            ),
            repeating-linear-gradient(
              -45deg,
              rgba(240, 244, 255, 0.03),
              rgba(240, 244, 255, 0.03) 1px,
              transparent 1px,
              transparent 20px
            )`,
          }}
        />
        <div className="max-w-6xl mx-auto relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-[minmax(0,420px)_1fr] gap-10 lg:gap-14 items-start">
            {/* Founder Photo */}
            <ScrollReveal>
              <figure className="lg:sticky lg:top-28">
                <div
                  className="rounded-xl overflow-hidden shadow-2xl"
                  style={{ border: "3px solid #C9A84C" }}
                >
                  <img
                    src={jagdishbhaiImage}
                    alt="Jagdishbhai B. Khokhani — founder of J. B. Khokhani & Co., pharmaceutical API distributor established 1965 in Mumbai"
                    className="w-full h-auto object-cover"
                    loading="lazy"
                  />
                </div>
                <figcaption
                  className="mt-4 text-center"
                  style={{
                    fontFamily: "var(--font-mono)",
                    fontSize: "16px",
                    letterSpacing: "0.12em",
                    textTransform: "uppercase",
                    color: "#C9A84C",
                  }}
                >
                  Jagdishbhai B. Khokhani
                  <span
                    className="block mt-1"
                    style={{
                      fontFamily: "var(--font-body)",
                      letterSpacing: "0",
                      textTransform: "none",
                      color: "var(--color-muted-foreground)",
                      fontSize: "15px",
                    }}
                  >
                    Founder · Est. 1965
                  </span>
                </figcaption>
              </figure>
            </ScrollReveal>

            {/* Story Text */}
            <div className="space-y-6 text-lg leading-relaxed">
              <div
                className="uppercase mb-2"
                style={{
                  fontFamily: "var(--font-mono)",
                  letterSpacing: "0.15em",
                  color: "#C9A84C",
                  fontSize: "14px",
                }}
              >
                Our Story
              </div>
              <p style={{ color: "var(--color-foreground)" }}>
                <span style={{ color: "#C9A84C", fontWeight: 700 }}>J. B. Khokhani & Co.</span> was founded in 1965 by{" "}
                <span style={{ color: "var(--color-foreground)", fontWeight: 600, fontStyle: "italic" }}>Jagdishbhai B. Khokhani</span> in
                Mumbai, with a simple but powerful idea: be the most reliable link
                between pharmaceutical manufacturers and the companies that need
                their products.
              </p>
              <p style={{ color: "var(--color-foreground)" }}>
                Six decades later, that idea has grown into one of India's leading
                pharmaceutical trading and distribution firms — serving 300+
                clients across India and exporting to markets across Africa, the
                Middle East, Southeast Asia, and Europe.
              </p>
              <p style={{ color: "var(--color-foreground)" }}>
                Today, JBK is managed by the second generation of the Khokhani
                family — Mahesh, Dinesh, and Mehul J. Khokhani — who have expanded
                the company's reach while staying true to its founding values:
                reliability, quality, and long-term relationships.
              </p>
              <p
                className="text-xl"
                style={{
                  fontFamily: "var(--font-body)",
                  fontWeight: 700,
                  color: "var(--color-foreground)",
                }}
              >
                We sit at the intersection of manufacturing excellence and distribution expertise — combining deep supplier
                networks, regulatory expertise, and multi-market access to deliver
                end-to-end sourcing solutions.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Company Timeline */}
      <section
        className="py-16 md:py-24 px-4 sm:px-6 lg:px-8 relative"
        style={{ backgroundColor: "var(--color-section-bg)" }}
      >
        <div
          className="absolute inset-0 dark:hidden"
          style={{
            backgroundImage: `repeating-linear-gradient(
              45deg,
              rgba(10, 22, 40, 0.04),
              rgba(10, 22, 40, 0.04) 1px,
              transparent 1px,
              transparent 20px
            ),
            repeating-linear-gradient(
              -45deg,
              rgba(10, 22, 40, 0.04),
              rgba(10, 22, 40, 0.04) 1px,
              transparent 1px,
              transparent 20px
            )`,
          }}
        />
        <div
          className="absolute inset-0 hidden dark:block"
          style={{
            backgroundImage: `repeating-linear-gradient(
              45deg,
              rgba(240, 244, 255, 0.03),
              rgba(240, 244, 255, 0.03) 1px,
              transparent 1px,
              transparent 20px
            ),
            repeating-linear-gradient(
              -45deg,
              rgba(240, 244, 255, 0.03),
              rgba(240, 244, 255, 0.03) 1px,
              transparent 1px,
              transparent 20px
            )`,
          }}
        />
        <div className="max-w-4xl mx-auto relative z-10">
          <h2
            className="text-3xl md:text-4xl mb-16 text-center"
            style={{
              fontFamily: "var(--font-heading)",
              fontWeight: 700,
              color: "var(--color-foreground)",
            }}
          >
            Our Journey
          </h2>

          <div className="relative">
            {/* Timeline line */}
            <div
              className="absolute left-1/2 top-0 bottom-0 w-0.5 hidden md:block"
              style={{ backgroundColor: "#C9A84C", transform: "translateX(-50%)" }}
            />
            <div
              className="absolute left-4 top-0 bottom-0 w-0.5 md:hidden"
              style={{ backgroundColor: "#C9A84C" }}
            />

            {timeline.map((milestone, index) => (
              <ScrollReveal
                key={index}
                delay={index * 0.08}
                className={`mb-12 md:mb-16 flex items-center ${
                  index % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"
                }`}
              >
                <div className={`flex-1 ${index % 2 === 0 ? "md:pr-12 md:text-right" : "md:pl-12"} pl-12 md:pl-0`}>
                  <div
                    className="mb-2"
                    style={{
                      fontFamily: "var(--font-body)",
                      fontWeight: 700,
                      color: "#C9A84C",
                      fontSize: "16px",
                    }}
                  >
                    {milestone.year}
                  </div>
                  <p
                    className="text-lg"
                    style={{
                      fontFamily: "var(--font-body)",
                      color: "var(--color-foreground)",
                    }}
                  >
                    {milestone.text}
                  </p>
                </div>

                {/* Timeline node */}
                <div
                  className="absolute left-4 md:left-1/2 w-3 h-3 rounded-full"
                  style={{
                    backgroundColor: "#C9A84C",
                    transform: "translateX(-50%)",
                    animation: `scaleIn 0.4s cubic-bezier(0.16, 1, 0.3, 1) ${index * 0.08}s backwards`,
                  }}
                />

                <div className="flex-1 hidden md:block" />
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* Our Inspiration */}
      <section
        className="py-20 px-4 sm:px-6 lg:px-8 relative bg-[#EAE6DD] dark:bg-[#111E33]"
      >
        <div className="max-w-6xl mx-auto relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Image */}
            <div>
              <ScrollReveal delay={0.2}>
                <motion.a
                  href="https://www.srmd.org"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block"
                  whileHover={{ scale: 1.02 }}
                  transition={{ duration: 0.3 }}
                >
                  <div
                    className="rounded-xl overflow-hidden shadow-2xl"
                    style={{
                      border: "3px solid #C9A84C",
                    }}
                  >
                    <img
                      src={gurudevshriImage}
                      alt="Pujya Gurudevshri Rakeshji — Spiritual Guide, Shrimad Rajchandra Mission Dharampur"
                      className="w-full h-auto object-cover"
                      style={{
                        maxHeight: "600px",
                      }}
                    />
                  </div>
                </motion.a>
              </ScrollReveal>
            </div>

            {/* Text Content */}
            <div>
              <div
                className="uppercase mb-4 text-[20px]"
                style={{
                  fontFamily: "var(--font-mono)",
                  letterSpacing: "0.15em",
                  color: "#C9A84C",
                }}
              >
                Our Inspiration
              </div>
              <h2
                className="text-3xl md:text-[44px] mb-6"
                style={{
                  fontFamily: "var(--font-heading)",
                  fontWeight: 700,
                  color: "var(--color-foreground)",
                }}
              >
                Guided by Timeless Values
              </h2>
              <div className="space-y-6 text-lg leading-[1.85]" style={{ fontFamily: "var(--font-body)" }}>
                <p style={{ color: "var(--color-foreground)" }}>
                  At <span style={{ color: "#C9A84C", fontWeight: 700 }}>J. B. Khokhani & Co.</span>, business is not just about transactions —
                  it is about how we conduct ourselves in every one of them.
                </p>
                <p style={{ color: "var(--color-foreground)" }}>
                  Our work is guided by the teachings of Pujya Gurudevshri Rakeshji,
                  an enlightened spiritual master, visionary, and the founder of
                  Shrimad Rajchandra Mission Dharampur (
                  <a
                    href="https://www.srmd.org"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="underline hover:opacity-80"
                    style={{ color: "#C9A84C" }}
                  >
                    www.srmd.org
                  </a>
                  ) — a global spiritual organisation with over 206 centres across
                  six continents.
                </p>
                <p style={{ color: "var(--color-foreground)" }}>
                  Pujya Gurudevshri's teachings centre on inner transformation,
                  integrity, compassion, and selfless service. He teaches that true
                  progress — in life and in work — comes not from what we achieve,
                  but from how we achieve it.
                </p>
                <p style={{ color: "var(--color-foreground)" }}>
                  These principles are not separate from how we do business. They are
                  the foundation of it.
                </p>
              </div>

              {/* Pull Quote */}
              <PullQuote className="italic my-8 text-[#0A1628] dark:text-[#F0F4FF]">
                <div
                  style={{
                    fontFamily: "var(--font-heading)",
                    fontWeight: 700,
                    fontSize: "26px",
                  }}
                >
                  "The way you conduct yourself in every interaction is a reflection of
                  your inner values."
                </div>
              </PullQuote>

              <p
                className="text-lg leading-[1.85]"
                style={{ fontFamily: "var(--font-body)", color: "var(--color-foreground)" }}
              >
                At JBK, this translates into the way we treat our clients, our
                suppliers, and our partners — with honesty, accountability, and a
                genuine commitment to their success.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ═══════════════ C8 · A Commitment to Care ═══════════════ */}
      <section className="py-16 md:py-24 px-4 sm:px-6 lg:px-8 relative">
        <div
          className="absolute inset-0 dark:hidden pointer-events-none"
          style={{
            backgroundImage: `repeating-linear-gradient(45deg, rgba(10, 22, 40, 0.04), rgba(10, 22, 40, 0.04) 1px, transparent 1px, transparent 20px), repeating-linear-gradient(-45deg, rgba(10, 22, 40, 0.04), rgba(10, 22, 40, 0.04) 1px, transparent 1px, transparent 20px)`,
          }}
        />
        <div
          className="absolute inset-0 hidden dark:block pointer-events-none"
          style={{
            backgroundImage: `repeating-linear-gradient(45deg, rgba(240, 244, 255, 0.03), rgba(240, 244, 255, 0.03) 1px, transparent 1px, transparent 20px), repeating-linear-gradient(-45deg, rgba(240, 244, 255, 0.03), rgba(240, 244, 255, 0.03) 1px, transparent 1px, transparent 20px)`,
          }}
        />

        <div className="max-w-4xl mx-auto relative z-10">
          <ScrollReveal>
            <div className="text-center mb-10">
              <div
                className="inline-flex items-center gap-3 mb-4"
                style={{
                  fontFamily: "var(--font-mono)",
                  fontSize: "13px",
                  letterSpacing: "0.2em",
                  textTransform: "uppercase",
                  color: "#C9A84C",
                  fontWeight: 500,
                }}
              >
                <span style={{ width: "24px", height: "1px", background: "#C9A84C" }} />
                Giving Back
                <span style={{ width: "24px", height: "1px", background: "#C9A84C" }} />
              </div>

              <h2
                className="text-3xl md:text-5xl mb-5"
                style={{
                  fontFamily: "var(--font-heading)",
                  fontWeight: 700,
                  letterSpacing: "-0.012em",
                  color: "var(--color-foreground)",
                }}
              >
                A Commitment to Care
              </h2>

              <p
                className="mx-auto"
                style={{
                  fontFamily: "var(--font-body)",
                  fontSize: "19px",
                  lineHeight: 1.55,
                  color: "var(--color-muted-foreground)",
                  maxWidth: "620px",
                }}
              >
                One of the most meaningful humanitarian initiatives of our time — and one we&apos;re privileged to support.
              </p>
            </div>
          </ScrollReveal>

          <ScrollReveal>
            <div
              className="mx-auto mb-10"
              style={{
                maxWidth: "760px",
                fontSize: "18px",
                lineHeight: 1.75,
                color: "var(--color-foreground)",
              }}
            >
              <p className="mb-5">
                Shrimad Rajchandra Love and Care (SRLC) is a global humanitarian initiative inspired by Shrimad Rajchandraji and guided by Pujya Gurudevshri Rakeshji. Its work spans ten care categories — from health and education to women&apos;s empowerment, animal welfare, and environmental care — and has touched over 21 million lives worldwide.
              </p>
              <p className="mb-0">
                <span style={{ color: "#C9A84C", fontWeight: 700 }}>J. B. Khokhani &amp; Co.</span> is proud to be associated with SRLC. The scope, the consistency, and the care with which it operates make it, in our view, a rare example of humanitarian work done well at scale — worth knowing about, whether one is connected to it or not.
              </p>
            </div>
          </ScrollReveal>

          {/* Stats grid */}
          <ScrollReveal>
            <div
              className="mx-auto mb-12 grid grid-cols-2 md:grid-cols-4 gap-4"
              style={{ maxWidth: "1000px" }}
            >
              <SrlcStatCard num="21M+" label="Lives Touched Globally" />
              <SrlcStatCard num="10" label="Care Categories · Health to Environment" />
              <SrlcStatCard num="UN" label="ECOSOC Special Consultative Status (2020)" />
              <SrlcStatCard num="13×" label="Highest Fundraising NGO · Tata Mumbai Marathon" />
            </div>
          </ScrollReveal>

          {/* 10-fold illustration card — cream island in both modes */}
          <ScrollReveal>
            <a
              href="https://loveandcare.srmd.org/"
              target="_blank"
              rel="noopener noreferrer"
              className="srlc-10fold block mx-auto text-center transition-all duration-200"
              style={{
                maxWidth: "640px",
                padding: "48px 40px 40px",
                borderRadius: "16px",
                background: "#FAF7F0",
                border: "1px solid rgba(201, 168, 76, 0.22)",
                boxShadow: "0 12px 36px rgba(10, 22, 40, 0.08)",
                textDecoration: "none",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = "translateY(-3px)";
                e.currentTarget.style.boxShadow = "0 24px 56px rgba(10, 22, 40, 0.14)";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = "translateY(0)";
                e.currentTarget.style.boxShadow = "0 12px 36px rgba(10, 22, 40, 0.08)";
              }}
            >
              <div
                style={{
                  fontFamily: "var(--font-mono)",
                  fontSize: "11.5px",
                  letterSpacing: "0.18em",
                  textTransform: "uppercase",
                  color: "#6B8F71",
                  fontWeight: 500,
                  marginBottom: "22px",
                }}
              >
                Unique 10-Fold Benevolent Programme
              </div>
              <h3
                style={{
                  fontFamily: "var(--font-heading)",
                  fontWeight: 600,
                  fontSize: "22px",
                  lineHeight: 1.25,
                  color: "#0A1628",
                  margin: "0 0 6px",
                }}
              >
                Shrimad Rajchandra Love and Care
              </h3>
              <img
                src={srlc10FoldImage}
                alt="SRLC's 10-fold programme: Environmental Care, Emergency Relief Care, Health Care, Educational Care, Child Care, Woman Care, Tribal Care, Community Care, Humanitarian Care, Animal Care"
                style={{
                  maxWidth: "100%",
                  height: "auto",
                  display: "block",
                  margin: "0 auto",
                }}
              />
              <div
                style={{
                  marginTop: "24px",
                  fontFamily: "var(--font-body)",
                  fontSize: "13.5px",
                  fontWeight: 500,
                  color: "#9A7D2E",
                  letterSpacing: "0.02em",
                }}
              >
                Explore SRLC&apos;s work →
              </div>
            </a>
          </ScrollReveal>
        </div>
      </section>

      {/* The Team */}
      <section className="py-16 md:py-24 px-4 sm:px-6 lg:px-8 relative">
        <div
          className="absolute inset-0 dark:hidden"
          style={{
            backgroundImage: `repeating-linear-gradient(
              45deg,
              rgba(10, 22, 40, 0.04),
              rgba(10, 22, 40, 0.04) 1px,
              transparent 1px,
              transparent 20px
            ),
            repeating-linear-gradient(
              -45deg,
              rgba(10, 22, 40, 0.04),
              rgba(10, 22, 40, 0.04) 1px,
              transparent 1px,
              transparent 20px
            )`,
          }}
        />
        <div
          className="absolute inset-0 hidden dark:block"
          style={{
            backgroundImage: `repeating-linear-gradient(
              45deg,
              rgba(240, 244, 255, 0.03),
              rgba(240, 244, 255, 0.03) 1px,
              transparent 1px,
              transparent 20px
            ),
            repeating-linear-gradient(
              -45deg,
              rgba(240, 244, 255, 0.03),
              rgba(240, 244, 255, 0.03) 1px,
              transparent 1px,
              transparent 20px
            )`,
          }}
        />
        <div className="max-w-6xl mx-auto relative z-10">
          <h2
            className="text-3xl md:text-[40px] mb-4"
            style={{
              fontFamily: "var(--font-heading)",
              fontWeight: 700,
              color: "var(--color-foreground)",
            }}
          >
            The Faces of <span style={{ color: "#C9A84C", fontWeight: 700 }}>J. B. Khokhani & Co.</span>
          </h2>

          <p
            className="text-lg mb-12"
            style={{
              fontFamily: "var(--font-body)",
              color: "var(--color-muted-foreground)",
            }}
          >
            Six decades of trust, built by people who care.
          </p>

          {departments.map((department) => (
            <div key={department} className="mb-12">
              <h3
                className="uppercase mb-6 text-[20px]"
                style={{
                  fontFamily: "var(--font-body)",
                  fontWeight: 700,
                  letterSpacing: "0.1em",
                  color: "#C9A84C",
                }}
              >
                {department}
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                {teamMembers
                  .filter((m) => m.department === department)
                  .map((member, index) => (
                    <ScrollReveal key={index} delay={index * 0.08}>
                      <div
                        className="rounded-xl overflow-hidden transition-all duration-300"
                        style={{
                          backgroundColor: "var(--color-card)",
                          border: "1px solid var(--color-border)",
                        }}
                        onMouseEnter={(e) => {
                          e.currentTarget.style.transform = "translateY(-6px)";
                          e.currentTarget.style.boxShadow =
                            "0 12px 40px rgba(10,22,40,0.12)";
                          e.currentTarget.style.transition = "all 0.25s cubic-bezier(0.16, 1, 0.3, 1)";
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.transform = "translateY(0)";
                          e.currentTarget.style.boxShadow = "none";
                          e.currentTarget.style.transition = "all 0.25s cubic-bezier(0.16, 1, 0.3, 1)";
                        }}
                      >
                        {/* Photo Area */}
                        <div
                          className="w-full aspect-square overflow-hidden"
                          style={{ backgroundColor: "#0A1628" }}
                        >
                          {member.photo ? (
                            <img
                              src={member.photo}
                              alt={member.alt || `${member.name} — ${member.role} at J. B. Khokhani & Co.`}
                              loading="lazy"
                              className="w-full h-full object-cover transition-transform duration-500"
                              style={{ objectPosition: "center top" }}
                              onMouseEnter={(e) => {
                                (e.currentTarget as HTMLImageElement).style.transform = "scale(1.04)";
                              }}
                              onMouseLeave={(e) => {
                                (e.currentTarget as HTMLImageElement).style.transform = "scale(1)";
                              }}
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center">
                              <div
                                className="text-5xl"
                                style={{
                                  fontFamily: "var(--font-heading)",
                                  fontWeight: 700,
                                  color: "#C9A84C",
                                }}
                              >
                                {member.initials}
                              </div>
                            </div>
                          )}
                        </div>

                        {/* Details */}
                        <div className="p-5">
                          <h3
                            className="mb-2 text-[20px]"
                            style={{
                              fontFamily: "var(--font-heading)",
                              fontWeight: 600,
                              color: "var(--color-foreground)",
                            }}
                          >
                            {member.name}
                          </h3>
                          <div
                            className="uppercase text-[14px]"
                            style={{
                              fontFamily: "var(--font-mono)",
                              letterSpacing: "0.08em",
                              color: "#C9A84C",
                            }}
                          >
                            {member.role}
                          </div>
                        </div>
                      </div>
                    </ScrollReveal>
                  ))}
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

/* ─────────── C8 · SRLC stat card helper ─────────── */

function SrlcStatCard({ num, label }: { num: string; label: string }) {
  return (
    <div
      className="text-center transition-colors"
      style={{
        padding: "22px 14px",
        border: "1px solid rgba(201, 168, 76, 0.3)",
        background: "rgba(201, 168, 76, 0.04)",
        borderRadius: "10px",
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.borderColor = "rgba(201, 168, 76, 0.55)";
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.borderColor = "rgba(201, 168, 76, 0.3)";
      }}
    >
      <div
        style={{
          fontFamily: "var(--font-heading)",
          fontWeight: 700,
          fontSize: "clamp(28px, 3.6vw, 40px)",
          color: "#C9A84C",
          lineHeight: 1,
          marginBottom: "10px",
        }}
      >
        {num}
      </div>
      <div
        style={{
          width: "32px",
          height: "1px",
          background: "rgba(201, 168, 76, 0.5)",
          margin: "0 auto 10px",
        }}
      />
      <div
        style={{
          fontFamily: "var(--font-body)",
          fontSize: "12.5px",
          lineHeight: 1.4,
          color: "var(--color-muted-foreground)",
        }}
      >
        {label}
      </div>
    </div>
  );
}
