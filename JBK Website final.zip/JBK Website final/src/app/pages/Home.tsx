import { Link } from "react-router";
import { useEffect, useRef, useState } from "react";
import { ArrowRight, Building, Users, ShieldCheck, MapPin, FileCheck, Globe, Pill, Heart, Shield, Leaf, Syringe, Stethoscope } from "lucide-react";
import PullQuote from "../components/PullQuote";
import HeroCarousel from "../components/HeroCarousel";
import { categories } from "../data/categories";
import { BrowseAllIcon } from "../components/icons/CategoryIcons";
import productsData from "../data/products.json";

// Derived at build time from products.json — must never drift from the data.
const TOTAL_PRODUCT_COUNT = productsData.length;

export default function Home() {
  const [statsVisible, setStatsVisible] = useState(false);
  const statsRef = useRef<HTMLDivElement>(null);
  const [underlineVisible, setUnderlineVisible] = useState(false);

  // SEO: Set page title and meta tags
  useEffect(() => {
    document.title = "JBK — Pharmaceutical API Supplier Since 1965 | J. B. Khokhani & Co.";

    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute("content", "J. B. Khokhani & Co. is a trusted pharmaceutical API supplier with 60+ years of experience. Supplying 240+ pharmaceutical ingredients to 300+ clients across 60+ countries. IP, BP, EP, USP, WHO-GMP certified.");
    } else {
      const meta = document.createElement('meta');
      meta.name = "description";
      meta.content = "J. B. Khokhani & Co. is a trusted pharmaceutical API supplier with 60+ years of experience. Supplying 240+ pharmaceutical ingredients to 300+ clients across 60+ countries. IP, BP, EP, USP, WHO-GMP certified.";
      document.head.appendChild(meta);
    }

    // Add Open Graph tags
    const ogTags = [
      { property: "og:title", content: "JBK — Pharmaceutical API Supplier Since 1965 | J. B. Khokhani & Co." },
      { property: "og:description", content: "J. B. Khokhani & Co. is a trusted pharmaceutical API supplier with 60+ years of experience. Supplying 240+ pharmaceutical ingredients to 300+ clients across 60+ countries. IP, BP, EP, USP, WHO-GMP certified." },
      { property: "og:type", content: "website" },
      { property: "og:site_name", content: "J. B. Khokhani & Co." },
      { property: "og:url", content: "https://www.jbkhokhani.com" },
      { property: "og:image", content: "https://www.jbkhokhani.com/assets/1_without_background.png" },
    ];

    ogTags.forEach(({ property, content }) => {
      let tag = document.querySelector(`meta[property="${property}"]`);
      if (tag) {
        tag.setAttribute("content", content);
      } else {
        tag = document.createElement('meta');
        tag.setAttribute("property", property);
        tag.setAttribute("content", content);
        document.head.appendChild(tag);
      }
    });

    // Add Twitter Card tags
    const twitterTags = [
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "JBK — Pharmaceutical API Supplier Since 1965 | J. B. Khokhani & Co." },
      { name: "twitter:description", content: "J. B. Khokhani & Co. is a trusted pharmaceutical API supplier with 60+ years of experience. Supplying 240+ pharmaceutical ingredients to 300+ clients across 60+ countries. IP, BP, EP, USP, WHO-GMP certified." },
      { name: "twitter:image", content: "https://www.jbkhokhani.com/assets/1_without_background.png" },
    ];

    twitterTags.forEach(({ name, content }) => {
      let tag = document.querySelector(`meta[name="${name}"]`);
      if (tag) {
        tag.setAttribute("content", content);
      } else {
        tag = document.createElement('meta');
        tag.setAttribute("name", name);
        tag.setAttribute("content", content);
        document.head.appendChild(tag);
      }
    });

    // Add additional SEO tags
    const additionalTags = [
      { name: "robots", content: "index, follow" },
      { name: "author", content: "J. B. Khokhani & Co." },
      { name: "geo.region", content: "IN-MH" },
      { name: "geo.placename", content: "Mumbai" },
      { name: "geo.position", content: "19.0176;72.8562" },
      { name: "ICBM", content: "19.0176, 72.8562" },
    ];

    additionalTags.forEach(({ name, content }) => {
      let tag = document.querySelector(`meta[name="${name}"]`);
      if (tag) {
        tag.setAttribute("content", content);
      } else {
        tag = document.createElement('meta');
        tag.setAttribute("name", name);
        tag.setAttribute("content", content);
        document.head.appendChild(tag);
      }
    });

    // Add canonical link
    let canonical = document.querySelector('link[rel="canonical"]');
    if (canonical) {
      canonical.setAttribute("href", "https://www.jbkhokhani.com/");
    } else {
      canonical = document.createElement('link');
      canonical.setAttribute("rel", "canonical");
      canonical.setAttribute("href", "https://www.jbkhokhani.com/");
      document.head.appendChild(canonical);
    }

    // Add JSON-LD Organization schema
    let schemaScript = document.querySelector('script[data-schema="organization"]');
    if (!schemaScript) {
      schemaScript = document.createElement('script');
      schemaScript.setAttribute('type', 'application/ld+json');
      schemaScript.setAttribute('data-schema', 'organization');
      schemaScript.textContent = JSON.stringify({
        "@context": "https://schema.org",
        "@type": "Organization",
        "name": "J. B. Khokhani & Co.",
        "alternateName": "JBK",
        "url": "https://www.jbkhokhani.com",
        "foundingDate": "1965",
        "description": "Pharmaceutical API supplier and distributor with 60+ years of experience. Supplying 240+ pharmaceutical ingredients to 300+ clients across 60+ countries.",
        "address": {
          "@type": "PostalAddress",
          "streetAddress": "B-207, Neelam Centre, Hind Cycle Road, Behind Doordarshan Tower, Worli",
          "addressLocality": "Mumbai",
          "postalCode": "400030",
          "addressCountry": "IN"
        },
        "contactPoint": [
          {
            "@type": "ContactPoint",
            "telephone": "+91-22-40441234",
            "contactType": "customer service",
            "availableLanguage": ["English", "Hindi"]
          },
          {
            "@type": "ContactPoint",
            "email": "info@jbkhokhani.com",
            "contactType": "sales"
          }
        ],
        "foundingLocation": {
          "@type": "Place",
          "name": "Mumbai, India"
        }
      });
      document.head.appendChild(schemaScript);
    }

    // Set lang attribute on html element
    document.documentElement.setAttribute('lang', 'en');
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setStatsVisible(true);
        }
      },
      { threshold: 0.3 }
    );

    if (statsRef.current) {
      observer.observe(statsRef.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      setUnderlineVisible(true);
    }, 500);
    return () => clearTimeout(timer);
  }, []);

  const Counter = ({ end, suffix = "" }: { end: number; suffix?: string }) => {
    const [count, setCount] = useState(0);

    useEffect(() => {
      if (!statsVisible) return;

      let start = 0;
      const duration = 2000;
      const increment = end / (duration / 16);

      const timer = setInterval(() => {
        start += increment;
        if (start >= end) {
          setCount(end);
          clearInterval(timer);
        } else {
          setCount(Math.floor(start));
        }
      }, 16);

      return () => clearInterval(timer);
    }, [statsVisible, end]);

    return (
      <span>
        {count}
        {suffix}
      </span>
    );
  };

  return (
    <div className="min-h-screen">
      {/* Hero + Scroll-driven Carousel Morph */}
      <HeroCarousel>
        {/* Hero Section */}
        <section
          className="relative h-full flex items-center px-4 sm:px-6 lg:px-8 overflow-hidden"
          style={{
            backgroundColor: "var(--color-background)",
          }}
        >
        <div
          className="absolute inset-0 hidden dark:block pointer-events-none"
          style={{
            backgroundImage: `repeating-linear-gradient(
              45deg,
              rgba(201, 168, 76, 0.05),
              rgba(201, 168, 76, 0.05) 1px,
              transparent 1px,
              transparent 20px
            ),
            repeating-linear-gradient(
              -45deg,
              rgba(201, 168, 76, 0.05),
              rgba(201, 168, 76, 0.05) 1px,
              transparent 1px,
              transparent 20px
            )`,
          }}
        />
        <div
          className="absolute inset-0 dark:hidden pointer-events-none"
          style={{
            backgroundImage: `repeating-linear-gradient(
              45deg,
              rgba(10, 22, 40, 0.08),
              rgba(10, 22, 40, 0.08) 1px,
              transparent 1px,
              transparent 20px
            ),
            repeating-linear-gradient(
              -45deg,
              rgba(10, 22, 40, 0.08),
              rgba(10, 22, 40, 0.08) 1px,
              transparent 1px,
              transparent 20px
            )`,
          }}
        />
        <div className="max-w-6xl mx-auto">
          <div className="space-y-6 max-w-4xl mx-auto text-center">
            {/* Label */}
            <div className="flex items-center justify-center gap-4 mb-6">
              <div
                className="h-px flex-grow max-w-24"
                style={{ backgroundColor: "#C9A84C" }}
              />
              <div
                className="text-sm md:text-base uppercase"
                style={{
                  fontFamily: "var(--font-mono)",
                  letterSpacing: "0.15em",
                  color: "#C9A84C",
                  fontSize: "14px",
                }}
              >
                <span className="md:text-[16px]">Pharmaceutical API Supplier · Est. 1965</span>
              </div>
              <div
                className="h-px flex-grow max-w-24"
                style={{ backgroundColor: "#C9A84C" }}
              />
            </div>

            {/* Main Headline */}
            <div>
              <h1
                className="text-4xl md:text-[68px] leading-tight"
                style={{
                  fontFamily: "var(--font-heading)",
                  fontWeight: 700,
                  color: "var(--color-foreground)",
                }}
              >
                Your trusted partner in pharmaceutical supply
              </h1>
              {/* Animated Underline */}
              <div className="flex justify-center mt-4">
                <div
                  className="h-0.5 transition-all duration-800"
                  style={{
                    backgroundColor: "#C9A84C",
                    width: underlineVisible ? "80px" : "0px",
                    transitionTimingFunction: "ease-out",
                  }}
                />
              </div>
            </div>

            {/* Subheadline */}
            <p
              className="text-lg md:text-xl max-w-[600px] mx-auto"
              style={{
                fontFamily: "var(--font-body)",
                lineHeight: 1.8,
                color: "var(--color-foreground)",
                marginTop: "32px",
                marginBottom: "32px",
              }}
            >
              Over 60 years connecting the world's pharmaceutical industry
              with quality APIs, ingredients, and sourcing solutions — from
              India and beyond.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4 relative z-10">
              <Link
                to="/products"
                className="inline-flex items-center justify-center transition-all duration-200 hover:scale-[1.03] active:scale-[0.98]"
                style={{
                  fontFamily: "var(--font-body)",
                  fontWeight: 500,
                  fontSize: "16px",
                  padding: "14px 32px",
                  backgroundColor: "#C4714A",
                  color: "#FFFFFF",
                  borderRadius: "4px",
                  opacity: 1,
                  pointerEvents: "auto",
                }}
              >
                Explore Products <span style={{ marginLeft: "6px" }}>→</span>
              </Link>
              <Link
                to="/contact"
                className="inline-flex items-center justify-center transition-all duration-200 border-[1.5px] border-[#0A1628] text-[#0A1628] dark:border-[#C9A84C] dark:text-[#C9A84C] hover:bg-[#C9A84C] hover:text-[#0A1628] hover:border-[#C9A84C]"
                style={{
                  fontFamily: "var(--font-body)",
                  fontWeight: 500,
                  fontSize: "16px",
                  padding: "14px 32px",
                  borderRadius: "4px",
                  backgroundColor: "#FFFFFF",
                  opacity: 1,
                  pointerEvents: "auto",
                }}
              >
                Get in Touch
              </Link>
            </div>
          </div>
        </div>
      </section>
      </HeroCarousel>

      {/* Stats Bar */}
      <section
        ref={statsRef}
        className="py-12 bg-[#0A1628] dark:bg-[#C9A84C]"
      >
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-0">
            {/* Stat 1 */}
            <div className="text-center py-12 md:border-r border-r-[rgba(201,168,76,0.3)] dark:border-r-[rgba(10,22,40,0.3)]">
              <div
                className="text-6xl md:text-7xl mb-3 text-[#C9A84C] dark:text-[#0A1628]"
                style={{
                  fontFamily: "var(--font-heading)",
                  fontWeight: 700,
                }}
              >
                {statsVisible && <Counter end={60} suffix="+" />}
              </div>
              <div
                className="text-sm uppercase text-[#C9A84C] dark:text-[#0A1628]"
                style={{
                  fontFamily: "var(--font-body)",
                  fontWeight: 500,
                  letterSpacing: "0.08em",
                }}
              >
                Years in Business
              </div>
            </div>

            {/* Stat 2 */}
            <div className="text-center py-12 border-t border-t-[rgba(201,168,76,0.3)] dark:border-t-[rgba(10,22,40,0.3)] md:border-t-0 md:border-r border-r-[rgba(201,168,76,0.3)] dark:border-r-[rgba(10,22,40,0.3)]">
              <div
                className="text-6xl md:text-7xl mb-3 text-[#C9A84C] dark:text-[#0A1628]"
                style={{
                  fontFamily: "var(--font-heading)",
                  fontWeight: 700,
                }}
              >
                {statsVisible && <Counter end={240} suffix="+" />}
              </div>
              <div
                className="text-sm uppercase text-[#C9A84C] dark:text-[#0A1628]"
                style={{
                  fontFamily: "var(--font-body)",
                  fontWeight: 500,
                  letterSpacing: "0.08em",
                }}
              >
                Products
              </div>
            </div>

            {/* Stat 3 */}
            <div className="text-center py-12 border-t border-t-[rgba(201,168,76,0.3)] dark:border-t-[rgba(10,22,40,0.3)] md:border-t-0">
              <div
                className="text-6xl md:text-7xl mb-3 text-[#C9A84C] dark:text-[#0A1628]"
                style={{
                  fontFamily: "var(--font-heading)",
                  fontWeight: 700,
                }}
              >
                {statsVisible && <Counter end={300} suffix="+" />}
              </div>
              <div
                className="text-sm uppercase text-[#C9A84C] dark:text-[#0A1628]"
                style={{
                  fontFamily: "var(--font-body)",
                  fontWeight: 500,
                  letterSpacing: "0.08em",
                }}
              >
                Client Companies
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Product Range — therapeutic category grid + browse-all CTA card */}
      <section className="py-16 md:py-24 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12 max-w-3xl mx-auto">
            <h2
              className="text-4xl md:text-[44px] mb-6"
              style={{
                fontFamily: "var(--font-heading)",
                fontWeight: 700,
                color: "var(--color-foreground)",
              }}
            >
              Our Product Range
            </h2>
            <p
              className="text-base md:text-lg"
              style={{
                fontFamily: "var(--font-body)",
                color: "var(--color-foreground)",
              }}
            >
              240+ pharmaceutical APIs, veterinary products, and nutraceutical
              ingredients — sourced from India's leading manufacturers and
              global suppliers.
            </p>
          </div>

          {/*
            4 × 3 on desktop · 3 cols on tablet · 2 cols on mobile.
            CTA card spans the full row on every breakpoint so the "+1"
            never leaves a lonely cell and always reads as an intentional
            continuation of the grid rather than a dangling thirteenth tile.
          */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-5">
            {categories.map((category) => {
              const { id, name, href, Icon } = category;
              return (
                <Link
                  key={id}
                  to={href}
                  className="group block rounded-xl p-5 md:p-6 flex flex-col items-center text-center transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-[#C9A84C] focus:ring-offset-2"
                  style={{
                    backgroundColor: "var(--color-card)",
                    border: "1px solid rgba(201,168,76,0.15)",
                    boxShadow: "0 2px 12px rgba(0,0,0,0.05)",
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.transform = "translateY(-4px)";
                    e.currentTarget.style.boxShadow = "0 10px 28px rgba(0,0,0,0.12)";
                    e.currentTarget.style.borderColor = "rgba(201,168,76,0.6)";
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.transform = "translateY(0)";
                    e.currentTarget.style.boxShadow = "0 2px 12px rgba(0,0,0,0.05)";
                    e.currentTarget.style.borderColor = "rgba(201,168,76,0.15)";
                  }}
                >
                  <Icon className="w-12 h-12 mb-4" />
                  <h3
                    style={{
                      fontFamily: "var(--font-body)",
                      fontWeight: 500,
                      fontSize: "15px",
                      lineHeight: "1.35",
                      color: "var(--color-foreground)",
                    }}
                  >
                    {name}
                  </h3>
                </Link>
              );
            })}

            {/* Browse-all CTA card — spans full grid width at every breakpoint */}
            <Link
              to="/products"
              className="group col-span-2 md:col-span-3 lg:col-span-4 block rounded-xl p-5 md:p-6 transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-[#C9A84C] focus:ring-offset-2"
              style={{
                backgroundColor: "var(--color-card)",
                border: "1px solid rgba(201,168,76,0.25)",
                boxShadow: "0 2px 12px rgba(0,0,0,0.05)",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = "translateY(-4px)";
                e.currentTarget.style.boxShadow = "0 10px 28px rgba(0,0,0,0.12)";
                e.currentTarget.style.borderColor = "rgba(201,168,76,0.7)";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = "translateY(0)";
                e.currentTarget.style.boxShadow = "0 2px 12px rgba(0,0,0,0.05)";
                e.currentTarget.style.borderColor = "rgba(201,168,76,0.25)";
              }}
            >
              <div className="flex flex-col md:flex-row items-center md:justify-between gap-4 md:gap-6">
                <div className="flex flex-col md:flex-row items-center gap-4 md:gap-5">
                  <BrowseAllIcon className="w-12 h-12 flex-shrink-0" />
                  <div className="text-center md:text-left">
                    <h3
                      style={{
                        fontFamily: "var(--font-heading)",
                        fontWeight: 700,
                        fontSize: "20px",
                        color: "var(--color-foreground)",
                      }}
                    >
                      Browse all {TOTAL_PRODUCT_COUNT} products
                    </h3>
                    <p
                      className="mt-1"
                      style={{
                        fontFamily: "var(--font-body)",
                        fontSize: "14px",
                        color: "var(--color-foreground)",
                        opacity: 0.72,
                      }}
                    >
                      APIs · Nutraceuticals · Veterinary
                    </p>
                  </div>
                </div>
                <ArrowRight
                  className="w-6 h-6 transition-transform duration-200 group-hover:translate-x-1 flex-shrink-0"
                  style={{ color: "#C9A84C" }}
                />
              </div>
            </Link>
          </div>
        </div>
      </section>

      {/* What We Do */}
      <section className="py-16 md:py-24 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16">
            <div
              className="uppercase mb-4 text-[14px] md:text-[16px]"
              style={{
                fontFamily: "var(--font-mono)",
                letterSpacing: "0.15em",
                color: "#C9A84C",
              }}
            >
              Our Capabilities
            </div>
            <h2
              className="text-4xl md:text-[44px] mb-6"
              style={{
                fontFamily: "var(--font-heading)",
                fontWeight: 700,
                color: "var(--color-foreground)",
              }}
            >
              What We Do
            </h2>
            <div className="flex justify-center">
              <div
                className="h-0.5 w-16"
                style={{ backgroundColor: "#C9A84C" }}
              />
            </div>
          </div>

          {/* Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Card 1 */}
            <div
              className="transition-all flex flex-col"
              style={{
                backgroundColor: "var(--color-card)",
                borderRadius: "8px",
                border: "1px solid var(--color-border)",
                position: "relative",
                padding: "32px",
                boxShadow: "0 2px 16px rgba(10,22,40,0.07)",
                transitionDuration: "0.25s",
                transitionTimingFunction: "cubic-bezier(0.16, 1, 0.3, 1)",
                minHeight: "280px",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = "translateY(-6px)";
                e.currentTarget.style.boxShadow = "0 12px 40px rgba(10,22,40,0.12)";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = "translateY(0)";
                e.currentTarget.style.boxShadow = "0 2px 16px rgba(10,22,40,0.07)";
              }}
            >
              <svg width="22" height="22" viewBox="0 0 22 22"
                style={{ position: "absolute", top: "12px", left: "12px", pointerEvents: "none" }}
                aria-hidden="true">
                <path d="M2 22 L2 2 L22 2" stroke="#C9A84C" strokeWidth="1.5" fill="none" />

              </svg>

              <div
                className="w-16 h-16 rounded-full flex items-center justify-center mb-6"
                style={{ backgroundColor: "var(--color-section-bg)", marginLeft: "12px", marginTop: "8px" }}
              >
                <ShieldCheck style={{ color: "#C9A84C", width: "36px", height: "36px" }} strokeWidth={1.5} />
              </div>
              <h3
                className="text-xl mb-4"
                style={{
                  fontFamily: "var(--font-heading)",
                  fontWeight: 600,
                  color: "var(--color-foreground)",
                }}
              >
                API Trading & Distribution
              </h3>
              <p
                style={{
                  fontFamily: "var(--font-body)",
                  fontSize: "15px",
                  lineHeight: 1.75,
                  color: "var(--color-muted-foreground)",
                }}
              >
                We supply Active Pharmaceutical Ingredients, bulk drug
                intermediates, nutraceuticals, and veterinary drugs — sourced
                from trusted manufacturers across India, China, Europe, and the
                USA.
              </p>
            </div>

            {/* Card 2 */}
            <div
              className="transition-all flex flex-col"
              style={{
                backgroundColor: "var(--color-card)",
                borderRadius: "8px",
                border: "1px solid var(--color-border)",
                position: "relative",
                padding: "32px",
                boxShadow: "0 2px 16px rgba(10,22,40,0.07)",
                transitionDuration: "0.25s",
                transitionTimingFunction: "cubic-bezier(0.16, 1, 0.3, 1)",
                minHeight: "280px",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = "translateY(-6px)";
                e.currentTarget.style.boxShadow = "0 12px 40px rgba(10,22,40,0.12)";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = "translateY(0)";
                e.currentTarget.style.boxShadow = "0 2px 16px rgba(10,22,40,0.07)";
              }}
            >
              <svg width="22" height="22" viewBox="0 0 22 22"
                style={{ position: "absolute", top: "12px", left: "12px", pointerEvents: "none" }}
                aria-hidden="true">
                <path d="M2 22 L2 2 L22 2" stroke="#C9A84C" strokeWidth="1.5" fill="none" />

              </svg>

              <div
                className="w-16 h-16 rounded-full flex items-center justify-center mb-6"
                style={{ backgroundColor: "var(--color-section-bg)", marginLeft: "12px", marginTop: "8px" }}
              >
                <Globe style={{ color: "#C9A84C", width: "36px", height: "36px" }} strokeWidth={1.5} />
              </div>
              <h3
                className="text-xl mb-4"
                style={{
                  fontFamily: "var(--font-heading)",
                  fontWeight: 600,
                  color: "var(--color-foreground)",
                }}
              >
                Global Sourcing & Indenting
              </h3>
              <p
                style={{
                  fontFamily: "var(--font-body)",
                  fontSize: "15px",
                  lineHeight: 1.75,
                  color: "var(--color-muted-foreground)",
                }}
              >
                We act as your sourcing office in India. Whether you're an
                international buyer or a domestic formulator, we connect you to
                the right supply at the right price.
              </p>
            </div>

            {/* Card 3 */}
            <div
              className="transition-all flex flex-col"
              style={{
                backgroundColor: "var(--color-card)",
                borderRadius: "8px",
                border: "1px solid var(--color-border)",
                position: "relative",
                padding: "32px",
                boxShadow: "0 2px 16px rgba(10,22,40,0.07)",
                transitionDuration: "0.25s",
                transitionTimingFunction: "cubic-bezier(0.16, 1, 0.3, 1)",
                height: "auto",
                overflow: "visible",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = "translateY(-6px)";
                e.currentTarget.style.boxShadow = "0 12px 40px rgba(10,22,40,0.12)";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = "translateY(0)";
                e.currentTarget.style.boxShadow = "0 2px 16px rgba(10,22,40,0.07)";
              }}
            >
              <svg width="22" height="22" viewBox="0 0 22 22"
                style={{ position: "absolute", top: "12px", left: "12px", pointerEvents: "none" }}
                aria-hidden="true">
                <path d="M2 22 L2 2 L22 2" stroke="#C9A84C" strokeWidth="1.5" fill="none" />

              </svg>

              <div
                className="w-16 h-16 rounded-full flex items-center justify-center mb-6"
                style={{ backgroundColor: "var(--color-section-bg)", marginLeft: "12px", marginTop: "8px" }}
              >
                <FileCheck style={{ color: "#C9A84C", width: "36px", height: "36px" }} strokeWidth={1.5} />
              </div>
              <h3
                className="text-xl mb-4"
                style={{
                  fontFamily: "var(--font-heading)",
                  fontWeight: 600,
                  color: "var(--color-foreground)",
                }}
              >
                Regulatory & Documentation Support
              </h3>
              <p
                style={{
                  fontFamily: "var(--font-body)",
                  fontSize: "15px",
                  lineHeight: 1.75,
                  color: "var(--color-muted-foreground)",
                }}
              >
                From DMF filings to GMP-compliant documentation, we help you
                navigate the paperwork so your supply chain stays compliant and
                audit-ready.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Why JBK */}
      <section
        className="py-16 md:py-24 px-4 sm:px-6 lg:px-8"
        style={{ backgroundColor: "var(--color-section-bg)" }}
      >
        <div className="max-w-6xl mx-auto">
          {/* Pull Quote */}
          <PullQuote className="text-2xl md:text-3xl italic mb-12 max-w-3xl">
            <div
              style={{
                fontFamily: "var(--font-heading)",
                fontWeight: 700,
                color: "var(--color-foreground)",
              }}
            >
              "We don't just supply ingredients — we build supply chains."
            </div>
          </PullQuote>

          {/* Trust Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Card 1 */}
            <div
              className="p-7 rounded-lg"
              style={{
                backgroundColor: "var(--color-card)",
                border: "1px solid var(--color-border)",
              }}
            >
              <Building
                style={{ color: "#C9A84C", width: "28px", height: "28px", marginBottom: "16px" }}
                strokeWidth={1.5}
              />
              <h3
                className="text-lg mb-2"
                style={{
                  fontFamily: "var(--font-body)",
                  fontWeight: 700,
                  color: "var(--color-foreground)",
                }}
              >
                Established 1965, Mumbai
              </h3>
              <p
                className="text-sm"
                style={{
                  fontFamily: "var(--font-body)",
                  color: "var(--color-muted-foreground)",
                }}
              >
                Six decades of pharmaceutical supply expertise
              </p>
            </div>

            {/* Card 2 */}
            <div
              className="p-7 rounded-lg"
              style={{
                backgroundColor: "var(--color-card)",
                border: "1px solid var(--color-border)",
              }}
            >
              <Users
                style={{ color: "#C9A84C", width: "28px", height: "28px", marginBottom: "16px" }}
                strokeWidth={1.5}
              />
              <h3
                className="text-lg mb-2"
                style={{
                  fontFamily: "var(--font-body)",
                  fontWeight: 700,
                  color: "var(--color-foreground)",
                }}
              >
                300+ Client Companies
              </h3>
              <p
                className="text-sm"
                style={{
                  fontFamily: "var(--font-body)",
                  color: "var(--color-muted-foreground)",
                }}
              >
                Serving pharma firms across India and 15+ countries
              </p>
            </div>

            {/* Card 3 */}
            <div
              className="p-7 rounded-lg"
              style={{
                backgroundColor: "var(--color-card)",
                border: "1px solid var(--color-border)",
              }}
            >
              <ShieldCheck
                style={{ color: "#C9A84C", width: "28px", height: "28px", marginBottom: "16px" }}
                strokeWidth={1.5}
              />
              <h3
                className="text-lg mb-2"
                style={{
                  fontFamily: "var(--font-body)",
                  fontWeight: 700,
                  color: "var(--color-foreground)",
                }}
              >
                GMP-Compliant Sourcing
              </h3>
              <p
                className="text-sm"
                style={{
                  fontFamily: "var(--font-body)",
                  color: "var(--color-muted-foreground)",
                }}
              >
                Multi-stage quality checks from source to delivery
              </p>
            </div>

            {/* Card 4 */}
            <div
              className="p-7 rounded-lg"
              style={{
                backgroundColor: "var(--color-card)",
                border: "1px solid var(--color-border)",
              }}
            >
              <MapPin
                style={{ color: "#C9A84C", width: "28px", height: "28px", marginBottom: "16px" }}
                strokeWidth={1.5}
              />
              <h3
                className="text-lg mb-2"
                style={{
                  fontFamily: "var(--font-body)",
                  fontWeight: 700,
                  color: "var(--color-foreground)",
                }}
              >
                Multi-Location Presence
              </h3>
              <p
                className="text-sm"
                style={{
                  fontFamily: "var(--font-body)",
                  color: "var(--color-muted-foreground)",
                }}
              >
                Depots in Bhiwandi, Baddi, and Haridwar
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Inquiry CTA Banner */}
      <section
        className="py-20 px-4 sm:px-6 lg:px-8 bg-[#0A1628] dark:bg-[#C9A84C]"
      >
        <div className="max-w-4xl mx-auto text-center">
          <h2
            className="text-3xl md:text-[40px] mb-6"
            style={{
              fontFamily: "var(--font-heading)",
              fontWeight: 700,
            }}
          >
            <span className="text-[#F4F1EC] dark:text-[#0A1628]">
              Can't find what you're looking for?
            </span>
          </h2>
          <p
            className="text-lg mb-8 max-w-[520px] mx-auto text-[#F4F1EC] dark:text-[#0A1628]"
            style={{
              fontFamily: "var(--font-body)",
            }}
          >
            We source beyond our listed products. Tell us what you need.
          </p>
          <Link
            to="/contact"
            className="inline-flex items-center transition-all duration-200 bg-[#C9A84C] text-[#0A1628] dark:bg-[#0A1628] dark:text-[#C9A84C] group hover:scale-[1.03] active:scale-[0.98]"
            style={{
              fontFamily: "var(--font-body)",
              fontWeight: 500,
              fontSize: "16px",
              padding: "16px 36px",
              borderRadius: "4px",
            }}
          >
            Submit a Sourcing Request
            <ArrowRight className="ml-2 w-5 h-5 transition-transform duration-200 group-hover:translate-x-1" />
          </Link>
        </div>
      </section>
    </div>
  );
}
