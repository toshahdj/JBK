import { useState, useEffect } from "react";
import { useSearchParams } from "react-router";
import { MapPin, Phone, Mail, Globe } from "lucide-react";
import ScrollReveal from "../components/ScrollReveal";
import { projectId, publicAnonKey } from "../../../utils/supabase/info";

export default function Contact() {
  const [searchParams] = useSearchParams();
  const [formData, setFormData] = useState({
    name: "",
    company: "",
    email: "",
    phone: "",
    country: "",
    inquiryType: "Product Inquiry",
    message: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<"success" | "error" | null>(null);

  // Pre-fill form when arriving from a Request-Sample CTA (e.g. from the
  // Nutraceuticals flagship block on /products). Reads ?product=<slug>
  // and optionally ?productName=<free text> when product=other.
  useEffect(() => {
    const productSlug = searchParams.get("product");
    if (!productSlug) return;

    const slugToLabel: Record<string, string> = {
      "pine-d3": "PineD3™ — Vegan Vitamin D3",
      menaquingold: "MenaquinGold® — Natural Vitamin K2-7",
      "caffeine-anhydrous": "Caffeine Anhydrous",
    };

    let productLabel = "";
    if (productSlug === "other") {
      const productName = searchParams.get("productName") ?? "";
      productLabel = productName.trim();
    } else {
      productLabel = slugToLabel[productSlug] ?? "";
    }

    if (!productLabel) return;

    setFormData((prev) => ({
      ...prev,
      inquiryType: "Sample Request",
      message: prev.message
        ? prev.message
        : `I would like to request a sample of ${productLabel}.\n\n`,
    }));
  }, [searchParams]);

  // SEO: Set page title and meta tags
  useEffect(() => {
    document.title = "Contact JBK | Request a Quote or Sample | J. B. Khokhani & Co.";

    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute("content", "Get in touch with J. B. Khokhani & Co. for pharmaceutical API enquiries, sample requests, pricing, and regulatory documentation. Based in Mumbai, India.");
    } else {
      const meta = document.createElement('meta');
      meta.name = "description";
      meta.content = "Get in touch with J. B. Khokhani & Co. for pharmaceutical API enquiries, sample requests, pricing, and regulatory documentation. Based in Mumbai, India.";
      document.head.appendChild(meta);
    }

    // Open Graph tags
    const ogTags = [
      { property: "og:title", content: "Contact JBK | Request a Quote or Sample | J. B. Khokhani & Co." },
      { property: "og:description", content: "Get in touch with J. B. Khokhani & Co. for pharmaceutical API enquiries, sample requests, pricing, and regulatory documentation. Based in Mumbai, India." },
      { property: "og:type", content: "website" },
      { property: "og:site_name", content: "J. B. Khokhani & Co." },
      { property: "og:url", content: "https://www.jbkhokhani.com/contact" },
      { property: "og:image", content: "https://www.jbkhokhani.com/assets/1_without_background.png" },
    ];

    ogTags.forEach(({ property, content }) => {
      let tag = document.querySelector(`meta[property="${property}"]`);
      if (tag) {
        tag.setAttribute("content", content);
      } else {
        tag = document.createElement('meta');
        tag.setAttribute("property", property);
        tag.setAttribute("content", content);
        document.head.appendChild(tag);
      }
    });

    // Twitter Card tags
    const twitterTags = [
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "Contact JBK | Request a Quote or Sample | J. B. Khokhani & Co." },
      { name: "twitter:description", content: "Get in touch with J. B. Khokhani & Co. for pharmaceutical API enquiries, sample requests, pricing, and regulatory documentation. Based in Mumbai, India." },
      { name: "twitter:image", content: "https://www.jbkhokhani.com/assets/1_without_background.png" },
    ];

    twitterTags.forEach(({ name, content }) => {
      let tag = document.querySelector(`meta[name="${name}"]`);
      if (tag) {
        tag.setAttribute("content", content);
      } else {
        tag = document.createElement('meta');
        tag.setAttribute("name", name);
        tag.setAttribute("content", content);
        document.head.appendChild(tag);
      }
    });

    // Canonical link
    let canonical = document.querySelector('link[rel="canonical"]');
    if (canonical) {
      canonical.setAttribute("href", "https://www.jbkhokhani.com/contact");
    } else {
      canonical = document.createElement('link');
      canonical.setAttribute("rel", "canonical");
      canonical.setAttribute("href", "https://www.jbkhokhani.com/contact");
      document.head.appendChild(canonical);
    }

    // Add additional SEO tags
    const additionalTags = [
      { name: "robots", content: "index, follow" },
      { name: "author", content: "J. B. Khokhani & Co." },
      { name: "geo.region", content: "IN-MH" },
      { name: "geo.placename", content: "Mumbai" },
      { name: "geo.position", content: "19.0176;72.8562" },
      { name: "ICBM", content: "19.0176, 72.8562" },
    ];

    additionalTags.forEach(({ name, content }) => {
      let tag = document.querySelector(`meta[name="${name}"]`);
      if (tag) {
        tag.setAttribute("content", content);
      } else {
        tag = document.createElement('meta');
        tag.setAttribute("name", name);
        tag.setAttribute("content", content);
        document.head.appendChild(tag);
      }
    });
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitStatus(null);

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-c285fd22/send-email`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify({
            formType: "contact",
            ...formData,
          }),
        }
      );

      const data = await response.json();

      if (response.ok) {
        setSubmitStatus("success");
        setFormData({
          name: "",
          company: "",
          email: "",
          phone: "",
          country: "",
          inquiryType: "Product Inquiry",
          message: "",
        });
      } else {
        console.error("Email sending failed:", data);
        setSubmitStatus("error");
      }
    } catch (error) {
      console.error("Error submitting form:", error);
      setSubmitStatus("error");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleInputChange = (
    e: React.ChangeEvent<
      HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
    >
  ) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 relative">
        <div
          className="absolute inset-0 dark:hidden"
          style={{
            backgroundImage: `repeating-linear-gradient(
              45deg,
              rgba(10, 22, 40, 0.04),
              rgba(10, 22, 40, 0.04) 1px,
              transparent 1px,
              transparent 20px
            ),
            repeating-linear-gradient(
              -45deg,
              rgba(10, 22, 40, 0.04),
              rgba(10, 22, 40, 0.04) 1px,
              transparent 1px,
              transparent 20px
            )`,
          }}
        />
        <div
          className="absolute inset-0 hidden dark:block"
          style={{
            backgroundImage: `repeating-linear-gradient(
              45deg,
              rgba(240, 244, 255, 0.03),
              rgba(240, 244, 255, 0.03) 1px,
              transparent 1px,
              transparent 20px
            ),
            repeating-linear-gradient(
              -45deg,
              rgba(240, 244, 255, 0.03),
              rgba(240, 244, 255, 0.03) 1px,
              transparent 1px,
              transparent 20px
            )`,
          }}
        />
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <h1
            className="text-4xl md:text-6xl mb-6"
            style={{
              fontFamily: "var(--font-heading)",
              fontWeight: 700,
              color: "var(--color-foreground)",
            }}
          >
            Let's Talk
          </h1>
          <p
            className="text-lg md:text-xl"
            style={{ color: "var(--color-foreground)" }}
          >
            Whether you're looking to source a product, explore a partnership, or
            just have a question — we'd love to hear from you.
          </p>
        </div>
      </section>

      {/* Contact Form & Info */}
      <section className="pb-16 md:pb-24 px-4 sm:px-6 lg:px-8 relative">
        <div
          className="absolute inset-0 dark:hidden"
          style={{
            backgroundImage: `repeating-linear-gradient(
              45deg,
              rgba(10, 22, 40, 0.04),
              rgba(10, 22, 40, 0.04) 1px,
              transparent 1px,
              transparent 20px
            ),
            repeating-linear-gradient(
              -45deg,
              rgba(10, 22, 40, 0.04),
              rgba(10, 22, 40, 0.04) 1px,
              transparent 1px,
              transparent 20px
            )`,
          }}
        />
        <div
          className="absolute inset-0 hidden dark:block"
          style={{
            backgroundImage: `repeating-linear-gradient(
              45deg,
              rgba(240, 244, 255, 0.03),
              rgba(240, 244, 255, 0.03) 1px,
              transparent 1px,
              transparent 20px
            ),
            repeating-linear-gradient(
              -45deg,
              rgba(240, 244, 255, 0.03),
              rgba(240, 244, 255, 0.03) 1px,
              transparent 1px,
              transparent 20px
            )`,
          }}
        />
        <div className="max-w-6xl mx-auto relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
            {/* Info panel (LEFT) — combined map + reach-us in a single card */}
            <ScrollReveal delay={0.1} className="h-full">
              <div
                className="rounded-lg overflow-hidden flex flex-col h-full"
                style={{
                  backgroundColor: "var(--color-card)",
                  border: "1px solid var(--color-border)",
                }}
              >
                <iframe
                  src="https://maps.google.com/maps?width=600&height=400&hl=en&q=j%20b%20khokhani&t=&z=15&ie=UTF8&iwloc=B&output=embed"
                  width="100%"
                  style={{
                    border: 0,
                    borderBottom: "1px solid var(--color-border)",
                    display: "block",
                    width: "100%",
                    flex: "1 1 auto",
                    minHeight: "300px",
                  }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="J. B. Khokhani & Co. office location — B-207 Neelam Centre, Worli, Mumbai"
                />
                <div className="p-6">
                  <div
                    style={{
                      fontFamily: "var(--font-mono)",
                      fontSize: "12px",
                      letterSpacing: "0.16em",
                      color: "#C9A84C",
                      textTransform: "uppercase",
                      fontWeight: 500,
                      marginBottom: "14px",
                    }}
                  >
                    Reach us
                  </div>
                  <div className="flex items-start gap-3 mb-4">
                    <MapPin
                      className="w-5 h-5 mt-0.5 flex-shrink-0"
                      style={{ color: "#C9A84C" }}
                      strokeWidth={1.6}
                    />
                    <div>
                      <div
                        style={{
                          fontWeight: 500,
                          color: "var(--color-foreground)",
                          marginBottom: "2px",
                        }}
                      >
                        Address
                      </div>
                      <div
                        style={{
                          color: "var(--color-foreground)",
                          fontSize: "14px",
                          lineHeight: 1.55,
                        }}
                      >
                        B-207, Neelam Centre
                        <br />
                        Hind Cycle Road
                        <br />
                        Behind Doordarshan Tower
                        <br />
                        Worli, Mumbai — 400030
                      </div>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 mb-4">
                    <Phone
                      className="w-5 h-5 mt-0.5 flex-shrink-0"
                      style={{ color: "#C9A84C" }}
                      strokeWidth={1.6}
                    />
                    <div>
                      <div
                        style={{
                          fontWeight: 500,
                          color: "var(--color-foreground)",
                          marginBottom: "2px",
                        }}
                      >
                        Phone
                      </div>
                      <a
                        href="tel:+912240441234"
                        style={{ color: "var(--color-foreground)", fontSize: "14px" }}
                      >
                        +91 22 4044 1234
                      </a>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Mail
                      className="w-5 h-5 mt-0.5 flex-shrink-0"
                      style={{ color: "#C9A84C" }}
                      strokeWidth={1.6}
                    />
                    <div>
                      <div
                        style={{
                          fontWeight: 500,
                          color: "var(--color-foreground)",
                          marginBottom: "2px",
                        }}
                      >
                        Email
                      </div>
                      <a
                        href="mailto:info@jbkhokhani.com"
                        style={{ color: "var(--color-foreground)", fontSize: "14px" }}
                      >
                        info@jbkhokhani.com
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </ScrollReveal>

            {/* Contact Form (RIGHT) — wrapped in matching card */}
            <ScrollReveal delay={0.1} className="h-full">
              <div
                className="rounded-lg p-6 md:p-8 h-full"
                style={{
                  backgroundColor: "var(--color-card)",
                  border: "1px solid var(--color-border)",
                }}
              >
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="contact-name"
                      className="block mb-2"
                      style={{ color: "var(--color-foreground)" }}
                    >
                      Name *
                    </label>
                    <input id="contact-name"
                      type="text"
                      name="name"
                      required
                      value={formData.name}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 rounded"
                      style={{
                        backgroundColor: "var(--color-input-background)",
                        border: "1px solid var(--color-border)",
                        color: "var(--color-foreground)",
                      }}
                    />
                  </div>
                  <div>
                    <label htmlFor="contact-company"
                      className="block mb-2"
                      style={{ color: "var(--color-foreground)" }}
                    >
                      Company Name *
                    </label>
                    <input id="contact-company"
                      type="text"
                      name="company"
                      required
                      value={formData.company}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 rounded"
                      style={{
                        backgroundColor: "var(--color-input-background)",
                        border: "1px solid var(--color-border)",
                        color: "var(--color-foreground)",
                      }}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="contact-email"
                      className="block mb-2"
                      style={{ color: "var(--color-foreground)" }}
                    >
                      Email Address *
                    </label>
                    <input id="contact-email"
                      type="email"
                      name="email"
                      required
                      value={formData.email}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 rounded"
                      style={{
                        backgroundColor: "var(--color-input-background)",
                        border: "1px solid var(--color-border)",
                        color: "var(--color-foreground)",
                      }}
                    />
                  </div>
                  <div>
                    <label htmlFor="contact-phone"
                      className="block mb-2"
                      style={{ color: "var(--color-foreground)" }}
                    >
                      Phone Number
                    </label>
                    <input id="contact-phone"
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 rounded"
                      style={{
                        backgroundColor: "var(--color-input-background)",
                        border: "1px solid var(--color-border)",
                        color: "var(--color-foreground)",
                      }}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="contact-country"
                      className="block mb-2"
                      style={{ color: "var(--color-foreground)" }}
                    >
                      Country
                    </label>
                    <input id="contact-country"
                      type="text"
                      name="country"
                      value={formData.country}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 rounded"
                      style={{
                        backgroundColor: "var(--color-input-background)",
                        border: "1px solid var(--color-border)",
                        color: "var(--color-foreground)",
                      }}
                    />
                  </div>
                  <div>
                    <label htmlFor="contact-inquiryType"
                      className="block mb-2"
                      style={{ color: "var(--color-foreground)" }}
                    >
                      Inquiry Type
                    </label>
                    <select id="contact-inquiryType"
                      name="inquiryType"
                      value={formData.inquiryType}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 rounded"
                      style={{
                        backgroundColor: "var(--color-input-background)",
                        border: "1px solid var(--color-border)",
                        color: "var(--color-foreground)",
                      }}
                    >
                      <option>Product Inquiry</option>
                      <option>Custom Sourcing Request</option>
                      <option>Partnership</option>
                      <option>General</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label htmlFor="contact-message"
                    className="block mb-2"
                    style={{ color: "var(--color-foreground)" }}
                  >
                    Message *
                  </label>
                    <textarea id="contact-message"
                    name="message"
                    rows={6}
                    required
                    value={formData.message}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 rounded"
                    style={{
                      backgroundColor: "var(--color-input-background)",
                      border: "1px solid var(--color-border)",
                      color: "var(--color-foreground)",
                    }}
                  />
                </div>

                <div className="space-y-4">
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="px-8 py-4 text-white rounded hover:scale-110 transition-all duration-300 shadow-md hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
                    style={{ backgroundColor: "var(--color-accent-terracotta)" }}
                  >
                    {isSubmitting ? "Sending..." : "Send Message"}
                  </button>

                  {submitStatus === "success" && (
                    <p
                      className="text-green-600 font-medium"
                      style={{ color: "#059669" }}
                    >
                      ✓ Message sent successfully! We'll get back to you within 24-48 hours.
                    </p>
                  )}

                  {submitStatus === "error" && (
                    <p
                      className="text-red-600 font-medium"
                      style={{ color: "#dc2626" }}
                    >
                      ✗ Failed to send message. Please try again or email us directly at info@jbkhokhani.com
                    </p>
                  )}
                </div>
              </form>
              </div>
            </ScrollReveal>

          </div>
        </div>
      </section>
    </div>
  );
}
