import { useState, useEffect, useRef } from "react";

export default function Presence() {
  const [statsVisible, setStatsVisible] = useState(false);
  const statsRef = useRef<HTMLDivElement>(null);

  // SEO: Set page title and meta tags
  useEffect(() => {
    document.title = "Global Presence | API Exports to 60+ Countries | J. B. Khokhani & Co.";

    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute("content", "J. B. Khokhani & Co. exports pharmaceutical APIs to clients across Europe, the Americas, Southeast Asia, the Middle East, and Africa. Sourcing from India, China, and Europe.");
    } else {
      const meta = document.createElement('meta');
      meta.name = "description";
      meta.content = "J. B. Khokhani & Co. exports pharmaceutical APIs to clients across Europe, the Americas, Southeast Asia, the Middle East, and Africa. Sourcing from India, China, and Europe.";
      document.head.appendChild(meta);
    }

    // Open Graph tags
    const ogTags = [
      { property: "og:title", content: "Global Presence | API Exports to 60+ Countries | J. B. Khokhani & Co." },
      { property: "og:description", content: "J. B. Khokhani & Co. exports pharmaceutical APIs to clients across Europe, the Americas, Southeast Asia, the Middle East, and Africa. Sourcing from India, China, and Europe." },
      { property: "og:type", content: "website" },
      { property: "og:site_name", content: "J. B. Khokhani & Co." },
      { property: "og:url", content: "https://www.jbkhokhani.com/presence" },
      { property: "og:image", content: "https://www.jbkhokhani.com/assets/1_without_background.png" },
    ];

    ogTags.forEach(({ property, content }) => {
      let tag = document.querySelector(`meta[property="${property}"]`);
      if (tag) {
        tag.setAttribute("content", content);
      } else {
        tag = document.createElement('meta');
        tag.setAttribute("property", property);
        tag.setAttribute("content", content);
        document.head.appendChild(tag);
      }
    });

    // Twitter Card tags
    const twitterTags = [
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "Global Presence | API Exports to 60+ Countries | J. B. Khokhani & Co." },
      { name: "twitter:description", content: "J. B. Khokhani & Co. exports pharmaceutical APIs to clients across Europe, the Americas, Southeast Asia, the Middle East, and Africa. Sourcing from India, China, and Europe." },
      { name: "twitter:image", content: "https://www.jbkhokhani.com/assets/1_without_background.png" },
    ];

    twitterTags.forEach(({ name, content }) => {
      let tag = document.querySelector(`meta[name="${name}"]`);
      if (tag) {
        tag.setAttribute("content", content);
      } else {
        tag = document.createElement('meta');
        tag.setAttribute("name", name);
        tag.setAttribute("content", content);
        document.head.appendChild(tag);
      }
    });

    // Canonical link
    let canonical = document.querySelector('link[rel="canonical"]');
    if (canonical) {
      canonical.setAttribute("href", "https://www.jbkhokhani.com/presence");
    } else {
      canonical = document.createElement('link');
      canonical.setAttribute("rel", "canonical");
      canonical.setAttribute("href", "https://www.jbkhokhani.com/presence");
      document.head.appendChild(canonical);
    }

    // Add additional SEO tags
    const additionalTags = [
      { name: "robots", content: "index, follow" },
      { name: "author", content: "J. B. Khokhani & Co." },
      { name: "geo.region", content: "IN-MH" },
      { name: "geo.placename", content: "Mumbai" },
      { name: "geo.position", content: "19.0176;72.8562" },
      { name: "ICBM", content: "19.0176, 72.8562" },
    ];

    additionalTags.forEach(({ name, content }) => {
      let tag = document.querySelector(`meta[name="${name}"]`);
      if (tag) {
        tag.setAttribute("content", content);
      } else {
        tag = document.createElement('meta');
        tag.setAttribute("name", name);
        tag.setAttribute("content", content);
        document.head.appendChild(tag);
      }
    });
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setStatsVisible(true);
        }
      },
      { threshold: 0.3 }
    );

    if (statsRef.current) {
      observer.observe(statsRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const Counter = ({ end, suffix = "" }: { end: number; suffix?: string }) => {
    const [count, setCount] = useState(0);

    useEffect(() => {
      if (!statsVisible) return;

      let start = 0;
      const duration = 2000;
      const increment = end / (duration / 16);

      const timer = setInterval(() => {
        start += increment;
        if (start >= end) {
          setCount(end);
          clearInterval(timer);
        } else {
          setCount(Math.floor(start));
        }
      }, 16);

      return () => clearInterval(timer);
    }, [statsVisible, end]);

    return (
      <span>
        {count}
        {suffix}
      </span>
    );
  };

  const sourcingRegions = [
    {
      country: "India",
      flagCode: "in",
      flagAlt: "India — Primary pharmaceutical API manufacturing source",
      description: "Primary manufacturing base — APIs, intermediates, and finished formulations",
    },
    {
      country: "China",
      flagCode: "cn",
      flagAlt: "China — API and nutraceutical ingredient source",
      description: "APIs and nutraceutical ingredients at competitive pricing",
    },
    {
      country: "Europe",
      flagCode: "eu",
      flagAlt: "Europe — Specialty pharmaceutical ingredient source",
      description: "Specialty ingredients and branded products for regulated markets",
    },
    {
      country: "USA",
      flagCode: "us",
      flagAlt: "USA — Regulated-market grade pharmaceutical materials",
      description: "Regulated-market grade materials with full documentation",
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Stats Band */}
      <section
        ref={statsRef}
        className="py-12"
        style={{
          backgroundColor: "#0A1628",
        }}
      >
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-0">
            {/* Stat 1 */}
            <div className="text-center py-12 md:border-r md:border-r-[rgba(201,168,76,0.3)]">
              <div
                className="text-6xl md:text-7xl mb-3"
                style={{
                  fontFamily: "var(--font-heading)",
                  fontWeight: 700,
                  color: "#C9A84C",
                }}
              >
                {statsVisible && <Counter end={60} suffix="+" />}
              </div>
              <div
                className="text-sm uppercase"
                style={{
                  fontFamily: "var(--font-body)",
                  fontWeight: 500,
                  letterSpacing: "0.08em",
                  color: "#FFFFFF",
                }}
              >
                Countries We Export To
              </div>
            </div>

            {/* Stat 2 */}
            <div className="text-center py-12 border-t border-t-[rgba(201,168,76,0.3)] md:border-t-0 md:border-r md:border-r-[rgba(201,168,76,0.3)]">
              <div
                className="text-6xl md:text-7xl mb-3"
                style={{
                  fontFamily: "var(--font-heading)",
                  fontWeight: 700,
                  color: "#C9A84C",
                }}
              >
                {statsVisible && <Counter end={5} />}
              </div>
              <div
                className="text-sm uppercase"
                style={{
                  fontFamily: "var(--font-body)",
                  fontWeight: 500,
                  letterSpacing: "0.08em",
                  color: "#FFFFFF",
                }}
              >
                Continents Reached
              </div>
            </div>

            {/* Stat 3 */}
            <div className="text-center py-12 border-t border-t-[rgba(201,168,76,0.3)] md:border-t-0">
              <div
                className="text-6xl md:text-7xl mb-3"
                style={{
                  fontFamily: "var(--font-heading)",
                  fontWeight: 700,
                  color: "#C9A84C",
                }}
              >
                {statsVisible && <Counter end={300} suffix="+" />}
              </div>
              <div
                className="text-sm uppercase"
                style={{
                  fontFamily: "var(--font-body)",
                  fontWeight: 500,
                  letterSpacing: "0.08em",
                  color: "#FFFFFF",
                }}
              >
                Client Companies Worldwide
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Where We Export */}
      <section className="py-16 md:py-24 px-4 sm:px-6 lg:px-8 relative">
        <div
          className="absolute inset-0 dark:hidden"
          style={{
            backgroundImage: `repeating-linear-gradient(
              45deg,
              rgba(10, 22, 40, 0.04),
              rgba(10, 22, 40, 0.04) 1px,
              transparent 1px,
              transparent 20px
            ),
            repeating-linear-gradient(
              -45deg,
              rgba(10, 22, 40, 0.04),
              rgba(10, 22, 40, 0.04) 1px,
              transparent 1px,
              transparent 20px
            )`,
          }}
        />
        <div
          className="absolute inset-0 hidden dark:block"
          style={{
            backgroundImage: `repeating-linear-gradient(
              45deg,
              rgba(240, 244, 255, 0.03),
              rgba(240, 244, 255, 0.03) 1px,
              transparent 1px,
              transparent 20px
            ),
            repeating-linear-gradient(
              -45deg,
              rgba(240, 244, 255, 0.03),
              rgba(240, 244, 255, 0.03) 1px,
              transparent 1px,
              transparent 20px
            )`,
          }}
        />
        <div className="max-w-5xl mx-auto relative z-10">
          <h2
            className="text-3xl md:text-4xl mb-12 text-center"
            style={{
              fontFamily: "var(--font-heading)",
              fontWeight: 700,
              color: "var(--color-foreground)",
            }}
          >
            Where We Export
          </h2>

          {/* Large Stat */}
          <div className="text-center mb-8">
            <div
              className="text-7xl mb-3"
              style={{
                fontFamily: "var(--font-heading)",
                fontWeight: 700,
                color: "#C9A84C",
              }}
            >
              60+
            </div>
            <p
              className="text-base"
              style={{
                fontFamily: "var(--font-body)",
                fontWeight: 500,
                color: "var(--color-foreground)",
              }}
            >
              Countries Served
            </p>
          </div>

          {/* Region Tiles */}
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3 md:gap-4 mt-8 max-w-3xl mx-auto">
            {["Europe", "Americas", "Middle East", "Southeast Asia", "Africa", "Australia"].map((region) => (
              <div
                key={region}
                className="rounded transition-all duration-200"
                style={{
                  backgroundColor: "var(--color-card)",
                  border: "1px solid var(--color-border)",
                  padding: "20px 18px",
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = "translateY(-2px)";
                  e.currentTarget.style.borderColor = "rgba(201, 168, 76, 0.5)";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = "translateY(0)";
                  e.currentTarget.style.borderColor = "var(--color-border)";
                }}
              >
                <div
                  style={{
                    fontFamily: "var(--font-heading)",
                    fontSize: "19px",
                    fontWeight: 600,
                    color: "var(--color-foreground)",
                    lineHeight: 1.2,
                    marginBottom: "10px",
                  }}
                >
                  {region}
                </div>
                <div
                  aria-hidden="true"
                  style={{
                    height: "1px",
                    width: "32px",
                    backgroundColor: "#C9A84C",
                  }}
                />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ═══════════════ C9 · Exhibitions ═══════════════ */}
      <section
        className="py-16 md:py-24 px-4 sm:px-6 lg:px-8 relative"
        style={{ backgroundColor: "var(--color-section-bg)" }}
      >
        <div
          className="absolute inset-0 dark:hidden"
          style={{
            backgroundImage: `repeating-linear-gradient(45deg, rgba(10, 22, 40, 0.04), rgba(10, 22, 40, 0.04) 1px, transparent 1px, transparent 20px), repeating-linear-gradient(-45deg, rgba(10, 22, 40, 0.04), rgba(10, 22, 40, 0.04) 1px, transparent 1px, transparent 20px)`,
          }}
        />
        <div
          className="absolute inset-0 hidden dark:block"
          style={{
            backgroundImage: `repeating-linear-gradient(45deg, rgba(240, 244, 255, 0.03), rgba(240, 244, 255, 0.03) 1px, transparent 1px, transparent 20px), repeating-linear-gradient(-45deg, rgba(240, 244, 255, 0.03), rgba(240, 244, 255, 0.03) 1px, transparent 1px, transparent 20px)`,
          }}
        />

        <div className="max-w-5xl mx-auto relative z-10">
          {/* Section header */}
          <div className="text-center mb-12">
            <div
              className="inline-flex items-center gap-3 mb-4"
              style={{
                fontFamily: "var(--font-mono)",
                fontSize: "12px",
                letterSpacing: "0.2em",
                textTransform: "uppercase",
                color: "#C9A84C",
                fontWeight: 500,
              }}
            >
              <span style={{ width: "28px", height: "1px", background: "#C9A84C" }} />
              Industry Exhibitions
              <span style={{ width: "28px", height: "1px", background: "#C9A84C" }} />
            </div>
            <h2
              className="mb-5"
              style={{
                fontFamily: "var(--font-heading)",
                fontWeight: 700,
                fontSize: "clamp(32px, 4vw, 46px)",
                letterSpacing: "-0.015em",
                color: "var(--color-foreground)",
              }}
            >
              Where We Meet
            </h2>
            <p
              className="mx-auto"
              style={{
                fontSize: "17px",
                lineHeight: 1.7,
                color: "var(--color-muted-foreground)",
                maxWidth: "640px",
              }}
            >
              We travel to pharma&apos;s major industry exhibitions each year &mdash; to meet partners, source new manufacturers, and strengthen long-standing relationships. If you&apos;re attending, come by. We&apos;d love to meet you.
            </p>
          </div>

          {/* Upcoming block */}
          <div className="mb-16">
            <div className="flex items-center gap-4 mb-6">
              <span
                style={{
                  fontFamily: "var(--font-mono)",
                  fontSize: "12px",
                  letterSpacing: "0.18em",
                  textTransform: "uppercase",
                  color: "#C9A84C",
                  fontWeight: 500,
                  whiteSpace: "nowrap",
                }}
              >
                Upcoming &middot; 2026
              </span>
              <span
                style={{ flex: 1, height: "1px", background: "rgba(201, 168, 76, 0.3)" }}
              />
            </div>

            <div className="exhibition-grid grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <ExhibitionCard month="May" name="CPHI Middle East" dates="11 – 13 May 2026" venue="Riyadh Exhibition & Convention Centre" country="Saudi Arabia" />
              <ExhibitionCard month="Jul" name="CPHI Southeast Asia" dates="8 – 10 Jul 2026" venue="QSNCC, Bangkok" country="Thailand" />
              <ExhibitionCard month="Aug" name="Fi India" dates="26 – 28 Aug 2026" venue="Bombay Exhibition Center, Mumbai" country="India" />
              <ExhibitionCard month="Sep" name="iPHEX" dates="7 – 9 Sep 2026" venue="Bharat Mandapam, New Delhi" country="India" />
              <ExhibitionCard month="Oct" name="CPHI Worldwide" dates="6 – 8 Oct 2026" venue="Fiera Milano, Milan" country="Italy" />
              <ExhibitionCard month="Nov" name="CPHI India" dates="23 – 25 Nov 2026" venue="IICC Yashobhoomi, Dwarka, Delhi" country="India" />
              <ExhibitionCard month="Dec" name="CPHI Middle East" edition="Dec edition" dates="14 – 16 Dec 2026" venue="Riyadh Exhibition & Convention Centre" country="Saudi Arabia" isSeventh />
            </div>

            <p
              className="text-center mt-7"
              style={{
                fontSize: "13px",
                color: "var(--color-muted-foreground)",
                fontStyle: "italic",
                lineHeight: 1.6,
              }}
            >
              Booth numbers, stand details, and meeting information for each exhibition will be updated here as confirmed.
            </p>
          </div>

          {/* Recent exhibition feature */}
          <article
            className="mx-auto rounded-2xl overflow-hidden"
            style={{
              maxWidth: "900px",
              background: "var(--color-card)",
              border: "1px solid var(--color-border)",
              boxShadow: "0 8px 24px rgba(10, 22, 40, 0.06)",
            }}
          >
            <div className="px-6 md:px-10 pt-8 pb-6 text-center">
              <span
                style={{
                  display: "block",
                  fontFamily: "var(--font-mono)",
                  fontSize: "11px",
                  letterSpacing: "0.18em",
                  textTransform: "uppercase",
                  color: "#6B8F71",
                  fontWeight: 500,
                  marginBottom: "10px",
                }}
              >
                Most Recently
              </span>
              <h3
                className="mb-2"
                style={{
                  fontFamily: "var(--font-heading)",
                  fontWeight: 700,
                  fontSize: "clamp(24px, 2.8vw, 32px)",
                  lineHeight: 1.2,
                  letterSpacing: "-0.01em",
                  color: "var(--color-foreground)",
                }}
              >
                CPHI &amp; PMEC India 2025
              </h3>
              <div
                style={{
                  fontFamily: "var(--font-mono)",
                  fontSize: "12px",
                  letterSpacing: "0.1em",
                  color: "var(--color-muted-foreground)",
                }}
              >
                India Expo Mart, Greater Noida
                <span style={{ color: "#C9A84C", margin: "0 8px" }}>&middot;</span>
                November 25&ndash;27, 2025
              </div>
            </div>

            <div
              className="relative w-full"
              style={{
                paddingBottom: "56.25%",
                background: "var(--color-section-bg)",
              }}
            >
              <iframe
                src="https://www.youtube.com/embed/HrLRNXgPvm0"
                title="JBK at CPHI & PMEC India 2025 — pharmaceutical API distributor at Asia's largest pharma exhibition"
                loading="lazy"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                referrerPolicy="strict-origin-when-cross-origin"
                allowFullScreen
                className="cphi-iframe absolute top-0 left-0 w-full h-full"
                style={{ border: "none" }}
              />
            </div>

            <div
              className="px-6 md:px-10 py-8 mx-auto text-center"
              style={{
                maxWidth: "780px",
                fontSize: "16px",
                lineHeight: 1.75,
                color: "var(--color-foreground)",
              }}
            >
              <p className="mb-4">
                The 18th edition of Asia&apos;s largest pharmaceutical exhibition brought together over 65,000 industry professionals &mdash; buyers, formulators, and distributors from Europe, the Americas, Southeast Asia, and the Middle East &mdash; to explore sourcing partnerships and API innovations.
              </p>
              <p className="mb-4">
                Three days of conversations with long-standing partners and new contacts alike.
              </p>
              <p
                style={{
                  fontFamily: "var(--font-heading)",
                  fontStyle: "italic",
                  fontSize: "18px",
                  color: "var(--color-foreground)",
                  marginTop: "8px",
                  marginBottom: 0,
                }}
              >
                We&apos;d love to see you at the next one.
              </p>
            </div>
          </article>
        </div>
      </section>

      {/* Where We Source From */}
      <section
        className="py-16 md:py-24 px-4 sm:px-6 lg:px-8 relative"
        style={{ backgroundColor: "var(--color-section-bg)" }}
      >
        <div
          className="absolute inset-0 dark:hidden"
          style={{
            backgroundImage: `repeating-linear-gradient(
              45deg,
              rgba(10, 22, 40, 0.04),
              rgba(10, 22, 40, 0.04) 1px,
              transparent 1px,
              transparent 20px
            ),
            repeating-linear-gradient(
              -45deg,
              rgba(10, 22, 40, 0.04),
              rgba(10, 22, 40, 0.04) 1px,
              transparent 1px,
              transparent 20px
            )`,
          }}
        />
        <div
          className="absolute inset-0 hidden dark:block"
          style={{
            backgroundImage: `repeating-linear-gradient(
              45deg,
              rgba(240, 244, 255, 0.03),
              rgba(240, 244, 255, 0.03) 1px,
              transparent 1px,
              transparent 20px
            ),
            repeating-linear-gradient(
              -45deg,
              rgba(240, 244, 255, 0.03),
              rgba(240, 244, 255, 0.03) 1px,
              transparent 1px,
              transparent 20px
            )`,
          }}
        />
        <div className="max-w-6xl mx-auto relative z-10">
          <h2
            className="text-3xl md:text-4xl mb-4 text-center"
            style={{
              fontFamily: "var(--font-heading)",
              fontWeight: 700,
              color: "var(--color-foreground)",
            }}
          >
            Where We Source From
          </h2>
          <p
            className="text-center mb-12 text-base"
            style={{
              fontFamily: "var(--font-body)",
              color: "var(--color-muted-foreground)",
            }}
          >
            We bring the world's best pharmaceutical ingredients to your supply
            chain.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {sourcingRegions.map((region, index) => (
              <div
                key={region.country}
                className="p-6 rounded-lg transition-all duration-200"
                style={{
                  backgroundColor: "var(--color-card)",
                  border: "1px solid var(--color-border)",
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = "translateY(-4px)";
                  e.currentTarget.style.boxShadow =
                    "0 8px 24px rgba(10,22,40,0.12)";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = "translateY(0)";
                  e.currentTarget.style.boxShadow = "none";
                }}
              >
                <div className="mb-4">
                  <img
                    src={`https://flagcdn.com/w40/${region.flagCode}.png`}
                    alt={region.flagAlt}
                    width="36"
                    height="24"
                    style={{
                      borderRadius: "4px",
                      display: "block",
                    }}
                  />
                </div>
                <h3
                  className="text-lg mb-2"
                  style={{
                    fontFamily: "var(--font-body)",
                    fontWeight: 700,
                    color: "var(--color-foreground)",
                  }}
                >
                  {region.country}
                </h3>
                <p
                  className="text-sm"
                  style={{
                    fontFamily: "var(--font-body)",
                    color: "var(--color-muted-foreground)",
                  }}
                >
                  {region.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

/* ─────────── C9 · Exhibition card helper ─────────── */

function ExhibitionCard({
  month,
  name,
  edition,
  dates,
  venue,
  country,
  isSeventh,
}: {
  month: string;
  name: string;
  edition?: string;
  dates: string;
  venue: string;
  country: string;
  isSeventh?: boolean;
}) {
  return (
    <article
      className="exhibition-card rounded-xl transition-all duration-150"
      data-seventh={isSeventh ? "true" : undefined}
      style={{
        background: "var(--color-card)",
        border: "1px solid var(--color-border)",
        padding: "22px 22px 20px",
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.borderColor = "rgba(201, 168, 76, 0.55)";
        e.currentTarget.style.transform = "translateY(-2px)";
        e.currentTarget.style.boxShadow = "0 8px 20px rgba(10, 22, 40, 0.08)";
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.borderColor = "var(--color-border)";
        e.currentTarget.style.transform = "translateY(0)";
        e.currentTarget.style.boxShadow = "none";
      }}
    >
      <div
        className="inline-block mb-3"
        style={{
          padding: "3px 10px",
          fontFamily: "var(--font-mono)",
          fontSize: "11px",
          letterSpacing: "0.14em",
          textTransform: "uppercase",
          fontWeight: 500,
          color: "#C9A84C",
          background: "rgba(201, 168, 76, 0.08)",
          border: "1px solid rgba(201, 168, 76, 0.18)",
          borderRadius: "4px",
        }}
      >
        {month}
      </div>
      <h3
        className="m-0 mb-2"
        style={{
          fontFamily: "var(--font-heading)",
          fontWeight: 600,
          fontSize: "18px",
          lineHeight: 1.25,
          letterSpacing: "-0.005em",
          color: "var(--color-foreground)",
        }}
      >
        {name}
        {edition && (
          <span
            className="ml-1 align-middle"
            style={{
              fontFamily: "var(--font-body)",
              fontSize: "11.5px",
              fontWeight: 400,
              fontStyle: "italic",
              color: "var(--color-muted-foreground)",
              display: "inline-block",
            }}
          >
            {edition}
          </span>
        )}
      </h3>
      <div
        style={{
          fontFamily: "var(--font-mono)",
          fontSize: "12.5px",
          letterSpacing: "0.04em",
          color: "var(--color-foreground)",
          marginBottom: "10px",
        }}
      >
        {dates}
      </div>
      <div
        style={{
          fontSize: "13px",
          lineHeight: 1.5,
          color: "var(--color-muted-foreground)",
        }}
      >
        {venue}
        <br />
        <span
          style={{
            fontFamily: "var(--font-mono)",
            fontSize: "11px",
            letterSpacing: "0.06em",
            opacity: 0.85,
            marginTop: "2px",
          }}
        >
          {country}
        </span>
      </div>
    </article>
  );
}
