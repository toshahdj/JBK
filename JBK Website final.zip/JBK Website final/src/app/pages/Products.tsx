import { useState, useEffect, useMemo, useCallback } from "react";
import { Search, ChevronLeft, ChevronRight } from "lucide-react";
import productsData from "../data/products.json";
import { projectId, publicAnonKey } from "../../../utils/supabase/info";
import NutraceuticalsFeature from "../components/NutraceuticalsFeature";
import RequestSampleCTA from "../components/RequestSampleCTA";
import AlsoAvailable from "../components/AlsoAvailable";

interface Product {
  name: string;
  manufacturer: string;
  category: string;
  categories?: string[];
}

const TABS = ["All", "APIs", "Veterinary", "Nutraceuticals"] as const;
type Tab = (typeof TABS)[number];

const FLAGSHIP_NUTRA_NAMES = new Set<string>([
  "Vegan Vitamin D3 Oil (1,000,000 IU)",
  "MenaquinGold (Natural Vitamin K2-7)",
  "Caffeine Anhydrous",
]);

const DEBOUNCE_MS = 300;

/** 7×6=42 desktop · 6×3=18 tablet · 3×4=12 mobile · 2×6=12 small mobile. */
function useGridConfig() {
  const [config, setConfig] = useState<{ cols: number; rows: number }>({ cols: 7, rows: 6 });
  useEffect(() => {
    const update = () => {
      const w = window.innerWidth;
      if (w < 420) setConfig({ cols: 2, rows: 6 });
      else if (w < 760) setConfig({ cols: 3, rows: 4 });
      else if (w < 1100) setConfig({ cols: 6, rows: 3 });
      else setConfig({ cols: 7, rows: 6 });
    };
    update();
    window.addEventListener("resize", update);
    return () => window.removeEventListener("resize", update);
  }, []);
  return config;
}

function matchesTab(p: Product, tab: Tab): boolean {
  if (tab === "All") return true;
  if (p.categories && p.categories.length > 0) return p.categories.includes(tab);
  return p.category === tab;
}

function matchesSearch(p: Product, q: string): boolean {
  if (!q) return true;
  return p.name.toLowerCase().includes(q.toLowerCase());
}

export default function Products() {
  const [allProducts, setAllProducts] = useState<Product[]>([]);
  const [activeTab, setActiveTab] = useState<Tab>("All");
  const [searchTerm, setSearchTerm] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [currentPage, setCurrentPage] = useState(0);
  const { cols, rows } = useGridConfig();
  const pageSize = cols * rows;

  const [formData, setFormData] = useState({
    name: "",
    company: "",
    email: "",
    phone: "",
    country: "",
    inquiryType: "Product Inquiry",
    productDescription: "",
    message: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<"success" | "error" | null>(null);

  // ── SEO ──
  useEffect(() => {
    document.title =
      "Pharmaceutical APIs & Intermediates | Product Catalogue | J. B. Khokhani & Co.";
    const desc =
      "Browse 240+ pharmaceutical APIs, veterinary products, and nutraceuticals. IP · BP · EP · USP grade. Request samples and quotes.";

    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) metaDescription.setAttribute("content", desc);
    else {
      const m = document.createElement("meta");
      m.name = "description";
      m.content = desc;
      document.head.appendChild(m);
    }

    const ogTags = [
      { property: "og:title", content: "Pharmaceutical APIs & Intermediates | Product Catalogue | J. B. Khokhani & Co." },
      { property: "og:description", content: desc },
      { property: "og:type", content: "website" },
      { property: "og:site_name", content: "J. B. Khokhani & Co." },
      { property: "og:url", content: "https://www.jbkhokhani.com/products" },
      { property: "og:image", content: "https://www.jbkhokhani.com/assets/1_without_background.png" },
    ];
    ogTags.forEach(({ property, content }) => {
      let tag = document.querySelector(`meta[property="${property}"]`);
      if (tag) tag.setAttribute("content", content);
      else {
        tag = document.createElement("meta");
        tag.setAttribute("property", property);
        tag.setAttribute("content", content);
        document.head.appendChild(tag);
      }
    });

    const twitterTags = [
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "Pharmaceutical APIs & Intermediates | Product Catalogue | J. B. Khokhani & Co." },
      { name: "twitter:description", content: desc },
      { name: "twitter:image", content: "https://www.jbkhokhani.com/assets/1_without_background.png" },
    ];
    twitterTags.forEach(({ name, content }) => {
      let tag = document.querySelector(`meta[name="${name}"]`);
      if (tag) tag.setAttribute("content", content);
      else {
        tag = document.createElement("meta");
        tag.setAttribute("name", name);
        tag.setAttribute("content", content);
        document.head.appendChild(tag);
      }
    });

    let canonical = document.querySelector('link[rel="canonical"]');
    if (canonical) canonical.setAttribute("href", "https://www.jbkhokhani.com/products");
    else {
      canonical = document.createElement("link");
      canonical.setAttribute("rel", "canonical");
      canonical.setAttribute("href", "https://www.jbkhokhani.com/products");
      document.head.appendChild(canonical);
    }

    let schemaScript = document.querySelector('script[data-schema="itemlist"]');
    if (!schemaScript) {
      schemaScript = document.createElement("script");
      schemaScript.setAttribute("type", "application/ld+json");
      schemaScript.setAttribute("data-schema", "itemlist");
      schemaScript.textContent = JSON.stringify({
        "@context": "https://schema.org",
        "@type": "ItemList",
        name: "Pharmaceutical APIs, Veterinary Products and Nutraceuticals — J. B. Khokhani & Co.",
        description:
          "Complete catalogue of 247 unique pharmaceutical APIs, veterinary products, and nutraceutical ingredients supplied by J. B. Khokhani & Co.",
        numberOfItems: 247,
        itemListElement: [
          { "@type": "ListItem", position: 1, name: "Pharmaceutical APIs" },
          { "@type": "ListItem", position: 2, name: "Veterinary Products" },
          { "@type": "ListItem", position: 3, name: "Nutraceutical Ingredients" },
        ],
      });
      document.head.appendChild(schemaScript);
    }

    const additionalTags = [
      { name: "robots", content: "index, follow" },
      { name: "author", content: "J. B. Khokhani & Co." },
      { name: "geo.region", content: "IN-MH" },
      { name: "geo.placename", content: "Mumbai" },
      { name: "geo.position", content: "19.0176;72.8562" },
      { name: "ICBM", content: "19.0176, 72.8562" },
    ];
    additionalTags.forEach(({ name, content }) => {
      let tag = document.querySelector(`meta[name="${name}"]`);
      if (tag) tag.setAttribute("content", content);
      else {
        tag = document.createElement("meta");
        tag.setAttribute("name", name);
        tag.setAttribute("content", content);
        document.head.appendChild(tag);
      }
    });
  }, []);

  // Merge products by name
  useEffect(() => {
    const productMap = new Map<string, Product>();
    (productsData as Product[]).forEach((product) => {
      const existing = productMap.get(product.name);
      if (existing) {
        if (!existing.categories) existing.categories = [existing.category];
        if (!existing.categories.includes(product.category)) existing.categories.push(product.category);
        if ((!existing.manufacturer || existing.manufacturer.trim() === "") && product.manufacturer?.trim()) {
          existing.manufacturer = product.manufacturer;
        }
      } else {
        productMap.set(product.name, { ...product });
      }
    });
    setAllProducts(Array.from(productMap.values()));
  }, []);

  useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(searchTerm.trim()), DEBOUNCE_MS);
    return () => clearTimeout(t);
  }, [searchTerm]);

  useEffect(() => {
    setCurrentPage(0);
  }, [activeTab, debouncedSearch, cols, rows]);

  const filteredProducts = useMemo(() => {
    return allProducts
      .filter((p) => matchesTab(p, activeTab) && matchesSearch(p, debouncedSearch))
      .sort((a, b) => a.name.localeCompare(b.name, "en", { sensitivity: "base" }));
  }, [allProducts, activeTab, debouncedSearch]);

  const crossTabMatches = useMemo(() => {
    if (!debouncedSearch || filteredProducts.length > 0) return {} as Record<string, number>;
    const result: Record<string, number> = {};
    for (const tab of TABS) {
      if (tab === "All" || tab === activeTab) continue;
      const count = allProducts.filter(
        (p) => matchesTab(p, tab) && matchesSearch(p, debouncedSearch)
      ).length;
      if (count > 0) result[tab] = count;
    }
    return result;
  }, [allProducts, activeTab, debouncedSearch, filteredProducts.length]);

  const nutraAll = useMemo(
    () => allProducts.filter((p) => matchesTab(p, "Nutraceuticals")),
    [allProducts]
  );
  const nutraNonFlagship = useMemo(
    () => nutraAll.filter((p) => !FLAGSHIP_NUTRA_NAMES.has(p.name)),
    [nutraAll]
  );
  const nutraFiltered = useMemo(
    () => nutraAll.filter((p) => matchesSearch(p, debouncedSearch)),
    [nutraAll, debouncedSearch]
  );

  const totalPages = Math.max(1, Math.ceil(filteredProducts.length / pageSize));
  const safePage = Math.min(currentPage, totalPages - 1);
  const pageStart = safePage * pageSize;
  const pageEnd = Math.min(pageStart + pageSize, filteredProducts.length);

  useEffect(() => {
    if (currentPage > totalPages - 1) setCurrentPage(Math.max(0, totalPages - 1));
  }, [currentPage, totalPages]);

  const letterToPage = useMemo(() => {
    const m = new Map<string, number>();
    filteredProducts.forEach((p, i) => {
      const L = p.name[0]?.toUpperCase() ?? "";
      if (L && !m.has(L)) m.set(L, Math.floor(i / pageSize));
    });
    return m;
  }, [filteredProducts, pageSize]);

  const lettersPresent = useMemo(() => new Set(letterToPage.keys()), [letterToPage]);

  const nextPage = useCallback(() => {
    setCurrentPage((p) => Math.min(p + 1, totalPages - 1));
  }, [totalPages]);
  const prevPage = useCallback(() => {
    setCurrentPage((p) => Math.max(p - 1, 0));
  }, []);

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (
        target.tagName === "INPUT" ||
        target.tagName === "TEXTAREA" ||
        target.tagName === "SELECT"
      ) return;
      if (e.key === "ArrowLeft") prevPage();
      if (e.key === "ArrowRight") nextPage();
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [nextPage, prevPage]);

  const resetFilters = () => {
    setActiveTab("All");
    setSearchTerm("");
    setDebouncedSearch("");
    setCurrentPage(0);
  };

  const switchToTab = (tab: Tab) => {
    setActiveTab(tab);
    setCurrentPage(0);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitStatus(null);
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-c285fd22/send-email`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify({ formType: "product", ...formData }),
        }
      );
      const data = await response.json();
      if (response.ok) {
        setSubmitStatus("success");
        setFormData({
          name: "",
          company: "",
          email: "",
          phone: "",
          country: "",
          inquiryType: "Product Inquiry",
          productDescription: "",
          message: "",
        });
      } else {
        console.error("Email sending failed:", data);
        setSubmitStatus("error");
      }
    } catch (error) {
      console.error("Error submitting form:", error);
      setSubmitStatus("error");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const tabCount = (tab: Tab): number => {
    if (tab === "All") return allProducts.length;
    return allProducts.filter((p) => matchesTab(p, tab)).length;
  };

  const isNutraTab = activeTab === "Nutraceuticals";
  const hasSearch = debouncedSearch.length > 0;
  const showCatalogueBand = !isNutraTab;
  const showNutraExperience = isNutraTab && !hasSearch;
  const showNutraFiltered = isNutraTab && hasSearch;

  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 relative">
        <BackgroundPattern />
        <div className="max-w-6xl mx-auto text-center relative z-10">
          <h1
            className="text-4xl md:text-6xl mb-6"
            style={{
              fontFamily: "var(--font-heading)",
              fontWeight: 700,
              color: "var(--color-foreground)",
            }}
          >
            Our Products
          </h1>
          <p className="text-lg md:text-xl max-w-3xl mx-auto" style={{ color: "var(--color-foreground)" }}>
            240+ pharmaceutical ingredients across APIs, nutraceuticals, and veterinary products — sourced from India's leading manufacturers and global suppliers.
          </p>
        </div>
      </section>

      {/* Filters */}
      <section className="pb-6 px-4 sm:px-6 lg:px-8 relative">
        <BackgroundPattern />
        <div className="max-w-6xl mx-auto relative z-10">
          <div className="relative max-w-xl mx-auto mb-5">
            <Search
              className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5"
              style={{ color: "var(--color-muted-foreground)" }}
            />
            <input
              type="text"
              placeholder="Search products by name…"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              autoComplete="off"
              aria-label="Search products"
              className="w-full pl-12 pr-4 py-3 rounded-lg"
              style={{
                backgroundColor: "var(--color-input-background)",
                border: "1px solid var(--color-border)",
                color: "var(--color-foreground)",
                fontFamily: "var(--font-body)",
              }}
            />
          </div>

          <div className="flex flex-wrap justify-center gap-2">
            {TABS.map((tab) => {
              const active = activeTab === tab;
              return (
                <button
                  key={tab}
                  type="button"
                  role="tab"
                  aria-selected={active}
                  onClick={() => setActiveTab(tab)}
                  className="px-5 py-2.5 rounded-md transition-all duration-150"
                  style={{
                    fontFamily: "var(--font-body)",
                    fontSize: "14px",
                    fontWeight: active ? 600 : 500,
                    background: active ? "var(--color-accent)" : "var(--color-secondary)",
                    color: active ? "var(--color-accent-foreground)" : "var(--color-foreground)",
                    border: "1px solid var(--color-border)",
                    cursor: "pointer",
                    transition: "background 150ms ease, border-color 150ms ease, color 150ms ease",
                  }}
                  onMouseEnter={(e) => {
                    if (!active) {
                      e.currentTarget.style.background = "rgba(201, 168, 76, 0.12)";
                      e.currentTarget.style.borderColor = "rgba(201, 168, 76, 0.4)";
                    }
                  }}
                  onMouseLeave={(e) => {
                    if (!active) {
                      e.currentTarget.style.background = "var(--color-secondary)";
                      e.currentTarget.style.borderColor = "var(--color-border)";
                    }
                  }}
                >
                  {tab}
                  <span className="ml-2" style={{ fontFamily: "var(--font-mono)", fontSize: "11px", opacity: 0.75 }}>
                    {tabCount(tab)}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* A-Z bar */}
      {!isNutraTab && (
        <div className="pb-5 px-4 sm:px-6 lg:px-8 relative">
          <div className="max-w-6xl mx-auto flex flex-wrap justify-center gap-1 relative z-10">
            {Array.from({ length: 26 }, (_, i) => {
              const letter = String.fromCharCode(65 + i);
              const has = lettersPresent.has(letter);
              return (
                <button
                  key={letter}
                  type="button"
                  disabled={!has}
                  aria-label={has ? `Jump to products starting with ${letter}` : `${letter} — no matches`}
                  onClick={() => {
                    const p = letterToPage.get(letter);
                    if (p !== undefined) setCurrentPage(p);
                  }}
                  className="rounded transition-colors"
                  style={{
                    width: "28px",
                    height: "28px",
                    fontFamily: "var(--font-mono)",
                    fontSize: "12px",
                    fontWeight: 500,
                    border: "none",
                    background: "transparent",
                    cursor: has ? "pointer" : "default",
                    color: has ? "var(--color-foreground)" : "rgba(128,128,128,0.3)",
                  }}
                  onMouseEnter={(e) => {
                    if (has) {
                      e.currentTarget.style.backgroundColor = "var(--color-secondary)";
                      e.currentTarget.style.color = "#C9A84C";
                    }
                  }}
                  onMouseLeave={(e) => {
                    if (has) {
                      e.currentTarget.style.backgroundColor = "transparent";
                      e.currentTarget.style.color = "var(--color-foreground)";
                    }
                  }}
                >
                  {letter}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {showNutraExperience && (
        <>
          <NutraceuticalsFeature />
          <RequestSampleCTA />
          <AlsoAvailable products={nutraNonFlagship.map((p) => ({ name: p.name }))} />
        </>
      )}

      {showNutraFiltered && (
        <section className="py-8 px-4 sm:px-6 lg:px-8" style={{ backgroundColor: "var(--color-section-bg)" }}>
          <div className="max-w-6xl mx-auto">
            {nutraFiltered.length === 0 ? (
              <EmptyState
                searchTerm={debouncedSearch}
                crossTabMatches={crossTabMatches}
                onSwitchTab={switchToTab}
                onReset={resetFilters}
              />
            ) : (
              <>
                <div
                  className="text-center mb-4"
                  style={{
                    fontFamily: "var(--font-mono)",
                    fontSize: "12px",
                    letterSpacing: "0.05em",
                    color: "var(--color-muted-foreground)",
                  }}
                >
                  {nutraFiltered.length} nutraceutical{nutraFiltered.length === 1 ? "" : "s"} match "{debouncedSearch}"
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5">
                  {nutraFiltered.map((p) => (
                    <ProductCard key={p.name} name={p.name} />
                  ))}
                </div>
              </>
            )}
          </div>
        </section>
      )}

      {showCatalogueBand && (
        <section className="py-8 relative" style={{ backgroundColor: "var(--color-section-bg)" }}>
          <div className="relative max-w-6xl mx-auto" style={{ padding: "0 60px" }}>
            {filteredProducts.length === 0 ? (
              <EmptyState
                searchTerm={debouncedSearch}
                crossTabMatches={crossTabMatches}
                onSwitchTab={switchToTab}
                onReset={resetFilters}
              />
            ) : (
              <>
                <div
                  className="text-center mb-4"
                  style={{
                    fontFamily: "var(--font-mono)",
                    fontSize: "12px",
                    letterSpacing: "0.05em",
                    color: "var(--color-muted-foreground)",
                  }}
                >
                  {totalPages > 1 ? (
                    <>
                      Showing {pageStart + 1}&ndash;{pageEnd} of {filteredProducts.length} products
                    </>
                  ) : (
                    <>{filteredProducts.length} product{filteredProducts.length === 1 ? "" : "s"}</>
                  )}
                </div>

                <div style={{ position: "relative" }}>
                  {/* Padding wrapper — defines the gutter on desktop. No overflow hidden here. */}
                  <div className="md:px-14">
                    {/* Slide container — its OWN overflow hidden clips at its OWN edges, no bleed. */}
                    <div style={{ overflow: "hidden", position: "relative" }}>
                      <div
                        style={{
                          display: "flex",
                          transform: `translateX(-${safePage * 100}%)`,
                          transition: "transform 420ms cubic-bezier(0.32, 0.72, 0, 1)",
                          willChange: "transform",
                        }}
                      >
                        {Array.from({ length: totalPages }, (_, pageIdx) => {
                          const start = pageIdx * pageSize;
                          const end = Math.min(start + pageSize, filteredProducts.length);
                          const items = filteredProducts.slice(start, end);
                          return (
                            <div
                              key={pageIdx}
                              style={{
                                flex: "0 0 100%",
                                display: "grid",
                                gridTemplateColumns: `repeat(${cols}, 1fr)`,
                                gridTemplateRows: `repeat(${rows}, 1fr)`,
                                gap: cols >= 6 ? "10px" : "8px",
                                minHeight: `${rows * 95}px`,
                                alignContent: "start",
                              }}
                            >
                              {items.map((p) => (
                                <ProductCard key={p.name} name={p.name} />
                              ))}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>

                  {totalPages > 1 && (
                    <>
                      <PageArrow direction="prev" disabled={safePage === 0} onClick={prevPage} />
                      <PageArrow direction="next" disabled={safePage === totalPages - 1} onClick={nextPage} />
                    </>
                  )}
                </div>

                {totalPages > 1 && (
                  <div className="flex justify-center items-center gap-4 mt-5">
                    <div className="flex gap-1.5 items-center">
                      {getPaginationItems(safePage, totalPages).map((item) => {
                        if (item.type === "ellipsis") {
                          return (
                            <span
                              key={item.key}
                              className="flex gap-0.5 items-center mx-1"
                              aria-hidden="true"
                            >
                              <span style={{ width: "3px", height: "3px", borderRadius: "999px", background: "var(--color-foreground)", opacity: 0.4 }} />
                              <span style={{ width: "3px", height: "3px", borderRadius: "999px", background: "var(--color-foreground)", opacity: 0.4 }} />
                              <span style={{ width: "3px", height: "3px", borderRadius: "999px", background: "var(--color-foreground)", opacity: 0.4 }} />
                            </span>
                          );
                        }
                        const p = item.page;
                        return (
                          <button
                            key={p}
                            type="button"
                            aria-label={`Go to page ${p + 1}`}
                            onClick={() => setCurrentPage(p)}
                            style={{
                              width: p === safePage ? "22px" : "7px",
                              height: "7px",
                              borderRadius: "999px",
                              background: p === safePage ? "#C9A84C" : "var(--color-foreground)",
                              opacity: p === safePage ? 1 : 0.25,
                              border: "none",
                              padding: 0,
                              cursor: "pointer",
                              transition: "width 180ms ease, opacity 180ms ease, background 180ms ease",
                            }}
                          />
                        );
                      })}
                    </div>
                    <div
                      style={{
                        fontFamily: "var(--font-mono)",
                        fontSize: "12px",
                        letterSpacing: "0.08em",
                        color: "var(--color-muted-foreground)",
                        whiteSpace: "nowrap",
                      }}
                    >
                      <span style={{ color: "#C9A84C", fontWeight: 600 }}>{safePage + 1}</span>
                      {" / "}
                      {totalPages}
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        </section>
      )}

      {/* Inquiry form (preserved — Supabase wiring unchanged) */}
      <section
        className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 relative"
        style={{ backgroundColor: "var(--color-section-bg)" }}
      >
        <BackgroundPattern />
        <div className="max-w-3xl mx-auto relative z-10">
          <h2
            className="text-3xl md:text-4xl mb-4"
            style={{
              fontFamily: "var(--font-heading)",
              fontWeight: 600,
              color: "var(--color-foreground)",
            }}
          >
            Can't find what you need?
          </h2>
          <p className="text-lg mb-8" style={{ color: "var(--color-foreground)" }}>
            We source beyond our listed products. If you're looking for a specific API, intermediate, or ingredient not listed here, tell us — we'll find it.
          </p>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <LabeledInput label="Name *" name="name" required value={formData.name} onChange={handleInputChange} />
              <LabeledInput label="Company Name *" name="company" required value={formData.company} onChange={handleInputChange} />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <LabeledInput label="Email Address *" name="email" type="email" required value={formData.email} onChange={handleInputChange} />
              <LabeledInput label="Phone Number" name="phone" value={formData.phone} onChange={handleInputChange} />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <LabeledInput label="Country" name="country" value={formData.country} onChange={handleInputChange} />
              <div>
                <label htmlFor="products-inquiryType" className="block mb-2" style={{ color: "var(--color-foreground)" }}>
                  Inquiry Type
                </label>
                    <select id="products-inquiryType"
                  name="inquiryType"
                  value={formData.inquiryType}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 rounded"
                  style={{
                    backgroundColor: "var(--color-input-background)",
                    border: "1px solid var(--color-border)",
                    color: "var(--color-foreground)",
                  }}
                >
                  <option value="Product Inquiry">Product Inquiry</option>
                  <option value="Sample Request">Sample Request</option>
                  <option value="Custom Sourcing">Custom Sourcing</option>
                  <option value="Regulatory Documentation">Regulatory Documentation</option>
                </select>
              </div>
            </div>
            <div>
              <label htmlFor="products-productDescription" className="block mb-2" style={{ color: "var(--color-foreground)" }}>
                Product / Ingredient You're Looking For
              </label>
                    <input id="products-productDescription"
                type="text"
                name="productDescription"
                value={formData.productDescription}
                onChange={handleInputChange}
                placeholder="e.g. Amoxicillin Trihydrate USP, Curcumin extract…"
                className="w-full px-4 py-3 rounded"
                style={{
                  backgroundColor: "var(--color-input-background)",
                  border: "1px solid var(--color-border)",
                  color: "var(--color-foreground)",
                }}
              />
            </div>
            <div>
              <label htmlFor="products-message" className="block mb-2" style={{ color: "var(--color-foreground)" }}>
                Additional Details
              </label>
                    <textarea id="products-message"
                name="message"
                rows={4}
                value={formData.message}
                onChange={handleInputChange}
                placeholder="Quantity required, grade, timeline, or any other specifics…"
                className="w-full px-4 py-3 rounded"
                style={{
                  backgroundColor: "var(--color-input-background)",
                  border: "1px solid var(--color-border)",
                  color: "var(--color-foreground)",
                }}
              />
            </div>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-8 py-3 rounded-lg transition-all duration-200"
              style={{
                backgroundColor: "var(--color-accent-terracotta)",
                color: "#FFFFFF",
                fontFamily: "var(--font-body)",
                fontWeight: 500,
                border: "none",
                cursor: isSubmitting ? "not-allowed" : "pointer",
                opacity: isSubmitting ? 0.7 : 1,
              }}
            >
              {isSubmitting ? "Sending…" : "Submit Inquiry"}
            </button>
            {submitStatus === "success" && (
              <p style={{ color: "var(--color-accent-green)", fontFamily: "var(--font-body)" }}>
                Thank you. We've received your inquiry and will be in touch shortly.
              </p>
            )}
            {submitStatus === "error" && (
              <p style={{ color: "var(--color-accent-terracotta)", fontFamily: "var(--font-body)" }}>
                Sorry, something went wrong. Please try again or contact us directly.
              </p>
            )}
          </form>
        </div>
      </section>
    </div>
  );
}

/* ─────────── Sub-components ─────────── */

function BackgroundPattern() {
  return (
    <>
      <div
        className="absolute inset-0 dark:hidden"
        style={{
          backgroundImage: `repeating-linear-gradient(45deg, rgba(10, 22, 40, 0.04), rgba(10, 22, 40, 0.04) 1px, transparent 1px, transparent 20px), repeating-linear-gradient(-45deg, rgba(10, 22, 40, 0.04), rgba(10, 22, 40, 0.04) 1px, transparent 1px, transparent 20px)`,
        }}
      />
      <div
        className="absolute inset-0 hidden dark:block"
        style={{
          backgroundImage: `repeating-linear-gradient(45deg, rgba(240, 244, 255, 0.03), rgba(240, 244, 255, 0.03) 1px, transparent 1px, transparent 20px), repeating-linear-gradient(-45deg, rgba(240, 244, 255, 0.03), rgba(240, 244, 255, 0.03) 1px, transparent 1px, transparent 20px)`,
        }}
      />
    </>
  );
}

function ProductCard({ name }: { name: string }) {
  return (
    <article
      className="rounded-lg flex items-center justify-center text-center transition-all duration-150"
      style={{
        backgroundColor: "var(--color-card)",
        border: "1px solid var(--color-border)",
        padding: "12px 10px",
        minHeight: "88px",
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.borderColor = "rgba(201, 168, 76, 0.55)";
        e.currentTarget.style.transform = "translateY(-2px)";
        e.currentTarget.style.boxShadow = "0 6px 14px rgba(10, 22, 40, 0.07)";
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.borderColor = "var(--color-border)";
        e.currentTarget.style.transform = "translateY(0)";
        e.currentTarget.style.boxShadow = "none";
      }}
    >
      <p
        className="m-0"
        style={{
          fontFamily: "var(--font-heading)",
          fontWeight: 600,
          fontSize: "14px",
          lineHeight: 1.2,
          color: "var(--color-foreground)",
          wordBreak: "break-word",
          hyphens: "auto",
        }}
      >
        {name}
      </p>
    </article>
  );
}

type PaginationItem = { type: "dot"; page: number } | { type: "ellipsis"; key: string };

function getPaginationItems(current: number, total: number): PaginationItem[] {
  if (total <= 7) {
    return Array.from({ length: total }, (_, i) => ({ type: "dot" as const, page: i }));
  }

  const items: PaginationItem[] = [];
  items.push({ type: "dot", page: 0 });

  let startMid: number;
  let endMid: number;
  if (current <= 2) {
    startMid = 1;
    endMid = 3;
  } else if (current >= total - 3) {
    startMid = total - 4;
    endMid = total - 2;
  } else {
    startMid = current - 1;
    endMid = current + 1;
  }

  if (startMid > 1) items.push({ type: "ellipsis", key: "ell-start" });
  for (let i = startMid; i <= endMid; i++) items.push({ type: "dot", page: i });
  if (endMid < total - 2) items.push({ type: "ellipsis", key: "ell-end" });

  items.push({ type: "dot", page: total - 1 });
  return items;
}

function PageArrow({
  direction,
  disabled,
  onClick,
}: {
  direction: "prev" | "next";
  disabled: boolean;
  onClick: () => void;
}) {
  const Icon = direction === "prev" ? ChevronLeft : ChevronRight;
  const sideStyle: React.CSSProperties =
    direction === "prev" ? { left: "8px" } : { right: "8px" };
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      aria-label={direction === "prev" ? "Previous page" : "Next page"}
      className="absolute top-1/2 hidden md:grid place-items-center rounded-full transition-all duration-150"
      style={{
        ...sideStyle,
        width: "40px",
        height: "40px",
        transform: "translateY(-50%)",
        border: "1px solid var(--color-border)",
        background: "var(--color-card)",
        color: "var(--color-foreground)",
        cursor: disabled ? "default" : "pointer",
        opacity: disabled ? 0.3 : 1,
        zIndex: 2,
      }}
      onMouseEnter={(e) => {
        if (!disabled) {
          e.currentTarget.style.background = "#C9A84C";
          e.currentTarget.style.borderColor = "#C9A84C";
          e.currentTarget.style.color = "#0A1628";
        }
      }}
      onMouseLeave={(e) => {
        if (!disabled) {
          e.currentTarget.style.background = "var(--color-card)";
          e.currentTarget.style.borderColor = "var(--color-border)";
          e.currentTarget.style.color = "var(--color-foreground)";
        }
      }}
    >
      <Icon className="w-4 h-4" />
    </button>
  );
}

function EmptyState({
  searchTerm,
  crossTabMatches,
  onSwitchTab,
  onReset,
}: {
  searchTerm: string;
  crossTabMatches: Record<string, number>;
  onSwitchTab: (tab: Tab) => void;
  onReset: () => void;
}) {
  const hasCrossTab = Object.keys(crossTabMatches).length > 0;
  return (
    <div
      className="max-w-md mx-auto text-center rounded-xl my-10 px-8 py-10"
      style={{
        background: "var(--color-card)",
        border: "1px dashed var(--color-border)",
      }}
    >
      <h3
        className="m-0 mb-2"
        style={{
          fontFamily: "var(--font-heading)",
          fontWeight: 600,
          fontSize: "20px",
          color: "var(--color-foreground)",
        }}
      >
        No products match your search
      </h3>
      <p className="m-0 mb-5" style={{ color: "var(--color-muted-foreground)", fontSize: "14px" }}>
        {searchTerm ? <>No matches for "{searchTerm}" in this tab.</> : <>Try a different term, or reset to browse all.</>}
      </p>
      {hasCrossTab && (
        <div className="flex flex-wrap justify-center gap-2 mb-5">
          {Object.entries(crossTabMatches).map(([tab, count]) => (
            <button
              key={tab}
              type="button"
              onClick={() => onSwitchTab(tab as Tab)}
              className="transition-all duration-150"
              style={{
                padding: "9px 16px",
                background: "transparent",
                color: "#C9A84C",
                border: "1px solid #C9A84C",
                borderRadius: "6px",
                fontFamily: "var(--font-mono)",
                fontSize: "12px",
                fontWeight: 500,
                letterSpacing: "0.06em",
                cursor: "pointer",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = "#C9A84C";
                e.currentTarget.style.color = "#0A1628";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = "transparent";
                e.currentTarget.style.color = "#C9A84C";
              }}
            >
              Found {count} in {tab} →
            </button>
          ))}
        </div>
      )}
      <button
        type="button"
        onClick={onReset}
        className="transition-all duration-150"
        style={{
          padding: "10px 20px",
          background: "#C9A84C",
          color: "#0A1628",
          border: "none",
          borderRadius: "6px",
          fontFamily: "var(--font-body)",
          fontWeight: 500,
          fontSize: "13.5px",
          cursor: "pointer",
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.background = "#B89A3E";
          e.currentTarget.style.transform = "scale(1.02)";
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.background = "#C9A84C";
          e.currentTarget.style.transform = "scale(1)";
        }}
      >
        Reset filters
      </button>
    </div>
  );
}

function LabeledInput({
  label,
  name,
  type = "text",
  required,
  value,
  onChange,
}: {
  label: string;
  name: string;
  type?: string;
  required?: boolean;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}) {
  const fieldId = `products-${name}`;
  return (
    <div>
      <label htmlFor={fieldId} className="block mb-2" style={{ color: "var(--color-foreground)" }}>
        {label}
      </label>
      <input
        id={fieldId}
        type={type}
        name={name}
        required={required}
        value={value}
        onChange={onChange}
        className="w-full px-4 py-3 rounded"
        style={{
          backgroundColor: "var(--color-input-background)",
          border: "1px solid var(--color-border)",
          color: "var(--color-foreground)",
        }}
      />
    </div>
  );
}
