import { Users, CheckCircle2, FileText, Shield, Microscope, Beaker, FileCheck, Award, CheckCheck } from "lucide-react";
import ScrollReveal from "../components/ScrollReveal";
import { useState, useEffect } from "react";

export default function Quality() {
  const [lineVisible, setLineVisible] = useState(false);

  // SEO: Set page title and meta tags
  useEffect(() => {
    document.title = "Quality Assurance | IP · BP · EP · USP Standards | J. B. Khokhani & Co.";

    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute("content", "JBK maintains rigorous quality standards aligned with IP, BP, EP, and USP pharmacopoeia. Full regulatory documentation — CoA, MSDS, DMF, and pharmacopoeial specifications — available for every consignment.");
    } else {
      const meta = document.createElement('meta');
      meta.name = "description";
      meta.content = "JBK maintains rigorous quality standards aligned with IP, BP, EP, and USP pharmacopoeia. Full regulatory documentation — CoA, MSDS, DMF, and pharmacopoeial specifications — available for every consignment.";
      document.head.appendChild(meta);
    }

    // Open Graph tags
    const ogTags = [
      { property: "og:title", content: "Quality Assurance | IP · BP · EP · USP Standards | J. B. Khokhani & Co." },
      { property: "og:description", content: "JBK maintains rigorous quality standards aligned with IP, BP, EP, and USP pharmacopoeia. Full regulatory documentation — CoA, MSDS, DMF, and pharmacopoeial specifications — available for every consignment." },
      { property: "og:type", content: "website" },
      { property: "og:site_name", content: "J. B. Khokhani & Co." },
      { property: "og:url", content: "https://www.jbkhokhani.com/quality" },
      { property: "og:image", content: "https://www.jbkhokhani.com/assets/1_without_background.png" },
    ];

    ogTags.forEach(({ property, content }) => {
      let tag = document.querySelector(`meta[property="${property}"]`);
      if (tag) {
        tag.setAttribute("content", content);
      } else {
        tag = document.createElement('meta');
        tag.setAttribute("property", property);
        tag.setAttribute("content", content);
        document.head.appendChild(tag);
      }
    });

    // Twitter Card tags
    const twitterTags = [
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "Quality Assurance | IP · BP · EP · USP Standards | J. B. Khokhani & Co." },
      { name: "twitter:description", content: "JBK maintains rigorous quality standards aligned with IP, BP, EP, and USP pharmacopoeia. Full regulatory documentation — CoA, MSDS, DMF, and pharmacopoeial specifications — available for every consignment." },
      { name: "twitter:image", content: "https://www.jbkhokhani.com/assets/1_without_background.png" },
    ];

    twitterTags.forEach(({ name, content }) => {
      let tag = document.querySelector(`meta[name="${name}"]`);
      if (tag) {
        tag.setAttribute("content", content);
      } else {
        tag = document.createElement('meta');
        tag.setAttribute("name", name);
        tag.setAttribute("content", content);
        document.head.appendChild(tag);
      }
    });

    // Canonical link
    let canonical = document.querySelector('link[rel="canonical"]');
    if (canonical) {
      canonical.setAttribute("href", "https://www.jbkhokhani.com/quality");
    } else {
      canonical = document.createElement('link');
      canonical.setAttribute("rel", "canonical");
      canonical.setAttribute("href", "https://www.jbkhokhani.com/quality");
      document.head.appendChild(canonical);
    }

    // Add additional SEO tags
    const additionalTags = [
      { name: "robots", content: "index, follow" },
      { name: "author", content: "J. B. Khokhani & Co." },
      { name: "geo.region", content: "IN-MH" },
      { name: "geo.placename", content: "Mumbai" },
      { name: "geo.position", content: "19.0176;72.8562" },
      { name: "ICBM", content: "19.0176, 72.8562" },
    ];

    additionalTags.forEach(({ name, content }) => {
      let tag = document.querySelector(`meta[name="${name}"]`);
      if (tag) {
        tag.setAttribute("content", content);
      } else {
        tag = document.createElement('meta');
        tag.setAttribute("name", name);
        tag.setAttribute("content", content);
        document.head.appendChild(tag);
      }
    });
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      setLineVisible(true);
    }, 300);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="min-h-screen">
      {/* Our Approach */}
      <section
        className="py-16 md:py-24 px-4 sm:px-6 lg:px-8 relative"
      >
        <div
          className="absolute inset-0 dark:hidden"
          style={{
            backgroundImage: `repeating-linear-gradient(
              45deg,
              rgba(10, 22, 40, 0.04),
              rgba(10, 22, 40, 0.04) 1px,
              transparent 1px,
              transparent 20px
            ),
            repeating-linear-gradient(
              -45deg,
              rgba(10, 22, 40, 0.04),
              rgba(10, 22, 40, 0.04) 1px,
              transparent 1px,
              transparent 20px
            )`,
          }}
        />
        <div
          className="absolute inset-0 hidden dark:block"
          style={{
            backgroundImage: `repeating-linear-gradient(
              45deg,
              rgba(240, 244, 255, 0.03),
              rgba(240, 244, 255, 0.03) 1px,
              transparent 1px,
              transparent 20px
            ),
            repeating-linear-gradient(
              -45deg,
              rgba(240, 244, 255, 0.03),
              rgba(240, 244, 255, 0.03) 1px,
              transparent 1px,
              transparent 20px
            )`,
          }}
        />
        <div className="max-w-6xl mx-auto relative z-10">
          <div className="mb-12">
            <div
              className="uppercase mb-4 text-[20px]"
              style={{
                fontFamily: "var(--font-mono)",
                letterSpacing: "0.15em",
                color: "#C9A84C",
              }}
            >
              Our Commitment
            </div>
            <h1
              className="text-4xl md:text-[52px] mb-4"
              style={{
                fontFamily: "var(--font-heading)",
                fontWeight: 700,
                color: "var(--color-foreground)",
              }}
            >
              Quality at Every Step
            </h1>
            <div
              className="h-0.5 transition-all duration-800"
              style={{
                backgroundColor: "#C9A84C",
                width: lineVisible ? "60px" : "0px",
                transitionTimingFunction: "ease-out",
              }}
            />
          </div>

          <h2
            className="text-3xl md:text-4xl mb-12 text-center"
            style={{
              fontFamily: "var(--font-heading)",
              fontWeight: 700,
              color: "var(--color-foreground)",
            }}
          >
            Our Approach
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12">
            <ScrollReveal delay={0}>
              <div className="space-y-4 transition-transform duration-300 hover:-translate-y-2">
                <div
                  className="w-16 h-16 rounded-full flex items-center justify-center transition-transform duration-300 hover:scale-110"
                  style={{ backgroundColor: "var(--color-accent)" }}
                >
                  <CheckCircle2 className="w-8 h-8" style={{ color: "var(--color-primary)" }} />
                </div>
                <h3
                  className="text-2xl"
                  style={{
                    fontFamily: "var(--font-heading)",
                    fontWeight: 600,
                    color: "var(--color-foreground)",
                  }}
                >
                  One-Stop Sourcing
                </h3>
                <p style={{ color: "var(--color-foreground)" }}>
                  Whether you need a single API or a full product basket, we
                  consolidate supply from multiple manufacturers so you don't have
                  to manage multiple vendors.
                </p>
              </div>
            </ScrollReveal>
            <ScrollReveal delay={0.08}>
              <div className="space-y-4 transition-transform duration-300 hover:-translate-y-2">
                <div
                  className="w-16 h-16 rounded-full flex items-center justify-center transition-transform duration-300 hover:scale-110"
                  style={{ backgroundColor: "var(--color-accent)" }}
                >
                  <Users className="w-8 h-8" style={{ color: "var(--color-primary)" }} />
                </div>
                <h3
                  className="text-2xl"
                  style={{
                    fontFamily: "var(--font-heading)",
                    fontWeight: 600,
                    color: "var(--color-foreground)",
                  }}
                >
                  Relationship-First
                </h3>
                <p style={{ color: "var(--color-foreground)" }}>
                  We've built 60 years of trust with manufacturers and clients
                  alike. That network is your advantage.
                </p>
              </div>
            </ScrollReveal>
            <ScrollReveal delay={0.16}>
              <div className="space-y-4 transition-transform duration-300 hover:-translate-y-2">
                <div
                  className="w-16 h-16 rounded-full flex items-center justify-center transition-transform duration-300 hover:scale-110"
                  style={{ backgroundColor: "var(--color-accent)" }}
                >
                  <FileText className="w-8 h-8" style={{ color: "var(--color-primary)" }} />
                </div>
                <h3
                  className="text-2xl"
                  style={{
                    fontFamily: "var(--font-heading)",
                    fontWeight: 600,
                    color: "var(--color-foreground)",
                  }}
                >
                  Regulatory Readiness
                </h3>
                <p style={{ color: "var(--color-foreground)" }}>
                  We understand what regulated markets require. Our documentation
                  support — DMFs, NDA filings, GMP certificates — means your
                  supply is always audit-ready.
                </p>
              </div>
            </ScrollReveal>
          </div>
        </div>
      </section>

      {/* Quality Framework */}
      <section className="py-16 md:py-24 px-4 sm:px-6 lg:px-8 relative" style={{ backgroundColor: "var(--color-section-bg)" }}>
        <div
          className="absolute inset-0 dark:hidden"
          style={{
            backgroundImage: `repeating-linear-gradient(
              45deg,
              rgba(10, 22, 40, 0.04),
              rgba(10, 22, 40, 0.04) 1px,
              transparent 1px,
              transparent 20px
            ),
            repeating-linear-gradient(
              -45deg,
              rgba(10, 22, 40, 0.04),
              rgba(10, 22, 40, 0.04) 1px,
              transparent 1px,
              transparent 20px
            )`,
          }}
        />
        <div
          className="absolute inset-0 hidden dark:block"
          style={{
            backgroundImage: `repeating-linear-gradient(
              45deg,
              rgba(240, 244, 255, 0.03),
              rgba(240, 244, 255, 0.03) 1px,
              transparent 1px,
              transparent 20px
            ),
            repeating-linear-gradient(
              -45deg,
              rgba(240, 244, 255, 0.03),
              rgba(240, 244, 255, 0.03) 1px,
              transparent 1px,
              transparent 20px
            )`,
          }}
        />
        <div className="max-w-6xl mx-auto relative z-10">
          <h2
            className="text-3xl md:text-4xl mb-4 text-center"
            style={{
              fontFamily: "var(--font-heading)",
              fontWeight: 700,
              color: "var(--color-foreground)",
            }}
          >
            Our Quality Framework
          </h2>
          <p
            className="text-lg mb-12 text-center max-w-3xl mx-auto"
            style={{
              fontFamily: "var(--font-body)",
              color: "var(--color-muted-foreground)"
            }}
          >
            At JBK, quality is not a checkbox — it's built into every step of how we work.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
            <ScrollReveal delay={0}>
              <div
                className="rounded-lg p-7 transition-all flex flex-col"
                style={{
                  backgroundColor: "var(--color-card)",
                  border: "1px solid var(--color-border)",
                  transitionDuration: "0.2s",
                  transitionTimingFunction: "ease",
                  minHeight: "260px",
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = "translateY(-4px)";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = "translateY(0)";
                }}
              >
                <Shield className="w-10 h-10 mb-0" style={{ color: "#C9A84C" }} strokeWidth={1.4} />
                <div style={{
                  height: "1px",
                  width: "44px",
                  backgroundColor: "#C9A84C",
                  marginTop: "16px",
                  marginBottom: "14px",
                }} aria-hidden="true" />
                <h3
                  className="text-[19px] mb-2 min-h-[2lh]"
                  style={{
                    fontFamily: "var(--font-heading)",
                    fontWeight: 600,
                    color: "var(--color-foreground)",
                  }}
                >
                  GMP-Compliant Sourcing
                </h3>
                <p
                  className="text-sm leading-[1.7] min-h-[3lh]"
                  style={{
                    fontFamily: "var(--font-body)",
                    color: "var(--color-muted-foreground)",
                  }}
                >
                  All manufacturers are verified against GMP standards before onboarding
                </p>
              </div>
            </ScrollReveal>

            <ScrollReveal delay={0.08}>
              <div
                className="rounded-lg p-7 transition-all flex flex-col"
                style={{
                  backgroundColor: "var(--color-card)",
                  border: "1px solid var(--color-border)",
                  transitionDuration: "0.2s",
                  transitionTimingFunction: "ease",
                  minHeight: "260px",
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = "translateY(-4px)";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = "translateY(0)";
                }}
              >
                <CheckCheck className="w-10 h-10 mb-0" style={{ color: "#C9A84C" }} strokeWidth={1.4} />
                <div style={{
                  height: "1px",
                  width: "44px",
                  backgroundColor: "#C9A84C",
                  marginTop: "16px",
                  marginBottom: "14px",
                }} aria-hidden="true" />
                <h3
                  className="text-[19px] mb-2 min-h-[2lh]"
                  style={{
                    fontFamily: "var(--font-heading)",
                    fontWeight: 600,
                    color: "var(--color-foreground)",
                  }}
                >
                  Multi-Stage Quality Checks
                </h3>
                <p
                  className="text-sm leading-[1.7] min-h-[3lh]"
                  style={{
                    fontFamily: "var(--font-body)",
                    color: "var(--color-muted-foreground)",
                  }}
                >
                  From raw material to final delivery, every batch is verified
                </p>
              </div>
            </ScrollReveal>

            <ScrollReveal delay={0.16}>
              <div
                className="rounded-lg p-7 transition-all flex flex-col"
                style={{
                  backgroundColor: "var(--color-card)",
                  border: "1px solid var(--color-border)",
                  transitionDuration: "0.2s",
                  transitionTimingFunction: "ease",
                  minHeight: "260px",
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = "translateY(-4px)";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = "translateY(0)";
                }}
              >
                <Microscope className="w-10 h-10 mb-0" style={{ color: "#C9A84C" }} strokeWidth={1.4} />
                <div style={{
                  height: "1px",
                  width: "44px",
                  backgroundColor: "#C9A84C",
                  marginTop: "16px",
                  marginBottom: "14px",
                }} aria-hidden="true" />
                <h3
                  className="text-[19px] mb-2 min-h-[2lh]"
                  style={{
                    fontFamily: "var(--font-heading)",
                    fontWeight: 600,
                    color: "var(--color-foreground)",
                  }}
                >
                  Microbiological & Chemical Testing
                </h3>
                <p
                  className="text-sm leading-[1.7] min-h-[3lh]"
                  style={{
                    fontFamily: "var(--font-body)",
                    color: "var(--color-muted-foreground)",
                  }}
                >
                  Full lab testing support including heavy metal analysis via ICP-MS
                </p>
              </div>
            </ScrollReveal>

            <ScrollReveal delay={0.24}>
              <div
                className="rounded-lg p-7 transition-all flex flex-col"
                style={{
                  backgroundColor: "var(--color-card)",
                  border: "1px solid var(--color-border)",
                  transitionDuration: "0.2s",
                  transitionTimingFunction: "ease",
                  minHeight: "260px",
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = "translateY(-4px)";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = "translateY(0)";
                }}
              >
                <Beaker className="w-10 h-10 mb-0" style={{ color: "#C9A84C" }} strokeWidth={1.4} />
                <div style={{
                  height: "1px",
                  width: "44px",
                  backgroundColor: "#C9A84C",
                  marginTop: "16px",
                  marginBottom: "14px",
                }} aria-hidden="true" />
                <h3
                  className="text-[19px] mb-2 min-h-[2lh]"
                  style={{
                    fontFamily: "var(--font-heading)",
                    fontWeight: 600,
                    color: "var(--color-foreground)",
                  }}
                >
                  Stability Testing
                </h3>
                <p
                  className="text-sm leading-[1.7] min-h-[3lh]"
                  style={{
                    fontFamily: "var(--font-body)",
                    color: "var(--color-muted-foreground)",
                  }}
                >
                  Shelf-life documentation and accelerated stability data available
                </p>
              </div>
            </ScrollReveal>

            <ScrollReveal delay={0.32}>
              <div
                className="rounded-lg p-7 transition-all flex flex-col"
                style={{
                  backgroundColor: "var(--color-card)",
                  border: "1px solid var(--color-border)",
                  transitionDuration: "0.2s",
                  transitionTimingFunction: "ease",
                  minHeight: "260px",
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = "translateY(-4px)";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = "translateY(0)";
                }}
              >
                <Award className="w-10 h-10 mb-0" style={{ color: "#C9A84C" }} strokeWidth={1.4} />
                <div style={{
                  height: "1px",
                  width: "44px",
                  backgroundColor: "#C9A84C",
                  marginTop: "16px",
                  marginBottom: "14px",
                }} aria-hidden="true" />
                <h3
                  className="text-[19px] mb-2 min-h-[2lh]"
                  style={{
                    fontFamily: "var(--font-heading)",
                    fontWeight: 600,
                    color: "var(--color-foreground)",
                  }}
                >
                  Pharmacopoeial Standards
                </h3>
                <p
                  className="text-sm leading-[1.7] min-h-[3lh]"
                  style={{
                    fontFamily: "var(--font-body)",
                    color: "var(--color-muted-foreground)",
                  }}
                >
                  IP, BP, EP, and USP grade materials with validated test methods
                </p>
              </div>
            </ScrollReveal>

            <ScrollReveal delay={0.4}>
              <div
                className="rounded-lg p-7 transition-all flex flex-col"
                style={{
                  backgroundColor: "var(--color-card)",
                  border: "1px solid var(--color-border)",
                  transitionDuration: "0.2s",
                  transitionTimingFunction: "ease",
                  minHeight: "260px",
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = "translateY(-4px)";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = "translateY(0)";
                }}
              >
                <FileCheck className="w-10 h-10 mb-0" style={{ color: "#C9A84C" }} strokeWidth={1.4} />
                <div style={{
                  height: "1px",
                  width: "44px",
                  backgroundColor: "#C9A84C",
                  marginTop: "16px",
                  marginBottom: "14px",
                }} aria-hidden="true" />
                <h3
                  className="text-[19px] mb-2 min-h-[2lh]"
                  style={{
                    fontFamily: "var(--font-heading)",
                    fontWeight: 600,
                    color: "var(--color-foreground)",
                  }}
                >
                  Regulatory Documentation
                </h3>
                <p
                  className="text-sm leading-[1.7] min-h-[3lh]"
                  style={{
                    fontFamily: "var(--font-body)",
                    color: "var(--color-muted-foreground)",
                  }}
                >
                  DMFs, CoAs, GMP certificates — all audit-ready
                </p>
              </div>
            </ScrollReveal>
          </div>

          {/* Standards Badges */}
          <div className="mb-16">
            <h3
              className="text-xl mb-6 text-center"
              style={{
                fontFamily: "var(--font-heading)",
                fontWeight: 600,
                color: "var(--color-foreground)",
              }}
            >
              Standards We Work To
            </h3>
            <div className="flex flex-wrap justify-center gap-3">
              {["IP", "BP", "EP", "USP"].map((standard, index) => (
                <ScrollReveal key={standard} delay={index * 0.08}>
                  <span
                    className="px-4 py-2 rounded-full text-sm font-medium bg-[#0A1628] text-white dark:bg-[#162236] dark:text-[#C9A84C] dark:border-[#C9A84C]"
                    style={{
                      fontFamily: "var(--font-mono)",
                      letterSpacing: "0.05em",
                    }}
                  >
                    {standard}
                  </span>
                </ScrollReveal>
              ))}
            </div>
          </div>

          {/* Documentation Section */}
          <div>
            <h2
              className="text-3xl md:text-[32px] mb-8 text-center"
              style={{
                fontFamily: "var(--font-heading)",
                fontWeight: 600,
                color: "var(--color-foreground)",
              }}
            >
              Documentation We Support
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 max-w-4xl mx-auto">
              <ScrollReveal delay={0}>
                <div
                  className="rounded-lg p-5 transition-all"
                  style={{
                    backgroundColor: "var(--color-card)",
                    border: "1px solid var(--color-border)",
                    borderTop: "3px solid #C9A84C",
                    transitionDuration: "0.2s",
                    transitionTimingFunction: "ease",
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.transform = "translateY(-4px)";
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.transform = "translateY(0)";
                  }}
                >
                  <FileText className="w-7 h-7 mb-3" style={{ color: "#C9A84C" }} strokeWidth={1.5} />
                  <h3
                    className="text-base"
                    style={{
                      fontFamily: "var(--font-body)",
                      fontWeight: 600,
                      color: "var(--color-foreground)",
                    }}
                  >
                    Drug Master Files (DMFs)
                  </h3>
                </div>
              </ScrollReveal>

              <ScrollReveal delay={0.08}>
                <div
                  className="rounded-lg p-5 transition-all"
                  style={{
                    backgroundColor: "var(--color-card)",
                    border: "1px solid var(--color-border)",
                    borderTop: "3px solid #C9A84C",
                    transitionDuration: "0.2s",
                    transitionTimingFunction: "ease",
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.transform = "translateY(-4px)";
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.transform = "translateY(0)";
                  }}
                >
                  <FileText className="w-7 h-7 mb-3" style={{ color: "#C9A84C" }} strokeWidth={1.5} />
                  <h3
                    className="text-base"
                    style={{
                      fontFamily: "var(--font-body)",
                      fontWeight: 600,
                      color: "var(--color-foreground)",
                    }}
                  >
                    NDA Filing Documentation
                  </h3>
                </div>
              </ScrollReveal>

              <ScrollReveal delay={0.16}>
                <div
                  className="rounded-lg p-5 transition-all"
                  style={{
                    backgroundColor: "var(--color-card)",
                    border: "1px solid var(--color-border)",
                    borderTop: "3px solid #C9A84C",
                    transitionDuration: "0.2s",
                    transitionTimingFunction: "ease",
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.transform = "translateY(-4px)";
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.transform = "translateY(0)";
                  }}
                >
                  <FileText className="w-7 h-7 mb-3" style={{ color: "#C9A84C" }} strokeWidth={1.5} />
                  <h3
                    className="text-base"
                    style={{
                      fontFamily: "var(--font-body)",
                      fontWeight: 600,
                      color: "var(--color-foreground)",
                    }}
                  >
                    Certificate of Analysis (CoA)
                  </h3>
                </div>
              </ScrollReveal>

              <ScrollReveal delay={0.24}>
                <div
                  className="rounded-lg p-5 transition-all"
                  style={{
                    backgroundColor: "var(--color-card)",
                    border: "1px solid var(--color-border)",
                    borderTop: "3px solid #C9A84C",
                    transitionDuration: "0.2s",
                    transitionTimingFunction: "ease",
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.transform = "translateY(-4px)";
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.transform = "translateY(0)";
                  }}
                >
                  <FileText className="w-7 h-7 mb-3" style={{ color: "#C9A84C" }} strokeWidth={1.5} />
                  <h3
                    className="text-base"
                    style={{
                      fontFamily: "var(--font-body)",
                      fontWeight: 600,
                      color: "var(--color-foreground)",
                    }}
                  >
                    GMP Compliance Certificates
                  </h3>
                </div>
              </ScrollReveal>
            </div>
          </div>

          {/* ═══════════════ C7 · Download Our Certificates ═══════════════ */}
          <div className="mt-20">
            <div className="text-center mb-10">
              <div
                className="inline-flex items-center gap-3 mb-4"
                style={{
                  fontFamily: "var(--font-mono)",
                  fontSize: "12px",
                  letterSpacing: "0.2em",
                  textTransform: "uppercase",
                  color: "#C9A84C",
                  fontWeight: 500,
                }}
              >
                <span style={{ width: "24px", height: "1px", background: "#C9A84C" }} />
                Regulatory &amp; Compliance
                <span style={{ width: "24px", height: "1px", background: "#C9A84C" }} />
              </div>
              <h2
                className="text-3xl md:text-4xl mb-4"
                style={{
                  fontFamily: "var(--font-heading)",
                  fontWeight: 700,
                  color: "var(--color-foreground)",
                }}
              >
                Download Our Certificates
              </h2>
              <p
                className="max-w-2xl mx-auto"
                style={{
                  fontSize: "15.5px",
                  lineHeight: 1.65,
                  color: "var(--color-muted-foreground)",
                }}
              >
                Our active regulatory and compliance registrations, available for download.
              </p>
            </div>

            <div
              className="certs-grid mx-auto"
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(6, 1fr)",
                gap: "20px",
                maxWidth: "1100px",
              }}
            >
              <CertCard
                title="Drug License"
                authority="CDSCO · Form 20 B & 21 B"
                description="Our authorisation to manufacture, distribute, and sell drugs under the Drugs & Cosmetics Act, 1940."
                href="/certificates/drug-license.pdf"
                pages={2}
                gridColumn="span 2"
                icon={
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" style={{ width: "26px", height: "26px" }}>
                    <path d="M21 11.5V7a2 2 0 0 0-2-2h-2.5l-1-2h-7l-1 2H5a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h7" />
                    <path d="M15 17h6M18 14v6" />
                  </svg>
                }
              />
              <CertCard
                title="GST Registration"
                authority="Govt. of India · Tax Registration"
                description="Goods and Services Tax registration certificate — current and in good standing."
                href="/certificates/gst-registration.pdf"
                pages={3}
                gridColumn="span 2"
                icon={
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" style={{ width: "26px", height: "26px" }}>
                    <rect x="3" y="4" width="18" height="18" rx="2" />
                    <path d="M3 10h18M8 4v4" />
                    <path d="M9 16l3-3 3 3" strokeWidth="1.6" />
                    <line x1="12" y1="13" x2="12" y2="19" strokeWidth="1.6" />
                  </svg>
                }
              />
              <CertCard
                title="Export House"
                authority="DGFT · Ministry of Commerce"
                description="Export House status granted under India's Foreign Trade Policy — confirms our export credentials."
                href="/certificates/export-house-certificate.pdf"
                pages={1}
                gridColumn="span 2"
                icon={
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" style={{ width: "26px", height: "26px" }}>
                    <circle cx="12" cy="12" r="10" />
                    <ellipse cx="12" cy="12" rx="4" ry="10" />
                    <line x1="2" y1="12" x2="22" y2="12" />
                  </svg>
                }
              />
              {/* Row 2 — 2 centred cards */}
              <CertCard
                title="ISO Certificate"
                authority="ISO · Quality Management System"
                description="International Standards Organisation certification covering our quality management system."
                href="/certificates/iso-certificate.pdf"
                pages={1}
                gridColumn="2 / span 2"
                icon={
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" style={{ width: "26px", height: "26px" }}>
                    <path d="M12 2l9 4.5v6c0 5-3.5 9-9 10-5.5-1-9-5-9-10v-6l9-4.5z" />
                    <path d="M9 12l2 2 4-4" strokeWidth="2" />
                  </svg>
                }
              />
              <CertCard
                title="FSSAI Licenses"
                authority="FSSAI · Central & State"
                description="Food Safety & Standards Authority of India — licenses for nutraceutical and food-grade ingredient trade."
                href="/certificates/fssai-licenses.pdf"
                pages={2}
                gridColumn="4 / span 2"
                isFssai
                icon={<FssaiSealIcon />}
              />
            </div>

            {/* WhatsApp compliance footnote */}
            <p
              className="text-center mx-auto"
              style={{
                marginTop: "44px",
                fontSize: "13px",
                color: "var(--color-muted-foreground)",
                maxWidth: "640px",
                lineHeight: 1.7,
              }}
            >
              For additional documents or compliance queries,{" "}
              <a
                href="https://wa.me/919821433393?text=Hello%2C%20This%20is%20reference%20to%20the%20documents%20on%20the%20website.%20%20I%20have%20a%20query%20regarding%20your%20compliance%20documentation%20and%20certificates.%20Could%20you%20please%20assist%3F"
                target="_blank"
                rel="noopener noreferrer"
                className="whatsapp-link inline-flex items-center gap-1.5"
                style={{
                  color: "var(--color-compliance-link)",
                  textDecoration: "none",
                  paddingBottom: "1px",
                  borderBottom: "1px solid var(--color-compliance-link-border)",
                  transition: "color 180ms ease, border-color 180ms ease",
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.color = "var(--color-foreground)";
                  e.currentTarget.style.borderBottomColor = "var(--color-foreground)";
                  const svg = e.currentTarget.querySelector("svg");
                  if (svg) (svg as SVGElement).style.color = "var(--wa-green-hover)";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.color = "var(--color-compliance-link)";
                  e.currentTarget.style.borderBottomColor = "var(--color-compliance-link-border)";
                  const svg = e.currentTarget.querySelector("svg");
                  if (svg) (svg as SVGElement).style.color = "var(--wa-green)";
                }}
              >
                <svg
                  viewBox="0 0 24 24"
                  fill="currentColor"
                  aria-hidden="true"
                  style={{
                    width: "14px",
                    height: "14px",
                    color: "var(--wa-green)",
                    transition: "color 180ms ease",
                  }}
                >
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                </svg>
                contact our compliance team &rarr;
              </a>
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}

/* ─────────── C7 · Certificate card helpers ─────────── */

function CertCard({
  title,
  authority,
  description,
  href,
  pages,
  icon,
  gridColumn,
  isFssai = false,
}: {
  title: string;
  authority: string;
  description: string;
  href: string;
  pages: number;
  icon: React.ReactNode;
  gridColumn: string;
  isFssai?: boolean;
}) {
  return (
    <article
      className="cert-card"
      data-fssai={isFssai ? "true" : undefined}
      style={{
        gridColumn,
        background: "var(--color-card)",
        border: "1px solid var(--color-border)",
        borderRadius: "12px",
        padding: "28px 24px 24px",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        textAlign: "center",
        gap: "14px",
        position: "relative",
        transition: "border-color 180ms ease, transform 180ms ease, box-shadow 180ms ease",
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.borderColor = "rgba(201, 168, 76, 0.55)";
        e.currentTarget.style.transform = "translateY(-3px)";
        e.currentTarget.style.boxShadow = "0 14px 30px rgba(10, 22, 40, 0.08)";
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.borderColor = "var(--color-border)";
        e.currentTarget.style.transform = "translateY(0)";
        e.currentTarget.style.boxShadow = "none";
      }}
    >
      <div
        className={`cert-icon-wrap${isFssai ? " fssai-icon" : ""}`}
        style={{
          width: "54px",
          height: "54px",
          display: "grid",
          placeItems: "center",
          borderRadius: "50%",
          background: "rgba(201, 168, 76, 0.1)",
          color: "#C9A84C",
          marginBottom: "2px",
        }}
      >
        {icon}
      </div>

      <h3
        className="cert-title m-0"
        style={{
          fontFamily: "var(--font-heading)",
          fontWeight: 700,
          fontSize: "19px",
          lineHeight: 1.2,
          letterSpacing: "-0.005em",
          color: "var(--color-foreground)",
        }}
      >
        {title}
      </h3>

      <p
        className="cert-authority m-0"
        style={{
          fontFamily: "var(--font-mono)",
          fontSize: "10.5px",
          letterSpacing: "0.14em",
          textTransform: "uppercase",
          color: "var(--color-muted-foreground)",
          fontWeight: 500,
          marginTop: "-6px",
        }}
      >
        {authority}
      </p>

      <p
        className="cert-desc m-0"
        style={{
          fontSize: "13.5px",
          color: "var(--color-muted-foreground)",
          lineHeight: 1.55,
          maxWidth: "260px",
        }}
      >
        {description}
      </p>

      <a
        className="cert-download"
        href={href}
        target="_blank"
        rel="noopener noreferrer"
        download
        style={{
          display: "inline-flex",
          alignItems: "center",
          gap: "8px",
          padding: "11px 20px",
          marginTop: "4px",
          background: "transparent",
          color: "var(--color-foreground)",
          border: "1px solid var(--color-border)",
          borderRadius: "6px",
          fontFamily: "var(--font-body)",
          fontWeight: 500,
          fontSize: "13.5px",
          textDecoration: "none",
          cursor: "pointer",
          transition: "background-color 180ms ease, color 180ms ease, border-color 180ms ease, transform 180ms ease",
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.background = "#C9A84C";
          e.currentTarget.style.color = "#0A1628";
          e.currentTarget.style.borderColor = "#C9A84C";
          e.currentTarget.style.transform = "scale(1.02)";
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.background = "transparent";
          e.currentTarget.style.color = "var(--color-foreground)";
          e.currentTarget.style.borderColor = "var(--color-border)";
          e.currentTarget.style.transform = "scale(1)";
        }}
      >
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          aria-hidden="true"
          style={{ width: "14px", height: "14px" }}
        >
          <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
          <polyline points="7 10 12 15 17 10" />
          <line x1="12" y1="15" x2="12" y2="3" />
        </svg>
        Download PDF
      </a>

      <div
        className="cert-meta"
        style={{
          fontFamily: "var(--font-mono)",
          fontSize: "11px",
          letterSpacing: "0.08em",
          color: "var(--color-muted-foreground)",
          marginTop: "auto",
          paddingTop: "6px",
        }}
      >
        {pages} page{pages === 1 ? "" : "s"}
      </div>
    </article>
  );
}

/** FSSAI — concentric seal with check, 34px (1.31× larger than other icons). */
function FssaiSealIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="#C9A84C"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      style={{ width: "34px", height: "34px" }}
    >
      <circle cx="12" cy="12" r="9" strokeWidth="2" />
      <circle cx="12" cy="12" r="5.5" strokeWidth="1.2" strokeDasharray="1.5 1.5" />
      <path d="m9 12 2 2 4-4" strokeWidth="2" />
    </svg>
  );
}
