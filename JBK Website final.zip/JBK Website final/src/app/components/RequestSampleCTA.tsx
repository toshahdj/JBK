import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";

/**
 * Request a Sample CTA — renders below the Nutraceuticals flagship block.
 * Dropdown picks one of the 3 flagships (or "Other"). On submit, navigates
 * to /contact with URL params so the inquiry form pre-fills.
 *
 * R2.4 (revises C5): migrated from native <select> to shadcn Select so the
 * popover follows our theme in dark mode. Layout split: dropdown + button
 * on a top row, "Other" input expands as a separate row beneath.
 */
export default function RequestSampleCTA() {
  const [product, setProduct] = useState("");
  const [otherName, setOtherName] = useState("");
  const navigate = useNavigate();
  const otherInputRef = useRef<HTMLInputElement>(null);

  const isOther = product === "other";
  const isValid =
    (product && product !== "other") ||
    (product === "other" && otherName.trim().length > 0);

  useEffect(() => {
    if (isOther) {
      // Short delay to let the grid-rows transition complete before focusing
      const t = setTimeout(() => otherInputRef.current?.focus(), 50);
      return () => clearTimeout(t);
    }
  }, [isOther]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isValid) return;

    if (product === "other") {
      navigate(
        `/contact?product=other&productName=${encodeURIComponent(otherName.trim())}`
      );
    } else {
      navigate(`/contact?product=${product}`);
    }
  };

  return (
    <section
      className="py-10 md:py-12 px-4 sm:px-6 lg:px-8"
      style={{ backgroundColor: "var(--color-section-bg)" }}
    >
      <div className="max-w-6xl mx-auto">
        <div
          className="rounded-2xl px-6 py-8 md:px-11 md:py-10 text-center"
          style={{
            backgroundColor: "var(--color-card)",
            border: "1px solid var(--color-border)",
          }}
        >
          <form
            onSubmit={handleSubmit}
            className="flex flex-col items-center gap-3"
            noValidate
          >
            {/* Top row: dropdown + submit button */}
            <div className="flex flex-wrap gap-3 items-stretch justify-center w-full">
              <div className="flex-1" style={{ minWidth: "280px", maxWidth: "340px" }}>
                <Select value={product} onValueChange={setProduct}>
                  <SelectTrigger
                    aria-label="Select a product for sample request"
                    style={{
                      fontFamily: "var(--font-body)",
                      fontSize: "15px",
                      height: "auto",
                      padding: "12px 18px",
                      border: "1px solid var(--color-border)",
                      borderRadius: "6px",
                      backgroundColor: "var(--color-input-background)",
                      color: "var(--color-foreground)",
                    }}
                  >
                    <SelectValue placeholder="I'd like a sample of…" />
                  </SelectTrigger>
                  <SelectContent
                    style={{
                      backgroundColor: "var(--color-card)",
                      border: "1px solid var(--color-border)",
                      color: "var(--color-foreground)",
                    }}
                  >
                    <SelectItem value="pine-d3">PineD3™ — Vegan Vitamin D3</SelectItem>
                    <SelectItem value="menaquingold">MenaquinGold® — Natural Vitamin K2-7</SelectItem>
                    <SelectItem value="caffeine-anhydrous">Caffeine Anhydrous</SelectItem>
                    <SelectItem value="other">Other — please specify</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <button
                type="submit"
                disabled={!isValid}
                className="inline-flex items-center gap-2 transition-all duration-200"
                style={{
                  padding: "12px 26px",
                  borderRadius: "6px",
                  fontFamily: "var(--font-body)",
                  fontWeight: 500,
                  fontSize: "15px",
                  border: "none",
                  backgroundColor: isValid
                    ? "var(--color-accent-terracotta)"
                    : "var(--color-border)",
                  color: isValid ? "#FFFFFF" : "var(--color-muted-foreground)",
                  cursor: isValid ? "pointer" : "not-allowed",
                  whiteSpace: "nowrap",
                  opacity: isValid ? 1 : 0.7,
                }}
                onMouseEnter={(e) => {
                  if (isValid) {
                    e.currentTarget.style.backgroundColor = "#A85C38";
                    e.currentTarget.style.transform = "scale(1.02)";
                  }
                }}
                onMouseLeave={(e) => {
                  if (isValid) {
                    e.currentTarget.style.backgroundColor = "var(--color-accent-terracotta)";
                    e.currentTarget.style.transform = "scale(1)";
                  }
                }}
              >
                Request a Sample
                <span style={{ fontFamily: "var(--font-mono)" }}>→</span>
              </button>
            </div>

            {/* 'Other' expand-on-select field — full-width row beneath */}
            <div
              className="w-full mx-auto"
              style={{
                maxWidth: "520px",
                display: "grid",
                gridTemplateRows: isOther ? "1fr" : "0fr",
                opacity: isOther ? 1 : 0,
                transition: "grid-template-rows 280ms ease, opacity 280ms ease",
              }}
              aria-hidden={!isOther}
            >
              <div style={{ overflow: "hidden" }}>
                <input
                  ref={otherInputRef}
                  type="text"
                  value={otherName}
                  onChange={(e) => setOtherName(e.target.value)}
                  placeholder="e.g. Alpha Lipoic Acid, Methylcobalamin, Curcumin…"
                  aria-label="Specify the ingredient"
                  className="w-full"
                  style={{
                    fontFamily: "var(--font-body)",
                    fontSize: "15px",
                    padding: "12px 18px",
                    border: "1px solid var(--color-border)",
                    borderRadius: "6px",
                    backgroundColor: "var(--color-input-background)",
                    color: "var(--color-foreground)",
                    marginTop: "4px",
                  }}
                />
              </div>
            </div>
          </form>
        </div>
      </div>
    </section>
  );
}
