import { Link, useLocation } from "react-router";
import { Sun, Moon, Menu, X } from "lucide-react";
import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import useReducedMotion from "../hooks/useReducedMotion";
import logoImage from "../../imports/1_without_background.png";

interface NavigationProps {
  darkMode: boolean;
  toggleTheme: () => void;
}

export default function Navigation({ darkMode, toggleTheme }: NavigationProps) {
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const reducedMotion = useReducedMotion();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 60);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Lock body scroll while the mobile overlay is open
  useEffect(() => {
    if (typeof document === "undefined") return;
    if (mobileMenuOpen) {
      const prev = document.body.style.overflow;
      document.body.style.overflow = "hidden";
      return () => {
        document.body.style.overflow = prev;
      };
    }
  }, [mobileMenuOpen]);

  // Close overlay when route changes (hamburger stays in sync with navigation)
  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location.pathname]);

  const navLinks = [
    { path: "/", label: "Home" },
    { path: "/about", label: "About" },
    { path: "/quality", label: "Quality" },
    { path: "/products", label: "Products" },
    { path: "/services", label: "Services" },
    { path: "/presence", label: "Presence" },
    { path: "/contact", label: "Contact" },
  ];

  return (
    <nav
      className="sticky top-0 z-50"
      style={{
        backgroundColor: "var(--color-nav-bg)",
        boxShadow: scrolled
          ? darkMode
            ? "0 2px 20px rgba(0,0,0,0.4)"
            : "0 2px 20px rgba(0,0,0,0.12)"
          : "none",
        transition: "box-shadow 0.3s ease",
      }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-3 transition-transform duration-300 hover:scale-105">
            <img
              src={logoImage}
              alt="J. B. Khokhani & Co. — Pharmaceutical API Supplier Since 1965"
              className="h-12 w-auto md:h-16"
            />
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className="text-[15px] text-white relative group"
                style={{ fontFamily: "var(--font-body)", fontWeight: 500 }}
              >
                {link.label}
                <span
                  className="absolute -bottom-1 left-0 h-[1.5px] transition-all"
                  style={{
                    backgroundColor: "#C9A84C",
                    width: location.pathname === link.path ? "100%" : "0%",
                    transitionDuration: "0.25s",
                    transitionTimingFunction: "ease-out",
                  }}
                />
                {location.pathname !== link.path && (
                  <span
                    className="absolute -bottom-1 left-0 h-[1.5px] w-0 group-hover:w-full transition-all"
                    style={{
                      backgroundColor: "#C9A84C",
                      transitionDuration: "0.25s",
                      transitionTimingFunction: "ease-out",
                    }}
                  />
                )}
              </Link>
            ))}
            {/* Desktop Theme Toggle Slider */}
            <button
              onClick={toggleTheme}
              className="relative ml-2 rounded-full transition-all duration-200"
              style={{
                width: "48px",
                height: "26px",
                background: darkMode
                  ? "linear-gradient(135deg, #1A2A45, #243550, #0F1E35)"
                  : "linear-gradient(135deg, #C9A84C, #E8C96A, #A8882E)",
                border: darkMode ? "1px solid rgba(100, 140, 200, 0.2)" : "1px solid rgba(180, 140, 40, 0.4)",
                boxShadow: darkMode ? "inset 0 1px 3px rgba(0,0,0,0.4)" : "inset 0 1px 3px rgba(0,0,0,0.15)",
                transition: "background 0.35s ease, box-shadow 0.2s ease",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.boxShadow = darkMode
                  ? "inset 0 1px 3px rgba(0,0,0,0.4), 0 0 0 3px rgba(201, 168, 76, 0.2)"
                  : "inset 0 1px 3px rgba(0,0,0,0.15), 0 0 0 3px rgba(201, 168, 76, 0.2)";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.boxShadow = darkMode
                  ? "inset 0 1px 3px rgba(0,0,0,0.4)"
                  : "inset 0 1px 3px rgba(0,0,0,0.15)";
              }}
              aria-label={darkMode ? "Switch to light mode" : "Switch to dark mode"}
              aria-pressed={darkMode}
            >
              <div
                className="absolute top-[3px] rounded-full"
                style={{
                  width: "20px",
                  height: "20px",
                  background: darkMode
                    ? "linear-gradient(135deg, #A8A8B0, #D0D0D8, #E8E8F0)"
                    : "linear-gradient(135deg, #D4AF37, #FFD700, #C9A84C)",
                  boxShadow: darkMode
                    ? "0 1px 4px rgba(0,0,0,0.4), 0 0 0 1px rgba(200,168,76,0.2)"
                    : "0 1px 4px rgba(0,0,0,0.25), 0 0 0 1px rgba(200,168,76,0.3)",
                  transform: darkMode ? "translateX(4px)" : "translateX(24px)",
                  transition: "transform 0.35s cubic-bezier(0.16, 1, 0.3, 1), background 0.35s ease",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  lineHeight: 0,
                }}
              >
                {darkMode ? (
                  <Moon
                    size={12}
                    strokeWidth={2.5}
                    style={{ color: "#0A1628", display: "block", flexShrink: 0 }}
                  />
                ) : (
                  <Sun
                    size={12}
                    strokeWidth={2.5}
                    style={{ color: "#FFFFFF", display: "block", flexShrink: 0 }}
                  />
                )}
              </div>
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center space-x-6">
            {/* Mobile Theme Toggle Slider — slides in when menu opens */}
            <AnimatePresence initial={false}>
              {mobileMenuOpen && (
                <motion.div
                  initial={{ width: 0, opacity: 0, marginRight: 0 }}
                  animate={{ width: "48px", opacity: 1, marginRight: 0 }}
                  exit={{ width: 0, opacity: 0, marginRight: 0 }}
                  transition={{ duration: reducedMotion ? 0 : 0.28, ease: [0.16, 1, 0.3, 1] }}
                  style={{ overflow: "hidden", display: "flex", alignItems: "center" }}
                >
                  <button
                    onClick={toggleTheme}
                    className="relative rounded-full transition-all duration-200 flex-shrink-0"
                    style={{
                      width: "48px",
                      height: "26px",
                      background: darkMode
                        ? "linear-gradient(135deg, #1A2A45, #243550, #0F1E35)"
                        : "linear-gradient(135deg, #C9A84C, #E8C96A, #A8882E)",
                      border: darkMode ? "1px solid rgba(100, 140, 200, 0.2)" : "1px solid rgba(180, 140, 40, 0.4)",
                      boxShadow: darkMode ? "inset 0 1px 3px rgba(0,0,0,0.4)" : "inset 0 1px 3px rgba(0,0,0,0.15)",
                      transition: "background 0.35s ease, box-shadow 0.2s ease",
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.boxShadow = darkMode
                        ? "inset 0 1px 3px rgba(0,0,0,0.4), 0 0 0 3px rgba(201, 168, 76, 0.2)"
                        : "inset 0 1px 3px rgba(0,0,0,0.15), 0 0 0 3px rgba(201, 168, 76, 0.2)";
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.boxShadow = darkMode
                        ? "inset 0 1px 3px rgba(0,0,0,0.4)"
                        : "inset 0 1px 3px rgba(0,0,0,0.15)";
                    }}
                    aria-label={darkMode ? "Switch to light mode" : "Switch to dark mode"}
                    aria-pressed={darkMode}
                  >
                    <div
                      className="absolute top-[3px] rounded-full"
                      style={{
                        width: "20px",
                        height: "20px",
                        background: darkMode
                          ? "linear-gradient(135deg, #A8A8B0, #D0D0D8, #E8E8F0)"
                          : "linear-gradient(135deg, #D4AF37, #FFD700, #C9A84C)",
                        boxShadow: darkMode
                          ? "0 1px 4px rgba(0,0,0,0.4), 0 0 0 1px rgba(200,168,76,0.2)"
                          : "0 1px 4px rgba(0,0,0,0.25), 0 0 0 1px rgba(200,168,76,0.3)",
                        transform: darkMode ? "translateX(4px)" : "translateX(24px)",
                        transition: "transform 0.35s cubic-bezier(0.16, 1, 0.3, 1), background 0.35s ease",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        lineHeight: 0,
                      }}
                    >
                      {darkMode ? (
                        <Moon
                          size={12}
                          strokeWidth={2.5}
                          style={{ color: "#0A1628", display: "block", flexShrink: 0 }}
                        />
                      ) : (
                        <Sun
                          size={12}
                          strokeWidth={2.5}
                          style={{ color: "#FFFFFF", display: "block", flexShrink: 0 }}
                        />
                      )}
                    </div>
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-white"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? (
                <X className="w-6 h-6" />
              ) : (
                <Menu className="w-6 h-6" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu — full-screen slide-up overlay */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            className="md:hidden fixed left-0 right-0 bottom-0 z-40 overflow-y-auto"
            style={{
              top: "64px", // matches nav h-16 on mobile
              backgroundColor: "var(--color-nav-bg)",
              backgroundImage: `repeating-linear-gradient(
                45deg,
                rgba(201, 168, 76, 0.045),
                rgba(201, 168, 76, 0.045) 1px,
                transparent 1px,
                transparent 24px
              ),
              repeating-linear-gradient(
                -45deg,
                rgba(201, 168, 76, 0.045),
                rgba(201, 168, 76, 0.045) 1px,
                transparent 1px,
                transparent 24px
              )`,
            }}
            initial={{ y: "100%", opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: "100%", opacity: 0 }}
            transition={{
              duration: 0.35,
              ease: [0.16, 1, 0.3, 1],
            }}
          >
            <nav
              className="flex flex-col justify-center items-start gap-2 px-8 py-12"
              style={{ minHeight: "calc(100vh - 64px)" }}
              aria-label="Mobile navigation"
            >
              {navLinks.map((link, index) => (
                <motion.div
                  key={link.path}
                  initial={{ opacity: 0, y: 24 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 8 }}
                  transition={{
                    duration: 0.4,
                    delay: 0.15 + index * 0.08,
                    ease: [0.16, 1, 0.3, 1],
                  }}
                  className="w-full"
                >
                  <Link
                    to={link.path}
                    onClick={() => setMobileMenuOpen(false)}
                    className="group flex items-baseline gap-4 py-4 border-b w-full transition-colors duration-200"
                    style={{
                      borderColor: "rgba(201, 168, 76, 0.15)",
                      fontFamily: "var(--font-heading)",
                    }}
                  >
                    <span
                      className="text-xs uppercase"
                      style={{
                        fontFamily: "var(--font-mono)",
                        letterSpacing: "0.15em",
                        color: "#C9A84C",
                        minWidth: "28px",
                      }}
                    >
                      0{index + 1}
                    </span>
                    <span
                      className={`text-4xl transition-colors duration-200 ${
                        location.pathname === link.path
                          ? "text-[#C9A84C]"
                          : "text-white group-hover:text-[#C9A84C] group-active:text-[#C9A84C]"
                      }`}
                      style={{
                        fontWeight: location.pathname === link.path ? 700 : 500,
                        letterSpacing: "-0.01em",
                      }}
                    >
                      {link.label}
                    </span>
                    {location.pathname === link.path && (
                      <span
                        className="ml-auto w-2 h-2 rounded-full"
                        style={{ backgroundColor: "#C9A84C" }}
                      />
                    )}
                  </Link>
                </motion.div>
              ))}

              {/* Footer-style tagline at the bottom of the overlay */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{
                  duration: 0.4,
                  delay: 0.15 + navLinks.length * 0.08,
                }}
                className="mt-8 uppercase"
                style={{
                  fontFamily: "var(--font-mono)",
                  fontSize: "11px",
                  letterSpacing: "0.2em",
                  color: "rgba(255,255,255,0.4)",
                }}
              >
                J. B. Khokhani & Co. · Est. 1965
              </motion.div>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
