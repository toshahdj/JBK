import { Link } from "react-router";
import logoImage from "../../imports/2_without_background.png";

/**
 * Footer — 3-column layout: Company · Products · Contact.
 *
 * Layout rules (per spec F):
 *   - Three equal columns on desktop (≥1024px) so the row fills the space
 *     cleanly with no gap where the retired Trust column used to sit.
 *   - Tablet (≥640px) drops to 2 columns: Company + Products on row 1,
 *     Contact spanning both columns on row 2 — contact has more content
 *     so letting it span reads more balanced than 2+2+1.
 *   - Mobile: stacked 1-column.
 *
 * WhatsApp treatment (per spec G):
 *   - No literal "WhatsApp:" text label anywhere. The WhatsApp entry is
 *     rendered as icon + number, with link semantics communicated by the
 *     green chat-bubble icon alone.
 *
 * Products links use /products#{category} hash fragments — Products.tsx
 * will read window.location.hash on mount and preselect the matching
 * tab (wired in Chunk C5).
 */

const EmailIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
    <polyline points="22,6 12,13 2,6" />
  </svg>
);

const PhoneIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
  </svg>
);

const WhatsAppIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413z"/>
  </svg>
);

const MapPinIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" />
    <circle cx="12" cy="10" r="3" />
  </svg>
);

interface FooterLinkProps {
  to: string;
  children: React.ReactNode;
}

function FooterNavLink({ to, children }: FooterLinkProps) {
  return (
    <Link
      to={to}
      className="block py-1.5 text-[15px] text-white/75 hover:text-[#C9A84C] transition-colors duration-200"
    >
      {children}
    </Link>
  );
}

const colHeadingStyle: React.CSSProperties = {
  fontFamily: "var(--font-mono)",
  fontSize: "12px",
  letterSpacing: "0.18em",
  textTransform: "uppercase",
  color: "#C9A84C",
  marginBottom: "1rem",
};

export default function Footer() {
  return (
    <footer
      className="mt-auto"
      style={{ backgroundColor: "var(--color-footer-bg)" }}
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-8 pt-14 pb-8">
        {/* Logo — single row above the columns */}
        <div className="flex justify-center lg:justify-start mb-10">
          <Link to="/" aria-label="J. B. Khokhani & Co. — home">
            <img
              src={logoImage}
              alt="J. B. Khokhani & Co. — Est. 1965, Mumbai"
              className="h-20 w-auto"
            />
          </Link>
        </div>

        {/* Three columns */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-10 lg:gap-12 mb-10">
          {/* Column 1 — Company */}
          <div>
            <div style={colHeadingStyle}>Company</div>
            <nav aria-label="Company links">
              <FooterNavLink to="/about">About us</FooterNavLink>
              <FooterNavLink to="/quality">Quality</FooterNavLink>
              <FooterNavLink to="/services">Services</FooterNavLink>
              <FooterNavLink to="/presence">Global presence</FooterNavLink>
            </nav>
          </div>

          {/* Column 2 — Products */}
          <div>
            <div style={colHeadingStyle}>Products</div>
            <nav aria-label="Product categories">
              <FooterNavLink to="/products">All products</FooterNavLink>
              <FooterNavLink to="/products#apis">APIs</FooterNavLink>
              <FooterNavLink to="/products#nutraceuticals">Nutraceuticals</FooterNavLink>
              <FooterNavLink to="/products#veterinary">Veterinary</FooterNavLink>
            </nav>
          </div>

          {/* Column 3 — Contact */}
          <div className="sm:col-span-2 lg:col-span-1">
            <div style={colHeadingStyle}>Contact</div>
            <ul className="space-y-3 text-[15px] text-white/75">
              <li className="flex items-start gap-2.5">
                <span className="text-[#C9A84C] mt-0.5 flex-shrink-0">
                  <EmailIcon />
                </span>
                <a
                  href="mailto:info@jbkhokhani.com"
                  className="hover:text-[#C9A84C] transition-colors duration-200 break-all"
                >
                  info@jbkhokhani.com
                </a>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="text-[#C9A84C] mt-0.5 flex-shrink-0">
                  <PhoneIcon />
                </span>
                <a
                  href="tel:+912240441234"
                  className="hover:text-[#C9A84C] transition-colors duration-200"
                >
                  +91 22 4044 1234
                </a>
              </li>
              <li className="flex items-start gap-2.5 pt-1">
                <span className="text-[#C9A84C] mt-0.5 flex-shrink-0">
                  <MapPinIcon />
                </span>
                <span>Mumbai, India</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Thin gold-tinted divider, then tagline + copyright + disclaimer */}
        <div className="pt-8 border-t border-white/10 text-center space-y-3">
          <p
            className="text-white/80 text-[15px]"
            style={{ fontFamily: "var(--font-body)" }}
          >
            J. B. Khokhani &amp; Co. &nbsp;·&nbsp; Est. 1965 &nbsp;·&nbsp; Mumbai, India
          </p>
          <p className="text-white/55 text-[13px]">
            © {new Date().getFullYear()} J. B. Khokhani &amp; Co. All rights reserved.
          </p>
          <p
            className="text-white/50 text-[12px] max-w-3xl mx-auto leading-relaxed pt-2"
            style={{ textWrap: "pretty" }}
          >
            Disclaimer: API/Substances covered by patent are not offered to
            countries where patent law is in force. Final responsibility lies
            with the customer.
          </p>
        </div>
      </div>
    </footer>
  );
}
