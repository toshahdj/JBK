import deftLogo from "../../imports/nutra/deft.png";
import eurochemLogo from "../../imports/nutra/eurochem.png";
import novonesisLogo from "../../imports/nutra/novonesis.png";

/**
 * Nutraceuticals flagship block — rendered on the Products page when the
 * Nutraceuticals tab is active. Three flagship actives (PineD3, MenaquinGold,
 * Caffeine Anhydrous) with partner-sourced provenance.
 *
 * C5 · round 4 (approved).
 */
export default function NutraceuticalsFeature() {
  return (
    <section
      className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 relative"
      style={{ backgroundColor: "var(--color-section-bg)" }}
    >
      <div className="max-w-6xl mx-auto relative z-10">
        {/* Section header */}
        <div className="text-center mb-12 md:mb-16">
          <div
            className="inline-flex items-center gap-3 mb-4"
            style={{
              fontFamily: "var(--font-mono)",
              fontSize: "13.5px",
              letterSpacing: "0.2em",
              textTransform: "uppercase",
              color: "#C9A84C",
            }}
          >
            <span style={{ width: "24px", height: "1px", background: "#C9A84C" }} />
            Premium Nutraceutical Ingredients
            <span style={{ width: "24px", height: "1px", background: "#C9A84C" }} />
          </div>
          <h2
            className="mb-4"
            style={{
              fontFamily: "var(--font-heading)",
              fontWeight: 700,
              fontSize: "clamp(28px, 3.2vw, 40px)",
              letterSpacing: "-0.012em",
              color: "var(--color-foreground)",
            }}
          >
            Flagship actives we represent in India
          </h2>
          <p
            className="mx-auto"
            style={{
              fontSize: "15.5px",
              lineHeight: 1.65,
              maxWidth: "620px",
              color: "var(--color-muted-foreground)",
            }}
          >
            Sourced in partnership with globally recognised manufacturers. From
            pine-sourced Vitamin D3 to fermented MK-7 and sports-grade caffeine —
            three actives at the heart of our nutraceutical catalogue.
          </p>
        </div>

        {/* Three flagship cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* PineD3 */}
          <NutraCard
            eyebrow="Vegan Vitamin D3"
            tagline="All-natural plant-sourced cholecalciferol."
            claims={[
              "First vegan Vitamin D3 (pine sourced) introduced to the Indian market",
              "100% plant-based · sourced from pine-tree phytosterol",
              "Vegan Society certified · Non-GMO · allergen-free",
              "Oil 1,000,000 IU/g · Powder 100,000 IU/g",
            ]}
            partnerLogo={eurochemLogo}
            partnerLogoAlt="Eurochem"
            partnerLogoHeight={36}
            partnerName="Eurochem Germany (ECA)"
            nameDisplay={<PineD3Wordmark />}
          />

          {/* MenaquinGold */}
          <NutraCard
            eyebrow="Natural Vitamin K2-7"
            tagline="Advantage heart. Advantage bone."
            claims={[
              "Binds calcium to the bone matrix",
              "Prevents arterial calcification via MGP activation",
              "Clinically proven osteocalcin carboxylation (Summeren et al., 2009)",
              "Natural menaquinone-7 (MK-7) via fermentation",
            ]}
            partnerLogo={novonesisLogo}
            partnerLogoAlt="Novonesis"
            partnerLogoHeight={26}
            partnerName="Novonesis (Denmark)"
            nameDisplay={<MenaquinGoldWordmark />}
          />

          {/* Caffeine Anhydrous */}
          <NutraCard
            eyebrow="Performance Ingredient"
            tagline="A purine-derivative alkaloid for sports nutrition."
            claims={[
              "Mental alertness · focus · faster reaction time",
              "Endurance performance · fat utilisation",
              "Thermogenesis · metabolic support",
              "Formulates into energy drinks, gels, capsules, gums, functional foods",
              "GMP · FDA · FSSC 22000 · Kosher · Halal",
            ]}
            partnerLogo={deftLogo}
            partnerLogoAlt="Deft Chemicals"
            partnerLogoHeight={36}
            partnerName="Deft Chemicals"
            nameDisplay={<span>Caffeine Anhydrous</span>}
          />
        </div>
      </div>
    </section>
  );
}

interface NutraCardProps {
  eyebrow: string;
  nameDisplay: React.ReactNode;
  tagline: string;
  claims: string[];
  partnerLogo: string;
  partnerLogoAlt: string;
  partnerLogoHeight: number;
  partnerName: string;
}

function NutraCard({
  eyebrow,
  nameDisplay,
  tagline,
  claims,
  partnerLogo,
  partnerLogoAlt,
  partnerLogoHeight,
  partnerName,
}: NutraCardProps) {
  return (
    <article
      className="rounded-2xl p-8 md:p-9 flex flex-col gap-4 transition-all duration-200"
      style={{
        backgroundColor: "var(--color-card)",
        border: "1px solid var(--color-border)",
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.borderColor = "rgba(201, 168, 76, 0.3)";
        e.currentTarget.style.transform = "translateY(-3px)";
        e.currentTarget.style.boxShadow = "0 18px 32px rgba(10, 22, 40, 0.09)";
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.borderColor = "var(--color-border)";
        e.currentTarget.style.transform = "translateY(0)";
        e.currentTarget.style.boxShadow = "none";
      }}
    >
      <div
        style={{
          fontFamily: "var(--font-mono)",
          fontSize: "13px",
          letterSpacing: "0.2em",
          textTransform: "uppercase",
          fontWeight: 500,
          color: "#C9A84C",
        }}
      >
        {eyebrow}
      </div>

      <h3
        className="m-0"
        style={{
          fontFamily: "var(--font-heading)",
          fontWeight: 700,
          fontSize: "28px",
          lineHeight: 1.08,
          letterSpacing: "-0.012em",
          color: "var(--color-foreground)",
        }}
      >
        {nameDisplay}
      </h3>

      <p
        className="m-0"
        style={{
          fontFamily: "var(--font-heading)",
          fontStyle: "italic",
          fontWeight: 400,
          fontSize: "15px",
          lineHeight: 1.45,
          color: "var(--color-muted-foreground)",
        }}
      >
        {tagline}
      </p>

      <div
        style={{
          height: "1px",
          background: "var(--color-border)",
          margin: "2px 0",
        }}
      />

      <ul className="flex flex-col gap-2 m-0 p-0 list-none">
        {claims.map((claim, i) => (
          <li
            key={i}
            className="relative"
            style={{
              fontSize: "14px",
              lineHeight: 1.55,
              color: "var(--color-foreground)",
              paddingLeft: "16px",
            }}
          >
            <span
              className="absolute left-0"
              style={{
                top: "7px",
                width: "6px",
                height: "6px",
                borderRadius: "50%",
                background: "#C9A84C",
              }}
            />
            {claim}
          </li>
        ))}
      </ul>

      {/* Partner footer */}
      <div
        className="mt-auto pt-5"
        style={{ borderTop: "1px dashed var(--color-border)" }}
      >
        <div
          style={{
            fontFamily: "var(--font-mono)",
            fontSize: "10px",
            letterSpacing: "0.14em",
            textTransform: "uppercase",
            color: "var(--color-muted-foreground)",
            fontWeight: 500,
            marginBottom: "6px",
          }}
        >
          Sourced in partnership with
        </div>
        <div style={{ lineHeight: 0, marginBottom: "8px" }}>
          <span
            style={{
              display: "inline-block",
              backgroundColor: "#FFFFFF",
              padding: "8px 12px",
              borderRadius: "4px",
              lineHeight: 0,
            }}
          >
            <img
              src={partnerLogo}
              alt={partnerLogoAlt}
              style={{
                height: `${partnerLogoHeight}px`,
                width: "auto",
                maxWidth: "100%",
                display: "block",
              }}
            />
          </span>
        </div>
        <div
          style={{
            fontFamily: "var(--font-body)",
            fontWeight: 500,
            fontSize: "13px",
            color: "var(--color-foreground)",
          }}
        >
          {partnerName}
        </div>
      </div>
    </article>
  );
}

/** PineD3 wordmark — sun icon + italic text + trademark. */
function PineD3Wordmark() {
  return (
    <span
      className="inline-flex items-center gap-2"
      style={{ color: "#F3A83A", fontStyle: "italic" }}
    >
      <svg
        viewBox="0 0 32 32"
        aria-hidden="true"
        style={{ width: "30px", height: "30px", flexShrink: 0 }}
      >
        <g fill="#F3A83A">
          <circle cx="14" cy="17" r="4.5" />
        </g>
        <g stroke="#F3A83A" strokeWidth="1.8" strokeLinecap="round" fill="none">
          <line x1="14" y1="6" x2="14" y2="9.5" />
          <line x1="14" y1="24.5" x2="14" y2="28" />
          <line x1="3" y1="17" x2="6.5" y2="17" />
          <line x1="21.5" y1="17" x2="25" y2="17" />
          <line x1="5.5" y1="8.5" x2="8" y2="11" />
          <line x1="20" y1="23" x2="22.5" y2="25.5" />
          <line x1="5.5" y1="25.5" x2="8" y2="23" />
          <line x1="20" y1="11" x2="22.5" y2="8.5" />
        </g>
        <g stroke="#F3A83A" strokeWidth="1.6" strokeLinecap="round">
          <line x1="25" y1="6" x2="30" y2="6" />
          <line x1="27.5" y1="3.5" x2="27.5" y2="8.5" />
        </g>
      </svg>
      <span>PineD3</span>
      <sup
        style={{
          color: "#F3A83A",
          fontSize: "0.38em",
          verticalAlign: "super",
          marginLeft: "1px",
          fontStyle: "normal",
        }}
      >
        ™
      </sup>
    </span>
  );
}

/** MenaquinGold wordmark — red "Menaquin" underlined + gold "Gold" + trademark. */
function MenaquinGoldWordmark() {
  return (
    <span style={{ fontStyle: "italic", letterSpacing: "-0.01em" }}>
      <span
        style={{
          color: "#DC2020",
          textDecoration: "underline",
          textDecorationColor: "#DC2020",
          textDecorationThickness: "2px",
          textUnderlineOffset: "3px",
        }}
      >
        Menaquin
      </span>
      <span style={{ color: "#C9A84C" }}>Gold</span>
      <sup
        style={{
          color: "#DC2020",
          fontSize: "0.38em",
          verticalAlign: "super",
          marginLeft: "2px",
          fontStyle: "normal",
        }}
      >
        ®
      </sup>
    </span>
  );
}
