import { useState, useEffect, useRef } from "react";

interface SectionHeadingProps {
  label: string;
  heading: string;
  centered?: boolean;
}

export default function SectionHeading({
  label,
  heading,
  centered = false,
}: SectionHeadingProps) {
  const [labelVisible, setLabelVisible] = useState(false);
  const [headingVisible, setHeadingVisible] = useState(false);
  const [lineVisible, setLineVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setLabelVisible(true);
          setTimeout(() => setHeadingVisible(true), 100);
          setTimeout(() => setLineVisible(true), 200);
        }
      },
      { threshold: 0.15 }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <div ref={ref} className={`mb-12 ${centered ? "text-center" : ""}`}>
      <div
        className="text-xs uppercase mb-4"
        style={{
          fontFamily: "var(--font-mono)",
          letterSpacing: "0.15em",
          color: "#C9A84C",
          opacity: labelVisible ? 1 : 0,
          transition: "opacity 0.4s cubic-bezier(0.16, 1, 0.3, 1)",
        }}
      >
        {label}
      </div>
      <h1
        className="text-4xl md:text-[44px] mb-4"
        style={{
          fontFamily: "var(--font-heading)",
          fontWeight: 700,
          color: "var(--color-foreground)",
          opacity: headingVisible ? 1 : 0,
          transform: headingVisible ? "translateY(0)" : "translateY(20px)",
          transition:
            "opacity 0.5s cubic-bezier(0.16, 1, 0.3, 1), transform 0.5s cubic-bezier(0.16, 1, 0.3, 1)",
        }}
      >
        {heading}
      </h1>
      <div
        className={centered ? "mx-auto" : ""}
        style={{
          backgroundColor: "#C9A84C",
          height: "2px",
          width: lineVisible ? "60px" : "0px",
          transition: "width 0.5s cubic-bezier(0.16, 1, 0.3, 1)",
        }}
      />
    </div>
  );
}
