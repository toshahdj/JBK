import { useState, useEffect } from "react";
import { ArrowUp } from "lucide-react";

interface FloatingButtonsProps {
  darkMode: boolean;
}

export default function FloatingButtons({ darkMode }: FloatingButtonsProps) {
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [isWhatsAppHovered, setIsWhatsAppHovered] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 300);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <>
      <style>{`
        @keyframes pulse-ring {
          0% {
            transform: scale(1);
            opacity: 0.4;
          }
          100% {
            transform: scale(1.5);
            opacity: 0;
          }
        }
      `}</style>

      {/* Scroll to Top Button - Bottom Left */}
      {showScrollTop && (
        <button
          onClick={scrollToTop}
          className="fixed bottom-6 left-6 z-40 p-4 rounded-full shadow-lg transition-all duration-300 hover:scale-110"
          style={{
            backgroundColor: darkMode ? "#C9A84C" : "#6B8F71",
            color: "#FFFFFF",
          }}
          aria-label="Scroll to top"
        >
          <ArrowUp className="w-6 h-6" />
        </button>
      )}

      {/* WhatsApp Button - Bottom Right */}
      <a
        href="https://wa.me/919821433393"
        target="_blank"
        rel="noopener noreferrer"
        className="group"
        style={{
          position: "fixed",
          bottom: "24px",
          right: "24px",
          zIndex: 9999,
        }}
        onMouseEnter={() => setIsWhatsAppHovered(true)}
        onMouseLeave={() => setIsWhatsAppHovered(false)}
      >
        {/* Pulse Ring — mode-aware tint */}
        <div
          style={{
            position: "absolute",
            top: "0",
            left: "0",
            width: "56px",
            height: "56px",
            borderRadius: "50%",
            // light: sage-tinted ring to agree with the #F4F1EC background
            // dark:  warmer gold-inflected ring for a premium halo on #060F1E
            backgroundColor: darkMode
              ? "rgba(201, 168, 76, 0.55)"
              : "rgba(107, 143, 113, 0.45)",
            animation: "pulse-ring 2s ease-out infinite",
            pointerEvents: "none",
          }}
        />

        {/* Main Button */}
        <div
          style={{
            position: "relative",
            width: "56px",
            height: "56px",
            borderRadius: "50%",
            backgroundColor: isWhatsAppHovered ? "var(--wa-green-hover)" : "var(--wa-green)",
            /* Layered shadow:
               – inner: the brand-green glow (always present, full-strength on hover)
               – outer: mode-aware accent — sage in light, gold in dark — at low opacity
                 so the bubble visually belongs to whichever mode is active. */
            boxShadow: darkMode
              ? isWhatsAppHovered
                ? "0 6px 24px rgba(37, 211, 102, 0.45), 0 0 32px rgba(201, 168, 76, 0.35)"
                : "0 4px 20px rgba(37, 211, 102, 0.35), 0 0 24px rgba(201, 168, 76, 0.25)"
              : isWhatsAppHovered
              ? "0 6px 24px rgba(37, 211, 102, 0.4), 0 0 28px rgba(107, 143, 113, 0.35)"
              : "0 4px 16px rgba(37, 211, 102, 0.3), 0 0 20px rgba(107, 143, 113, 0.22)",
            transform: isWhatsAppHovered ? "scale(1.08)" : "scale(1)",
            transition: "all 0.2s ease",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          {/* WhatsApp Icon */}
          <svg
            viewBox="0 0 24 24"
            fill="white"
            xmlns="http://www.w3.org/2000/svg"
            style={{
              width: "28px",
              height: "28px",
            }}
          >
            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
          </svg>
        </div>

        {/* Tooltip */}
        <div
          style={{
            position: "absolute",
            right: "70px",
            top: "50%",
            transform: isWhatsAppHovered
              ? "translateY(-50%) translateX(0)"
              : "translateY(-50%) translateX(4px)",
            opacity: isWhatsAppHovered ? 1 : 0,
            pointerEvents: "none",
            transition: "opacity 0.2s ease, transform 0.2s ease",
            whiteSpace: "nowrap",
            fontFamily: "var(--font-body)",
            fontSize: "13px",
            color: "white",
            backgroundColor: darkMode ? "#162236" : "#1A1A1A",
            padding: "8px 14px",
            borderRadius: "6px",
            boxShadow: "0 2px 8px rgba(0,0,0,0.15)",
          }}
        >
          Chat with us!
          {/* Arrow */}
          <div
            style={{
              position: "absolute",
              right: "-6px",
              top: "50%",
              transform: "translateY(-50%)",
              width: 0,
              height: 0,
              borderTop: "6px solid transparent",
              borderBottom: "6px solid transparent",
              borderLeft: darkMode ? "6px solid #162236" : "6px solid #1A1A1A",
            }}
          />
        </div>
      </a>
    </>
  );
}
