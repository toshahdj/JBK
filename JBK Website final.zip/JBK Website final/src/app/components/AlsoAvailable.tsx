/**
 * "Also available" block — shown on Products page under Nutraceuticals tab,
 * below the flagship block. Lists non-flagship Nutra products. Currently
 * just Xylitol.
 *
 * R2.3 (revises C6): italic note sits above the eyebrow; tile is a solid
 * bordered card (gold-tinted) instead of dashed for stronger visibility.
 */

interface AlsoAvailableProps {
  products: { name: string }[];
}

export default function AlsoAvailable({ products }: AlsoAvailableProps) {
  if (products.length === 0) return null;

  return (
    <section
      className="pt-0 pb-16 px-4 sm:px-6 lg:px-8"
      style={{ backgroundColor: "var(--color-section-bg)" }}
    >
      <div className="max-w-6xl mx-auto">
        {/* Italic note — sits ABOVE the eyebrow */}
        <p
          className="text-center mt-0 mb-5"
          style={{
            fontSize: "13px",
            color: "var(--color-muted-foreground)",
            fontStyle: "italic",
          }}
        >
          Additional ingredients we source. Use the{" "}
          <em style={{ fontStyle: "italic" }}>Request a Sample</em> form above — pick "Other"
          to request any of these.
        </p>

        {/* Eyebrow + hairline */}
        <div className="flex items-center gap-4 mb-5">
          <span
            className="whitespace-nowrap"
            style={{
              fontFamily: "var(--font-mono)",
              fontSize: "12px",
              letterSpacing: "0.2em",
              textTransform: "uppercase",
              color: "#C9A84C",
              fontWeight: 500,
            }}
          >
            Also available
          </span>
          <span
            className="flex-1"
            aria-hidden="true"
            style={{ height: "1px", background: "rgba(201, 168, 76, 0.3)" }}
          />
        </div>

        {/* Grid of also-available products */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5">
          {products.map((p) => (
            <div
              key={p.name}
              className="rounded-lg p-3 flex items-center justify-center text-center transition-all duration-150"
              style={{
                minHeight: "76px",
                backgroundColor: "var(--color-card)",
                border: "1px solid rgba(201, 168, 76, 0.35)",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.borderColor = "rgba(201, 168, 76, 0.55)";
                e.currentTarget.style.backgroundColor = "var(--color-card)";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.borderColor = "rgba(201, 168, 76, 0.35)";
                e.currentTarget.style.backgroundColor = "var(--color-card)";
              }}
            >
              <p
                className="m-0"
                style={{
                  fontFamily: "var(--font-heading)",
                  fontWeight: 600,
                  fontSize: "14px",
                  lineHeight: 1.2,
                  color: "var(--color-foreground)",
                  wordBreak: "break-word",
                  hyphens: "auto",
                }}
              >
                {p.name}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
