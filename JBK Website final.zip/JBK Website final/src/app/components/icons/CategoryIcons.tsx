import type { FC } from "react";

/**
 * Category icons — Variant B (filled flat two-tone).
 *
 * Design system:
 *   - viewBox 0 0 48 48 across every icon for consistent visual weight.
 *   - Primary fill: `var(--color-foreground)` — auto-swaps #0A1628 (light) ↔ #F0F4FF (dark).
 *   - Accent: hard-coded `#C9A84C` (gold reads on both backgrounds, no swap needed).
 *   - Dividers between touching fills: 1.2 px in `var(--color-card)` — blends
 *     into the card background on both themes so the gap reads as "no fill,"
 *     not as a visible white line.
 *   - Detail strokes (rungs, ECG trace, trend arrows, brain cleft, leaf veins):
 *     1.5–2 px in primary colour. Stroke-based rendering is a pragmatic
 *     concession for shapes that are naturally linear (DNA strands, leaf veins,
 *     brain grooves) — matches Material / Phosphor filled-variant conventions.
 *   - All icons are decorative (category name carries semantic meaning), so
 *     each SVG is `aria-hidden="true"` and non-focusable.
 *
 * Caller controls rendering size via `className` (e.g. "w-12 h-12" = 48 px).
 */

type IconProps = { className?: string };

const svgBase = (className?: string) => ({
  viewBox: "0 0 48 48",
  className,
  xmlns: "http://www.w3.org/2000/svg",
  "aria-hidden": true as const,
  focusable: "false" as const,
});

/* ─── 1. Antibiotics — capsule, -30° rotation, 1.2 px divider ─────── */
export const AntibioticIcon: FC<IconProps> = ({ className }) => (
  <svg {...svgBase(className)}>
    <g transform="rotate(-30 24 24)">
      <path d="M24 17 L15 17 A7 7 0 0 0 15 31 L24 31 Z" fill="var(--color-foreground)" />
      <path d="M24 17 L33 17 A7 7 0 0 1 33 31 L24 31 Z" fill="#C9A84C" />
      <line x1="24" y1="18" x2="24" y2="30" stroke="var(--color-card)" strokeWidth="1.2" strokeLinecap="round" />
    </g>
  </svg>
);

/* ─── 2. Anti-Infectives — shield with plus ───────────────────────── */
export const AntiInfectiveIcon: FC<IconProps> = ({ className }) => (
  <svg {...svgBase(className)}>
    <path
      d="M 24 6 L 10 11 L 10 24 C 10 34 16 38 24 42 C 32 38 38 34 38 24 L 38 11 Z"
      fill="var(--color-foreground)"
    />
    <path
      d="M 21 15 L 27 15 L 27 21 L 33 21 L 33 27 L 27 27 L 27 33 L 21 33 L 21 27 L 15 27 L 15 21 L 21 21 Z"
      fill="#C9A84C"
    />
  </svg>
);

/* ─── 3. Cardiovascular & Metabolic — heart with ECG trace ────────── */
export const CardiovascularIcon: FC<IconProps> = ({ className }) => (
  <svg {...svgBase(className)}>
    <path
      d="M 24 14 C 22 10, 16 8, 12 14 C 8 20, 12 28, 24 38 C 36 28, 40 20, 36 14 C 32 8, 26 10, 24 14 Z"
      fill="var(--color-foreground)"
    />
    <polyline
      points="10,24 17,24 20,20 22,28 26,14 29,24 38,24"
      fill="none"
      stroke="#C9A84C"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

/* ─── 4. Antidiabetics — blood droplet with downward trend ────────── */
export const AntidiabeticIcon: FC<IconProps> = ({ className }) => (
  <svg {...svgBase(className)}>
    <path
      d="M 24 8 C 18 14, 10 24, 10 30 C 10 38, 16 42, 24 42 C 32 42, 38 38, 38 30 C 38 24, 30 14, 24 8 Z"
      fill="var(--color-foreground)"
    />
    <g stroke="#C9A84C" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" fill="none">
      <line x1="32" y1="22" x2="20" y2="34" />
      <polyline points="20,28 20,34 26,34" />
    </g>
  </svg>
);

/* ─── 5. Oncology — cancer cell, 6-spike polygon with gold nuclei ─── */
export const OncologyIcon: FC<IconProps> = ({ className }) => (
  <svg {...svgBase(className)}>
    <path
      d="M 24 5 L 29 15 L 40 13 L 35 24 L 40 34 L 29 32 L 24 43 L 19 32 L 8 34 L 13 24 L 8 13 L 19 15 Z"
      fill="var(--color-foreground)"
    />
    <circle cx="20" cy="22" r="2" fill="#C9A84C" />
    <circle cx="28" cy="23" r="2" fill="#C9A84C" />
    <circle cx="24" cy="29" r="2" fill="#C9A84C" />
  </svg>
);

/* ─── 6. Respiratory — trachea + Y-bronchi + lungs w/ bronchial tree ── */
export const RespiratoryIcon: FC<IconProps> = ({ className }) => (
  <svg {...svgBase(className)}>
    <line x1="22" y1="6" x2="22" y2="17" stroke="var(--color-foreground)" strokeWidth="2" strokeLinecap="round" />
    <line x1="26" y1="6" x2="26" y2="17" stroke="var(--color-foreground)" strokeWidth="2" strokeLinecap="round" />
    <line x1="22" y1="17" x2="17" y2="22" stroke="var(--color-foreground)" strokeWidth="2" strokeLinecap="round" />
    <line x1="26" y1="17" x2="31" y2="22" stroke="var(--color-foreground)" strokeWidth="2" strokeLinecap="round" />
    <path
      d="M 17 22 C 11 24, 8 30, 10 38 C 11 42, 16 42, 20 40 C 21 38, 21 35, 21 32 L 21 22 Z"
      fill="var(--color-foreground)"
    />
    <path
      d="M 31 22 C 37 24, 40 30, 38 38 C 37 42, 32 42, 28 40 C 27 38, 27 35, 27 32 L 27 22 Z"
      fill="#C9A84C"
    />
    <g stroke="var(--color-card)" strokeWidth="1.2" fill="none" strokeLinecap="round">
      <path d="M 17 26 L 14 33" />
      <path d="M 14 33 L 12 37" />
      <path d="M 14 33 L 16 38" />
      <path d="M 17 26 L 18 32" />
    </g>
    <g stroke="var(--color-card)" strokeWidth="1.2" fill="none" strokeLinecap="round">
      <path d="M 31 26 L 34 33" />
      <path d="M 34 33 L 36 37" />
      <path d="M 34 33 L 32 38" />
      <path d="M 31 26 L 30 32" />
    </g>
  </svg>
);

/* ─── 7. CNS — bumpier brain with multiple gyri + internal sulci ─── */
export const CnsIcon: FC<IconProps> = ({ className }) => (
  <svg {...svgBase(className)}>
    <path
      d="M 24 14 C 22 11, 19 11, 18 13 C 15 11, 12 13, 13 16 C 10 16, 7 20, 10 23 C 7 25, 8 30, 12 30 C 11 33, 14 36, 17 35 C 18 38, 24 39, 24 36 Z"
      fill="var(--color-foreground)"
    />
    <path
      d="M 24 14 C 26 11, 29 11, 30 13 C 33 11, 36 13, 35 16 C 38 16, 41 20, 38 23 C 41 25, 40 30, 36 30 C 37 33, 34 36, 31 35 C 30 38, 24 39, 24 36 Z"
      fill="#C9A84C"
    />
    <line x1="24" y1="14" x2="24" y2="37" stroke="var(--color-card)" strokeWidth="1.2" strokeLinecap="round" />
    <path d="M 14 19 Q 18 23, 13 26" fill="none" stroke="var(--color-card)" strokeWidth="1" strokeLinecap="round" />
    <path d="M 34 19 Q 30 23, 35 26" fill="none" stroke="var(--color-card)" strokeWidth="1" strokeLinecap="round" />
    <path d="M 16 28 Q 20 31, 17 34" fill="none" stroke="var(--color-card)" strokeWidth="0.9" strokeLinecap="round" />
    <path d="M 32 28 Q 28 31, 31 34" fill="none" stroke="var(--color-card)" strokeWidth="0.9" strokeLinecap="round" />
  </svg>
);

/* ─── 8. Hormones & Steroids — DNA helix (sanity-checked) ─────────── */
export const HormonesIcon: FC<IconProps> = ({ className }) => (
  <svg {...svgBase(className)}>
    <path
      d="M 14 8 C 14 16, 34 16, 34 24 C 34 32, 14 32, 14 40"
      fill="none"
      stroke="var(--color-foreground)"
      strokeWidth="3"
      strokeLinecap="round"
    />
    <path
      d="M 34 8 C 34 16, 14 16, 14 24 C 14 32, 34 32, 34 40"
      fill="none"
      stroke="#C9A84C"
      strokeWidth="3"
      strokeLinecap="round"
    />
    <line x1="14" y1="8" x2="34" y2="8" stroke="var(--color-foreground)" strokeWidth="1.5" strokeLinecap="round" />
    <line x1="14" y1="24" x2="34" y2="24" stroke="var(--color-foreground)" strokeWidth="1.5" strokeLinecap="round" />
    <line x1="14" y1="40" x2="34" y2="40" stroke="var(--color-foreground)" strokeWidth="1.5" strokeLinecap="round" />
  </svg>
);

/* ─── 9. Antifungals — fungal cell inside gold prohibit ring ──────── */
export const AntifungalIcon: FC<IconProps> = ({ className }) => (
  <svg {...svgBase(className)}>
    <circle cx="24" cy="24" r="9" fill="var(--color-foreground)" />
    <g fill="var(--color-foreground)">
      <path d="M 24 13 L 23 16 L 25 16 Z" />
      <path d="M 35 24 L 32 23 L 32 25 Z" />
      <path d="M 24 35 L 23 32 L 25 32 Z" />
      <path d="M 13 24 L 16 23 L 16 25 Z" />
    </g>
    <circle cx="21" cy="22" r="1.3" fill="var(--color-card)" />
    <circle cx="26" cy="24" r="1.3" fill="var(--color-card)" />
    <circle cx="22" cy="27" r="1.3" fill="var(--color-card)" />
    <circle cx="24" cy="24" r="15" fill="none" stroke="#C9A84C" strokeWidth="2.5" />
    <line x1="13.5" y1="13.5" x2="34.5" y2="34.5" stroke="#C9A84C" strokeWidth="2.5" strokeLinecap="round" />
  </svg>
);

/* ─── 10. Sexual Wellness — interlocking ♀ + ♂ symbols ────────────── */
export const SexualWellnessIcon: FC<IconProps> = ({ className }) => (
  <svg {...svgBase(className)}>
    <circle cx="20" cy="28" r="7.5" fill="none" stroke="var(--color-foreground)" strokeWidth="3" />
    <line x1="20" y1="35.5" x2="20" y2="43" stroke="var(--color-foreground)" strokeWidth="3" strokeLinecap="round" />
    <line x1="16" y1="40" x2="24" y2="40" stroke="var(--color-foreground)" strokeWidth="3" strokeLinecap="round" />
    <circle cx="28" cy="20" r="7.5" fill="none" stroke="#C9A84C" strokeWidth="3" />
    <line x1="33.5" y1="14.5" x2="40" y2="8" stroke="#C9A84C" strokeWidth="3" strokeLinecap="round" />
    <polyline points="36,8 40,8 40,12" fill="none" stroke="#C9A84C" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

/* ─── 11. Vitamins & Nutraceuticals — sun rays + 1.5× central pill ─── */
export const VitaminsIcon: FC<IconProps> = ({ className }) => (
  <svg {...svgBase(className)}>
    <g stroke="#C9A84C" strokeWidth="2" strokeLinecap="round">
      <line x1="24" y1="3" x2="24" y2="14" />
      <line x1="24" y1="34" x2="24" y2="45" />
      <line x1="3" y1="24" x2="9" y2="24" />
      <line x1="39" y1="24" x2="45" y2="24" />
      <line x1="6" y1="6" x2="11" y2="11" />
      <line x1="37" y1="37" x2="42" y2="42" />
      <line x1="6" y1="42" x2="11" y2="37" />
      <line x1="37" y1="11" x2="42" y2="6" />
    </g>
    <rect x="12" y="18" width="24" height="12" rx="6" fill="var(--color-foreground)" />
    <line x1="12" y1="24" x2="36" y2="24" stroke="var(--color-card)" strokeWidth="1.2" strokeLinecap="round" />
  </svg>
);

/* ─── 12. Plant Extracts — mortar & pestle with teardrop leaves ───── */
export const PlantExtractsIcon: FC<IconProps> = ({ className }) => (
  <svg {...svgBase(className)}>
    <line x1="22" y1="34" x2="40" y2="12" stroke="var(--color-foreground)" strokeWidth="5" strokeLinecap="round" />
    <circle cx="40" cy="12" r="3.5" fill="var(--color-foreground)" />
    <path d="M 8 28 C 8 40, 14 43, 24 43 C 34 43, 40 40, 40 28 Z" fill="#C9A84C" />
    <ellipse cx="24" cy="28" rx="15" ry="1.8" fill="var(--color-card)" />
    <rect x="14" y="43" width="20" height="2" fill="#C9A84C" />
    <path d="M 17 27 C 11 22, 10 12, 15 7 C 21 11, 21 21, 18 27 Z" fill="var(--color-foreground)" />
    <path d="M 24 27 C 19 22, 19 10, 24 5 C 29 10, 29 22, 24 27 Z" fill="var(--color-foreground)" />
  </svg>
);

/* ─── 13. Browse all — arrow-right in rounded square (CTA card) ───── */
export const BrowseAllIcon: FC<IconProps> = ({ className }) => (
  <svg {...svgBase(className)}>
    <rect x="8" y="8" width="32" height="32" rx="8" fill="var(--color-foreground)" />
    <g stroke="#C9A84C" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" fill="none">
      <line x1="16" y1="24" x2="32" y2="24" />
      <polyline points="24,16 32,24 24,32" />
    </g>
  </svg>
);
