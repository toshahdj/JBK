/**
 * HeroCarousel — homepage scroll-driven hero/carousel morph.
 *
 * UX spec (from change-log Item 2):
 *   1. On load:  full-screen hero (headline + subtitle + CTAs) — `children`.
 *   2. On scroll down: hero text dissolves; carousel fades in full-screen.
 *   3. On further scroll: carousel scales down and docks to the top 1/3 of
 *      the viewport while page content scrolls beneath it.
 *   4. On scroll back up: the sequence reverses.
 *
 * Architecture — option (a), two-component split:
 *   - A sticky scroll region (height 220vh) contains a sticky inner container
 *     (height = viewport minus nav). Inside, two absolutely-positioned layers
 *     (original hero + morphing carousel) are driven by `useScroll` progress.
 *   - Once the user scrolls *past* the sticky region, a separate
 *     position:fixed DockedCarousel mounts at the top of the viewport and
 *     persists as subsequent sections scroll underneath.
 *   - Both carousel instances share slide state via this component's own
 *     React state — no context, no portals, no shenanigans.
 *
 * Slides are dummy copy + generic gold SVG geometry. Real slide copy and
 * imagery will be supplied by Darshan (see `AWAITING FROM DARSHAN` item C).
 *
 * prefers-reduced-motion is respected site-wide via a CSS global in
 * theme.css; this component additionally uses `useReducedMotion()` to
 * disable autoplay entirely (stills carousel at slide 0) and suppress
 * the docked mini-carousel entrance animation.
 */

import { useState, useEffect, useRef, useCallback, type ReactNode } from "react";
import { Link } from "react-router";
import {
  motion,
  useScroll,
  useTransform,
  AnimatePresence,
} from "motion/react";
import { ChevronLeft, ChevronRight, ArrowRight } from "lucide-react";
import useReducedMotion from "../hooks/useReducedMotion";

/** Nav bar height — matches md:h-20 in Navigation.tsx.
 *  On mobile (h-16 = 64px) this leaves a ~16px gap below the nav,
 *  which reads as intentional breathing space. */
const NAV_TOP_PX = 80;

/** Docked height = top third of viewport. */
const DOCKED_HEIGHT_VH = 33;

/** Autoplay interval for the full-screen carousel. */
const AUTOPLAY_MS = 4000;

// ────────────────────────────────────────────────────────────────────────────
// Generic SVG visuals — gold-on-background geometric compositions.
// All use currentColor-friendly palette (#C9A84C gold, with neutral strokes).
// Each takes a slide index so slight rotation/seed differences keep them
// visually distinct without hand-authoring 9 unique scenes.
// ────────────────────────────────────────────────────────────────────────────

// ────────────────────────────────────────────────────────────────────────────
// VisualPlaceholder — per slide's visual area, a descriptive placeholder
// block that names the slot, the subject, and the intended art style.
// This is the reference's round-5 locked visual; when Darshan's final
// flagship designs land, the component only needs to swap this block
// for per-slide visual renderers without touching any other architecture.
// ────────────────────────────────────────────────────────────────────────────

function VisualPlaceholder({
  slotLabel,
  subject,
  style,
}: {
  slotLabel: string;
  subject: string;
  style: string;
}) {
  return (
    <div
      className="w-full grid place-items-center"
      style={{ minHeight: "300px", padding: "24px" }}
    >
      <div
        className="flex flex-col text-center"
        style={{
          gap: "12px",
          maxWidth: "320px",
          fontFamily: "var(--font-mono)",
          color: "#C9A84C",
          fontSize: "clamp(11px, 0.95vw, 12.5px)",
          letterSpacing: "0.14em",
          textTransform: "uppercase",
          lineHeight: 1.5,
        }}
      >
        <span style={{ fontWeight: 500, opacity: 0.9 }}>{slotLabel}</span>
        <span
          style={{
            fontFamily: "var(--font-heading)",
            fontStyle: "italic",
            fontWeight: 400,
            fontSize: "clamp(17px, 1.4vw, 22px)",
            letterSpacing: "-0.005em",
            textTransform: "none",
            color: "var(--color-foreground)",
          }}
        >
          {subject}
        </span>
        <span
          style={{
            fontFamily: "var(--font-body)",
            fontWeight: 400,
            fontSize: "clamp(11.5px, 0.9vw, 13px)",
            letterSpacing: "0.01em",
            textTransform: "none",
            color: "var(--color-muted-foreground)",
            lineHeight: 1.55,
          }}
        >
          {style}
        </span>
      </div>
    </div>
  );
}

// ────────────────────────────────────────────────────────────────────────────
// Slide data — 7 slides per C4 round-5 locked order (D3 · K2-7 · Products ·
// Exhibitions · Presence · Trusted Supply · Services).
//
// Copy below matches the round-5 locked preview. Flagship slide design
// (slides 1 and 2) is being produced separately by Darshan and will be
// slotted in without a structural change — the component rendering is
// already agnostic to slide count (uses SLIDES.length everywhere).
//
// Do NOT mention specific manufacturer names here (per hard constraint —
// manufacturer info lives only in data JSON + SEO pages).
// ────────────────────────────────────────────────────────────────────────────

type Slide = {
  id: number;
  eyebrow: string;
  headline: string;
  body: string;
  cta?: { label: string; href: string };
  visualSubject: string;
  visualStyle: string;
};

const SLIDES: Slide[] = [
  {
    id: 1,
    eyebrow: "Slide 1 · Vitamin D3",
    headline: "Vegan Vitamin D3",
    body:
      "Pine-sourced cholecalciferol at pharmaceutical-grade purity. First vegan D3 introduced to the Indian market. [Full content TBD.]",
    cta: { label: "Explore D3", href: "/products#nutraceuticals" },
    visualSubject: "Flagship slide — elevated design pending",
    visualStyle:
      "Cholecalciferol molecule · partner logos · FIRST IN INDIA badge. Concept to be picked from Concepts A / B / C.",
  },
  {
    id: 2,
    eyebrow: "Slide 2 · Vitamin K2-7",
    headline: "Natural Vitamin K2-7",
    body:
      "MenaquinGold menaquinone-7 from Denmark — cardiovascular and bone-health ingredient at clinical standard. [Full content TBD.]",
    cta: { label: "Explore K2-7", href: "/products#nutraceuticals" },
    visualSubject: "Flagship slide — mirror of Slide 1's concept",
    visualStyle:
      "Menaquinone-7 molecule · partner logo · Denmark origin callout. Same concept family as Slide 1.",
  },
  {
    id: 3,
    eyebrow: "Slide 3 · Products",
    headline: "Twelve therapeutic categories",
    body:
      "Antibiotics, cardiovascular, oncology, nutraceuticals — and eight more. APIs, intermediates, and specialty ingredients.",
    cta: { label: "Browse Products", href: "/products" },
    visualSubject: "12-category icon grid",
    visualStyle:
      "Our production CategoryIcons in a 4×3 layout, category name below each. Live art, not placeholder.",
  },
  {
    id: 4,
    eyebrow: "Slide 4 · Exhibitions 2026",
    headline: "Find us on the floor",
    body:
      "Seven exhibitions this year — from CPHI Middle East in Riyadh to CPHI India in Delhi. Book a meeting at our stand.",
    cta: { label: "Upcoming Events", href: "/presence#exhibitions" },
    visualSubject: "7 event cards, chronological",
    visualStyle:
      "Vertical stack of mini-cards: date (DM Mono gold), event (Playfair), venue (DM Sans). Shared data source with /presence.",
  },
  {
    id: 5,
    eyebrow: "Slide 5 · Global Presence",
    headline: "Sixty countries served",
    body:
      "From Mumbai to five continents. Exporting raw materials to clients in Europe, Africa, Middle East, Americas, and Asia.",
    cta: { label: "Global Presence", href: "/presence" },
    visualSubject: "World map with pulsing dots",
    visualStyle:
      "Simplified navy map, ~15 gold dots marking major export destinations; Mumbai dot larger. Gentle pulse loop.",
  },
  {
    id: 6,
    eyebrow: "Slide 6 · Trusted Supply",
    headline: "Six decades of supply",
    body:
      "Trusted by India's pharmaceutical industry since 1965. We source what you need — globally, reliably, transparently.",
    cta: { label: "About Us", href: "/about" },
    visualSubject: "Geometric brand motif",
    visualStyle:
      "Interlocking circles or a diagonal grid with a subtle JBK monogram. No chemistry imagery. Navy + gold.",
  },
  {
    id: 7,
    eyebrow: "Slide 7 · Services",
    headline: "End-to-end sourcing",
    body:
      "Supplier match. Documentation. Delivery. We coordinate pharmaceutical raw-material supply chains end-to-end.",
    cta: { label: "Our Services", href: "/services" },
    visualSubject: "Supply-chain flow",
    visualStyle:
      "Three gold circles connected by navy hairlines — MATCH → DOCUMENT → DELIVER. Minimal, horizontal.",
  },
];

// ────────────────────────────────────────────────────────────────────────────
// Shared slide content layout — two-column (text | visual) on desktop,
// stacked on mobile. `showVisual=false` removes the SVG for the docked
// mini-carousel where vertical space is constrained.
// ────────────────────────────────────────────────────────────────────────────

function SlideBody({
  slide,
  showVisual,
  compact,
}: {
  slide: Slide;
  showVisual: boolean;
  compact?: boolean;
}) {
  return (
    <div
      className={`grid gap-6 lg:gap-12 items-center w-full ${
        showVisual
          ? "grid-cols-1 lg:grid-cols-[1fr_auto]"
          : "grid-cols-1"
      }`}
    >
      <div className={compact ? "space-y-2" : "space-y-3 lg:space-y-5"}>
        <div
          className="uppercase"
          style={{
            fontFamily: "var(--font-mono)",
            letterSpacing: "0.18em",
            color: "#C9A84C",
            fontSize: compact ? "11px" : "13px",
          }}
        >
          {slide.eyebrow}
        </div>
        <h2
          className={
            compact
              ? "text-xl md:text-2xl lg:text-3xl"
              : "text-3xl md:text-5xl lg:text-[64px]"
          }
          style={{
            fontFamily: "var(--font-heading)",
            fontWeight: 700,
            color: "var(--color-foreground)",
            lineHeight: compact ? 1.2 : 1.08,
            letterSpacing: "-0.01em",
            margin: 0,
          }}
        >
          {slide.headline}
        </h2>
        {!compact && (
          <p
            className="text-base md:text-lg max-w-[560px]"
            style={{
              fontFamily: "var(--font-body)",
              color: "var(--color-foreground)",
              lineHeight: 1.65,
            }}
          >
            {slide.body}
          </p>
        )}
        {slide.cta && !compact && (
          <div>
            <Link
              to={slide.cta.href}
              className="inline-flex items-center gap-2 group transition-all duration-200 hover:scale-[1.03]"
              style={{
                fontFamily: "var(--font-body)",
                fontWeight: 500,
                fontSize: "15px",
                padding: "12px 28px",
                backgroundColor: "#C9A84C",
                color: "#0A1628",
                borderRadius: "4px",
                marginTop: "8px",
              }}
            >
              {slide.cta.label}
              <ArrowRight className="w-4 h-4 transition-transform duration-200 group-hover:translate-x-1" />
            </Link>
          </div>
        )}
      </div>
      {showVisual && (
        <div className="justify-self-center lg:justify-self-end w-full max-w-[520px]">
          <VisualPlaceholder
            slotLabel={`Slide ${slide.id} · Visual`}
            subject={slide.visualSubject}
            style={slide.visualStyle}
          />
        </div>
      )}
    </div>
  );
}

// ────────────────────────────────────────────────────────────────────────────
// Carousel controls — arrows + dots. Sized variants for full vs docked.
// ────────────────────────────────────────────────────────────────────────────

function Arrows({
  onPrev,
  onNext,
  compact,
}: {
  onPrev: () => void;
  onNext: () => void;
  compact?: boolean;
}) {
  const size = compact ? 32 : 44;
  const iconSize = compact ? 16 : 22;
  return (
    <>
      <button
        onClick={onPrev}
        aria-label="Previous slide"
        className="absolute left-2 md:left-6 top-1/2 -translate-y-1/2 rounded-full flex items-center justify-center transition-all duration-200 hover:scale-110"
        style={{
          width: size,
          height: size,
          backgroundColor: "rgba(201, 168, 76, 0.15)",
          border: "1px solid rgba(201, 168, 76, 0.4)",
          color: "#C9A84C",
        }}
      >
        <ChevronLeft size={iconSize} />
      </button>
      <button
        onClick={onNext}
        aria-label="Next slide"
        className="absolute right-2 md:right-6 top-1/2 -translate-y-1/2 rounded-full flex items-center justify-center transition-all duration-200 hover:scale-110"
        style={{
          width: size,
          height: size,
          backgroundColor: "rgba(201, 168, 76, 0.15)",
          border: "1px solid rgba(201, 168, 76, 0.4)",
          color: "#C9A84C",
        }}
      >
        <ChevronRight size={iconSize} />
      </button>
    </>
  );
}

function Dots({
  count,
  current,
  onSelect,
  compact,
}: {
  count: number;
  current: number;
  onSelect: (n: number) => void;
  compact?: boolean;
}) {
  return (
    <div
      className={`absolute left-1/2 -translate-x-1/2 flex gap-2 ${
        compact ? "bottom-2" : "bottom-6"
      }`}
      role="tablist"
      aria-label="Carousel slide selector"
    >
      {Array.from({ length: count }).map((_, i) => {
        const isActive = i === current;
        return (
          <button
            key={i}
            role="tab"
            aria-selected={isActive}
            aria-label={`Go to slide ${i + 1}`}
            onClick={() => onSelect(i)}
            className="transition-all duration-300 rounded-full"
            style={{
              width: isActive ? (compact ? 20 : 28) : compact ? 6 : 8,
              height: compact ? 6 : 8,
              backgroundColor: isActive
                ? "#C9A84C"
                : "rgba(201, 168, 76, 0.35)",
              border: "none",
              cursor: "pointer",
            }}
          />
        );
      })}
    </div>
  );
}

// ────────────────────────────────────────────────────────────────────────────
// Main export
// ────────────────────────────────────────────────────────────────────────────

interface HeroCarouselProps {
  /** Original hero JSX — shown at scroll 0, fades out as carousel fades in. */
  children: ReactNode;
}

export default function HeroCarousel({ children: originalHero }: HeroCarouselProps) {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [isBeyondHero, setIsBeyondHero] = useState(false);
  const prefersReducedMotion = useReducedMotion();
  const heroWrapperRef = useRef<HTMLDivElement>(null);

  const goPrev = useCallback(
    () => setCurrentSlide((s) => (s - 1 + SLIDES.length) % SLIDES.length),
    []
  );
  const goNext = useCallback(
    () => setCurrentSlide((s) => (s + 1) % SLIDES.length),
    []
  );

  // Autoplay — disabled for reduced-motion users and while paused.
  useEffect(() => {
    if (prefersReducedMotion || isPaused) return;
    const id = window.setInterval(() => {
      setCurrentSlide((s) => (s + 1) % SLIDES.length);
    }, AUTOPLAY_MS);
    return () => window.clearInterval(id);
  }, [prefersReducedMotion, isPaused]);

  // Keyboard navigation — ←/→ when not in a form field.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
      if (e.key === "ArrowLeft") goPrev();
      if (e.key === "ArrowRight") goNext();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [goPrev, goNext]);

  // Scroll-driven transforms.
  const { scrollYProgress } = useScroll({
    target: heroWrapperRef,
    offset: ["start start", "end start"],
  });

  // Progress boundaries (0 → 1 across the 220vh sticky region):
  //   0.00 → 0.12  hero fades out
  //   0.12 → 0.24  carousel fades in
  //   0.24 → 0.55  carousel steady full-screen
  //   0.55 → 0.88  carousel scales down & translates up toward the top 1/3
  //   0.88 → 1.00  docked form, steady
  const heroOpacity = useTransform(scrollYProgress, [0, 0.12], [1, 0]);
  const carouselOpacity = useTransform(scrollYProgress, [0.12, 0.24], [0, 1]);
  const carouselScale = useTransform(scrollYProgress, [0.55, 0.88], [1, 0.55]);
  const visualOpacity = useTransform(scrollYProgress, [0.55, 0.8], [1, 0]);

  // Track scroll past the sticky region — controls the fixed docked carousel.
  useEffect(() => {
    const onScroll = () => {
      if (!heroWrapperRef.current) return;
      const rect = heroWrapperRef.current.getBoundingClientRect();
      // When the wrapper's bottom edge has scrolled above the nav bar,
      // we're past the sticky region — show the fixed docked version.
      setIsBeyondHero(rect.bottom <= NAV_TOP_PX + 1);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const currentSlideData = SLIDES[currentSlide];

  return (
    <>
      {/* ==========================================================
           Sticky scroll region — 220vh tall. Contains a sticky inner
           container that pins to the viewport (below the nav) and
           morphs hero → carousel → shrunk-preview via scroll progress.
         ========================================================== */}
      <div
        ref={heroWrapperRef}
        style={{ height: "220vh", position: "relative" }}
        aria-label="Homepage hero carousel region"
      >
        <div
          className="overflow-hidden"
          style={{
            position: "sticky",
            top: `${NAV_TOP_PX}px`,
            height: `calc(100vh - ${NAV_TOP_PX}px)`,
            width: "100%",
          }}
          onMouseEnter={() => setIsPaused(true)}
          onMouseLeave={() => setIsPaused(false)}
        >
          {/* Layer 1 — original hero. Fades out first. */}
          <motion.div
            style={{
              opacity: heroOpacity,
              position: "absolute",
              inset: 0,
            }}
          >
            {originalHero}
          </motion.div>

          {/* Layer 2 — morphing carousel. Fades in, then scales down. */}
          <motion.div
            style={{
              opacity: carouselOpacity,
              scale: carouselScale,
              position: "absolute",
              inset: 0,
              transformOrigin: "50% 0%",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              padding: "2rem 1.5rem",
            }}
            aria-roledescription="carousel"
            aria-label="Company highlights"
          >
            <div className="w-full max-w-6xl mx-auto relative">
              <AnimatePresence mode="wait">
                <motion.div
                  key={`full-${currentSlide}`}
                  initial={prefersReducedMotion ? false : { opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={prefersReducedMotion ? undefined : { opacity: 0, y: -16 }}
                  transition={{
                    duration: prefersReducedMotion ? 0 : 0.5,
                    ease: [0.16, 1, 0.3, 1],
                  }}
                >
                  <motion.div style={{ opacity: visualOpacity }}>
                    <SlideBody slide={currentSlideData} showVisual={true} />
                  </motion.div>
                </motion.div>
              </AnimatePresence>

              <Arrows onPrev={goPrev} onNext={goNext} />
              <Dots
                count={SLIDES.length}
                current={currentSlide}
                onSelect={setCurrentSlide}
              />
            </div>
          </motion.div>
        </div>
      </div>

      {/* ==========================================================
           Fixed docked mini-carousel — appears only when the user has
           scrolled past the sticky region. Overlays the top 33vh of
           the viewport; page content scrolls beneath it.
         ========================================================== */}
      <AnimatePresence>
        {isBeyondHero && (
          <motion.aside
            key="docked-carousel"
            initial={prefersReducedMotion ? false : { opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={prefersReducedMotion ? undefined : { opacity: 0, y: -12 }}
            transition={{ duration: prefersReducedMotion ? 0 : 0.3 }}
            style={{
              position: "fixed",
              top: `${NAV_TOP_PX}px`,
              left: 0,
              right: 0,
              height: `${DOCKED_HEIGHT_VH}vh`,
              zIndex: 30,
              backgroundColor: "var(--color-background)",
              borderBottom: "1px solid rgba(201, 168, 76, 0.25)",
              boxShadow: "0 4px 20px rgba(10, 22, 40, 0.06)",
            }}
            onMouseEnter={() => setIsPaused(true)}
            onMouseLeave={() => setIsPaused(false)}
            aria-roledescription="carousel"
            aria-label="Company highlights — compact"
          >
            <div
              className="relative w-full h-full flex items-center justify-center"
              style={{ padding: "1rem 3.5rem" }}
            >
              <div className="w-full max-w-5xl">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={`dock-${currentSlide}`}
                    initial={prefersReducedMotion ? false : { opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={prefersReducedMotion ? undefined : { opacity: 0, y: -8 }}
                    transition={{ duration: prefersReducedMotion ? 0 : 0.35 }}
                  >
                    <SlideBody slide={currentSlideData} showVisual={false} compact />
                  </motion.div>
                </AnimatePresence>
              </div>

              <Arrows onPrev={goPrev} onNext={goNext} compact />
              <Dots
                count={SLIDES.length}
                current={currentSlide}
                onSelect={setCurrentSlide}
                compact
              />
            </div>
          </motion.aside>
        )}
      </AnimatePresence>
    </>
  );
}
