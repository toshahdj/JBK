import { createBrowserRouter } from "react-router";
import Root from "./Root";
import Home from "./pages/Home";
import About from "./pages/About";
import Quality from "./pages/Quality";
import Products from "./pages/Products";
import ProductsIndex from "./pages/ProductsIndex";
import Services from "./pages/Services";
import Presence from "./pages/Presence";
import Contact from "./pages/Contact";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Root,
    children: [
      { index: true, Component: Home },
      { path: "about", Component: About },
      { path: "quality", Component: Quality },
      { path: "products", Component: Products },
      { path: "products-index", Component: ProductsIndex },
      { path: "services", Component: Services },
      { path: "presence", Component: Presence },
      { path: "contact", Component: Contact },
    ],
  },
]);
