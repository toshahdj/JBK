import { Outlet, useLocation } from "react-router";
import { useEffect, useState } from "react";
import Navigation from "./components/Navigation";
import Footer from "./components/Footer";
import FloatingButtons from "./components/FloatingButtons";

export default function Root() {
  const [darkMode, setDarkMode] = useState(false);
  const [pageTransition, setPageTransition] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const savedTheme = localStorage.getItem("jbk-theme");
    if (savedTheme === "dark") {
      setDarkMode(true);
      document.documentElement.classList.add("dark");
    }
  }, []);

  useEffect(() => {
    setPageTransition(true);
    window.scrollTo({ top: 0, behavior: "instant" });

    const timer = setTimeout(() => {
      setPageTransition(false);
    }, 100);

    return () => clearTimeout(timer);
  }, [location.pathname]);

  const toggleTheme = () => {
    setDarkMode(!darkMode);
    if (!darkMode) {
      document.documentElement.classList.add("dark");
      localStorage.setItem("jbk-theme", "dark");
    } else {
      document.documentElement.classList.remove("dark");
      localStorage.setItem("jbk-theme", "light");
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation darkMode={darkMode} toggleTheme={toggleTheme} />
      <main
        className="flex-1 transition-opacity duration-300"
        style={{ opacity: pageTransition ? 0 : 1 }}
      >
        <Outlet />
      </main>
      <Footer />
      <FloatingButtons darkMode={darkMode} />
    </div>
  );
}
