import type { FC } from "react";
import {
  AntibioticIcon,
  AntiInfectiveIcon,
  CardiovascularIcon,
  AntidiabeticIcon,
  OncologyIcon,
  RespiratoryIcon,
  CnsIcon,
  HormonesIcon,
  AntifungalIcon,
  SexualWellnessIcon,
  VitaminsIcon,
  PlantExtractsIcon,
} from "../components/icons/CategoryIcons";

/**
 * Therapeutic category catalog.
 *
 * Single source of truth for:
 *   - Home page 4×3 (+1) grid
 *   - Carousel Slide 6 "Products" (wired in C4 — same 12 cards, no CTA)
 *
 * `id` is kebab-case because Products.tsx (C5) reads `window.location.hash`
 * on mount. A click on `/products#antibiotics` will prefill the product
 * search with a sensible term mapped from the id. Nothing in the Home
 * grid depends on that mapping — cards navigate, Products.tsx interprets.
 *
 * No count fields here. products.json has no therapeutic-class tagging yet;
 * inferring counts from product names would be misleading. DM Mono slot
 * left out of the card layout entirely — cards should look intentional
 * without it, not like something's missing.
 */

export interface Category {
  id: string;
  name: string;
  href: string;
  Icon: FC<{ className?: string }>;
}

export const categories: readonly Category[] = [
  { id: "antibiotics",      name: "Antibiotics",                 href: "/products#antibiotics",      Icon: AntibioticIcon },
  { id: "anti-infectives",  name: "Anti-Infectives",             href: "/products#anti-infectives",  Icon: AntiInfectiveIcon },
  { id: "cardiovascular",   name: "Cardiovascular & Metabolic",  href: "/products#cardiovascular",   Icon: CardiovascularIcon },
  { id: "antidiabetics",    name: "Antidiabetics",               href: "/products#antidiabetics",    Icon: AntidiabeticIcon },
  { id: "oncology",         name: "Oncology",                    href: "/products#oncology",         Icon: OncologyIcon },
  { id: "respiratory",      name: "Respiratory",                 href: "/products#respiratory",      Icon: RespiratoryIcon },
  { id: "cns",              name: "Central Nervous System",     href: "/products#cns",              Icon: CnsIcon },
  { id: "hormones",         name: "Hormones & Steroids",         href: "/products#hormones",         Icon: HormonesIcon },
  { id: "antifungals",      name: "Antifungals",                 href: "/products#antifungals",      Icon: AntifungalIcon },
  { id: "sexual-wellness",  name: "Sexual Wellness",             href: "/products#sexual-wellness",  Icon: SexualWellnessIcon },
  { id: "vitamins",         name: "Vitamins & Nutraceuticals",   href: "/products#vitamins",         Icon: VitaminsIcon },
  { id: "plant-extracts",   name: "Plant Extracts",              href: "/products#plant-extracts",   Icon: PlantExtractsIcon },
] as const;
