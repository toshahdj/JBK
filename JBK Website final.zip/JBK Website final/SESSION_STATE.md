# SESSION_STATE.md

Continuation document for the JBK Pharma (J. B. Khokhani & Co.) website migration. Last-known state at end-of-session, Friday April 24, 2026 ~00:30 IST. Written to hand off to a new thread without losing context.

---

## 1 · Project at a glance

**Company:** J. B. Khokhani & Co. — Indian pharmaceutical raw-material distributor, est. 1965.
**Migrating from:** https://team-ratio-72420426.figma.site
**Migrating to:** https://www.jbkhokhani.com
**Stack:** React + Vite + TypeScript + Tailwind v4, multi-page routing via `createBrowserRouter`.
**Working tree:** this repo root (`/home/claude/phase1/`).
**Original upload:** `/mnt/user-data/uploads/JBK_Website.zip` (unmodified on host).

## 2 · Hard constraints (non-negotiable, reconfirmed multiple times)

- Manufacturer names **never** appear on the frontend. Only permitted inside hidden SEO lists / JSON-LD.
- `src/app/data/products.json` (219 entries: `name`, `manufacturer`, `category`) is **not to be mutated**. Read-only source.
- Supabase config — `projectId: mwwuycuzmiuyytrtbvru`, edge function `make-server-c285fd22/send-email` — is **not to be changed**.
- URL structure preserved.
- `prefers-reduced-motion` respected throughout.

## 3 · Source of truth

- Original migration prompt (long) + the previous live site + direct user feedback **in this thread**.
- Reference docs already in `src/imports/pasted_text/`: `homepage-redesign.md`, `page-updates.md`, `jb-khokhani-website-spec.md`.
- The earlier "31-item change log" is **deprecated** — do not use.

---

## 4 · Chunk status

### C1 — Gate sketches · ✅ COMPLETE
Produced variant exploration (line-art / filled-flat / duotone) on Antibiotics capsule; 3 SRLC layout sketches; cert-upload wait-state. User picked:
- **Variant B** (filled flat two-tone) with **1.2 px divider stroke**, **-30° capsule rotation**, `#F0F4FF` near-white for the dark-mode primary half.
- **SRLC Layout 1** (editorial magazine — photo left, narrative right, small Love & Care card inline).

### C2 — Hygiene pass · ✅ COMPLETE (user: "C2 approved — all items clean")
Files touched:
- `src/imports/Pujya-Gurudevshri-1.jpg` — compressed 11.09 MB → **103 KB** at 916×1100 q=85 progressive (via PIL).
- `src/app/pages/Presence.tsx` lines 424–438 — CPHI iframe got `loading="lazy"`, `referrerPolicy="strict-origin-when-cross-origin"`, expanded `title`, `cphi-iframe` class.
- `src/styles/theme.css` — appended `.dark .cphi-iframe { box-shadow: 0 0 0 1px rgba(201,168,76,0.35), 0 8px 24px rgba(0,0,0,0.35) !important; }` (gold hairline in dark mode).
- `src/app/components/Footer.tsx` — full rewrite 87 → ~170 lines. 3-col layout (Company / Products / Contact). Products links use hash fragments `/products#apis`, `/products#nutraceuticals`, `/products#veterinary`. Contact column has email + phone + WhatsApp icon + number (no literal "WhatsApp:" label) + Mumbai location. Tablet 2-col, mobile stacked.
- `src/app/components/FloatingButtons.tsx` line 151 — tooltip "Chat with us on WhatsApp" → **"Chat with us!"**.
- `src/app/pages/About.tsx` — href already correct (`https://www.srmd.org`), no change.
- `src/app/pages/Contact.tsx` — audited, no WhatsApp content present.
- `src/app/pages/Products.tsx` — audited, inquiry form present at lines 649–712, Supabase-wired (`formType: "product"`), untouched.

DNA-helix sanity check for Variant B done at 48/96 px in both modes; user approved. **DNA design is locked** (see `staged-assets/icon-preview-iterations/01-dna-helix-sanity-check.html`).

### C3 — Categories data + Home grid + icons · 🟡 IN PROGRESS
**Awaiting user approval of round-3 icon preview before applying to `CategoryIcons.tsx`.**

Files shipped to repo:
- `src/app/data/categories.ts` — **NEW**. 12 entries: `{ id, name, href, Icon }`. kebab-case ids, `/products#{id}` hrefs. CNS `name` = **"Central Nervous System"** (spelled out, not "CNS").
- `src/app/components/icons/CategoryIcons.tsx` — **NEW** (~190 lines). Currently contains **round-1 icon designs**. Round-3 designs are in `staged-assets/icon-preview-iterations/03-all-13-icons-preview-round-3.html` waiting to be copy-pasted in after approval.
- `src/app/pages/Home.tsx` — **EDITED**. Added imports (`categories`, `BrowseAllIcon`, `productsData`), added `const TOTAL_PRODUCT_COUNT = productsData.length;`, removed the 6 inline icon components + inline 6-entry categories array, replaced old 6-card grid + separate "View Full Product List" button with new **4×3+CTA grid**. Classes: `grid-cols-2 md:grid-cols-3 lg:grid-cols-4`; CTA spans all columns at every breakpoint (`col-span-2 md:col-span-3 lg:col-span-4`). CTA heading: `Browse all {TOTAL_PRODUCT_COUNT} products`. Net: 1033 → 1004 lines. Syntactically clean.

**Icon revision rounds:**
- **Round 1** (original): capsule + shield-plus + heart+ECG + kidney-Rx + ribbon v1 + lungs v1 + brain v1 + DNA + leaf+ring + shield-heart + sun-pill + sprig + CTA.
- **Round 2** (preview shipped): Oncology / Respiratory / Sexual Wellness flagged as likely-to-fail.
- **Round 3** (preview shipped, in `staged-assets/icon-preview-iterations/03-…round-3.html` — user must approve before anything lands in `CategoryIcons.tsx`):
  - **Oncology** → proper awareness ribbon with loop hole + gold crossover knot + V-notched tails.
  - **Respiratory** → two-line trachea + Y-bronchi split + bronchial branches rendered inside each lung as card-bg negative space.
  - **CNS** → bumpier hemisphere outlines with multiple gyri + gold sulci inside each half.
  - **Antifungal** → swapped from leaf+ring to **shield + microbe cell** per user's ref 4. Shows **Option A (shield+microbe as requested)** and **Option B (fungal cell in gold prohibit ring)** side by side at bottom of preview. Flagged concern: Option A duplicates the shield from Anti-Infectives. User must pick.
  - **Sexual Wellness** → Venus+Mars interlocking, tighter overlap (circles r=7.5, centers at (20,28) and (28,20)).
  - **Vitamins & Nutraceuticals** → pill scaled **1.75×** (16×8 → 28×14 at rect x=10 y=17); rays repositioned to clear the larger pill (all 8 rays preserved: 4 axial + 4 diagonal).
  - **Plant Extracts** → swapped from sprig to **filled mortar + pestle** at 45° with bulb head + 2 gold leaves emerging from bowl top.
- **Kept unchanged from round 1/2** (user said "perfect"): Antibiotics, Anti-Infectives, Cardiovascular & Metabolic, Antidiabetics, Hormones & Steroids (DNA).

### C4 onward — NOT STARTED

---

## 5 · Locked decisions (do not re-open)

### Icon system (C1 + C3)
- **Variant:** B (filled flat two-tone).
- **Primary color:** `var(--color-foreground)` — i.e. `#0A1628` in light, `#F0F4FF` in dark.
- **Accent color:** `#C9A84C` (gold) — hard-coded in icon SVGs so both modes use the same gold.
- **Divider stroke:** 1.2 px, color `var(--color-card)` (white in light / `#162236` in dark).
- **Capsule rotation:** -30°.
- **Stroke-based icons (DNA helix, Sexual Wellness ♀/♂):** 3 px stroke is the accepted concession for naturally-linear shapes. This is a deliberate break from Variant B's pure filled style.

### Home grid (C3)
- **12 therapeutic categories** in this fixed order: Antibiotics · Anti-Infectives · Cardiovascular & Metabolic · Antidiabetics · Oncology · Respiratory · Central Nervous System · Hormones & Steroids · Antifungals · Sexual Wellness · Vitamins & Nutraceuticals · Plant Extracts.
- **CNS is spelled out as "Central Nervous System"** (not "CNS" acronym) — user decision.
- **Grid:** 4×3(+1) desktop, 3-col tablet, 2-col mobile. CTA banner spans **all columns at every breakpoint** (not a 13th card).
- **Card content:** icon top + DM Sans 500 category name. **No product counts, no DM Mono slot** — `products.json` lacks therapeutic tags so per-category counts aren't reliable.
- **CTA banner heading:** `Browse all {N} products` where `{N}` is computed from `productsData.length` (not hardcoded).
- **CTA banner subtitle:** `APIs · Nutraceuticals · Veterinary`.

### About · SRLC (C8)
- **Layout 1** (editorial magazine). Photo left column (→ `https://www.srmd.org`), narrative + pull quote + small Love & Care card right column. Small card → `https://loveandcare.srmd.org/`.
- 4 SRLC stat chips below: 3M+ / 10M+ / UN ECOSOC / 13× marathon.

### Quality · certificates (C7)
- Section heading: **"Download Our Certificates"**.
- Subtext: **"Verified documentation available for your compliance and due diligence requirements."**
- Grid: **3 top / 2 centered bottom desktop** (user picked option A), 2×3 tablet, 1-col mobile.
- **5 cards** after FSSAI merge: Drug License, GST Registration, Export House Certificate, ISO Certificate, FSSAI License.
- **No 6th "Additional Documents" card.**
- Card visual: gold SVG cert icon + Playfair name + DM Sans one-line + navy button with gold text triggering download.

### Footer (C2)
- 3 columns (Company / Products / Contact). **No Trust column.**
- No literal "WhatsApp:" label.

### FAB tooltip (C2)
- "Chat with us!" (not "Chat with us on WhatsApp").

### Nutraceutical feature cards (C-Nutra)
- Exactly 3 cards on Products page, Nutraceuticals tab: D3 (Vegan Cholecalciferol), K2-7 (Menaquinone-7), Caffeine (Food Grade).
- Each has terracotta "Request Sample" CTA → `/contact` with pre-filled message textarea.
- Hover: lift + gold border glow.
- **"Request Sample" appears nowhere else on the site.**

### Exhibitions list (C-Presence + C-Carousel S9)
Ascending by date:
1. **CPHI ME** — May 11–13 2026, Riyadh
2. **CPHI SEA** — Jul 8–10, Bangkok QSNCC
3. **Fi India** — Aug 26–28, Mumbai BEC
4. **iPHEX** — Sep 7–9, New Delhi Bharat Mandapam
5. **CPHI Worldwide** — Oct 6–8, Milan Fiera Milano
6. **CPHI India** — Nov 23–25, Delhi IICC Yashobhoomi
7. **CPHI ME Dec** — Dec 14–16, Riyadh

Card styling: date DM Mono gold · event Playfair · venue+city DM Sans. Light: navy bg. Dark: lighter-navy with gold hairline.

### Products page pagination (C-Products)
- Pagination **on "All" tab only**, 30/page, centered `< 1 2 3 4 … >`.
- A-Z letter-clicks navigate across pages.
- Tab switch resets to page 1.
- APIs / Veterinary / Nutraceuticals tabs fit without pagination.
- Hash-preselect from URL (`/products#apis` etc.).
- Inquiry form already present at bottom, already Supabase-wired — keep untouched.

### Design tokens (verified from `src/styles/theme.css`)
- **Light:** bg `#F4F1EC` / fg `#0A1628` / card `#FFFFFF` / section-bg `#EAE6DD` / nav `#0A1628`.
- **Dark:** bg `#0A1628` / fg `#F0F4FF` / card `#162236` / section-bg `#111E33` / nav `#060F1E`.
- **Accents:** gold `#C9A84C`, sage `#6B8F71`, terracotta `#C4714A`.
- **Fonts:** Playfair Display / DM Sans / DM Mono.
- CSS var convention: `--color-card`, `--color-background`, `--color-foreground` with `--card` → `--color-card` aliasing inside the `@theme` block.

---

## 6 · In-flight / pending application to repo

- **Round-3 icon SVG bodies** are in `staged-assets/icon-preview-iterations/03-all-13-icons-preview-round-3.html` inside the JS `icons` object. After user approval + Antifungal option pick (A vs B), copy the 7 changed SVG bodies into `src/app/components/icons/CategoryIcons.tsx` replacing the round-1 designs. File structure unchanged (13 named exports, same props signature, same wrapper pattern).
- **Home.tsx grid is already wired to `categories.ts` and `CategoryIcons.tsx`** — no further edits needed on Home.tsx for C3 once icons land.

---

## 7 · Handoff-message items needing re-confirmation

The user's handoff message referenced "carousel approach Option 1 with neutral placeholders" as a locked decision. **This decision is not in the current session transcript.** Either it was decided in an earlier session I don't have access to, or the user is conflating. The next thread should:
1. Check the prior transcripts journal at `/mnt/transcripts/journal.txt` for the earlier session.
2. If not found, explicitly re-confirm with the user before building C4.

---

## 8 · Open items (next thread picks up here)

Priority order per user's handoff:

### First up: finish C3
- [ ] User approves round-3 icon preview + picks Antifungal Option A or B.
- [ ] Apply the 7 changed SVG bodies into `src/app/components/icons/CategoryIcons.tsx`.
- [ ] Verify at 48 px on Home grid in both light and dark modes.

### C4 — Carousel (Home page only)
- Retire `HeroCarousel.tsx`. Build new `CarouselSection.tsx` + `src/app/components/slides/` subdir.
- 9 slides per spec: S1 Vitamin D3 · S2 Vitamin K27 · S3 Homepage (geometric brand motif, not chemistry) · S4 About (geometric three-generations motif, no silhouettes) · S5 Quality · S6 Products (12 categories, no CTA 13th) · S7 Services · S8 Presence (world map + pulsing gold dots) · S9 Exhibitions (7 events from the locked list above).
- Per-slide "Big" (enter transition, only on re-advance) + "Small" (internal choreography) animations.
- Hero → S1 is scroll-triggered. S1's Big animation doesn't run first time; S1's Small waits for hero exit complete.
- 6 s autoplay, 700 ms ease, morphing dots, progress bar, hover-fade arrows, swipe/keyboard/reduced-motion support.
- **No persistent dock** — carousel is Home-only.
- Slide 6 pulls its 12 categories from the shared `src/app/data/categories.ts` (no CTA 13th).
- User's handoff splits this into **C4 infra + C4b visuals** — build the carousel shell and transitions first, then per-slide visuals second.

### C5 — Nutraceuticals cards (user's priority numbering)
- 3 feature cards on Products page Nutraceuticals tab: D3 / K2-7 / Caffeine.
- Each: product image, 4 bullets (verbatim from spec, preserved in earlier transcript), terracotta "Request Sample" CTA → `/contact`, hover lift + gold border glow.
- Pre-fill `/contact` form message textarea on sample request.

### C6 — Products page pagination (user's priority numbering)
- Port Phase-3 logic: tabs (All | APIs | Veterinary | Nutraceuticals merging Export+Domestic), sticky filter bar, A-Z rail with disabled letters, debounced search 300 ms, letter-grouped grid, empty state, hidden SEO list with JSON-LD.
- Pagination rules per locked decision above.
- Inquiry form already in place, don't touch.

### C7 — Quality certificates (user's priority numbering)
- **5 PDFs total**, all source files staged in `staged-assets/pending-certificates/`:
  - `drug-license.pdf` — **merge pending**: `Form 20 B.pdf` + `Form 21 B.pdf` (use `pypdf`).
  - `gst-registration.pdf` — **ready** (copy from staged).
  - `export-house-certificate.pdf` — **ready** (copy from staged).
  - `iso-certificate.pdf` — **ready** (copy from staged).
  - `fssai-licenses.pdf` — **merge pending**: `FSSI_JBK_CENTRAL.pdf` (275 KB) + `FSSI_JBK_STATE.pdf` (182 KB). One card labeled "FSSAI License" — do not surface Central/State separately.
- Final destination: `public/certificates/` inside the repo.
- Build "Download Our Certificates" section per locked layout (3+2-centered desktop / 2×3 tablet / 1-col mobile).

### Remaining chunks (from earlier plan, lower priority)
- **C8 SRLC on About** — Layout 1 editorial magazine, small Love & Care card inline.
- **C9 Exhibitions on Presence** — 7-card calendar per locked list, ascending.
- **C10 Final pass** — `tsc --noEmit`, dark/light walkthrough every page, zip with `CHANGES.md` at root. Build: `npm install && npm run build`. If zip fails, present files individually.

---

## 9 · Staged-assets inventory (shipped with this zip)

### `staged-assets/pending-certificates/`
Seven source PDFs. Two pairs still need merging inside C7.

| File | Size | Purpose |
|---|---|---|
| `Form 20 B.pdf` | 270 KB | merges with Form 21 B → `public/certificates/drug-license.pdf` |
| `Form 21 B.pdf` | 266 KB | merges with Form 20 B → `public/certificates/drug-license.pdf` |
| `FSSI_JBK_CENTRAL.pdf` | 275 KB | merges with State → `public/certificates/fssai-licenses.pdf` |
| `FSSI_JBK_STATE.pdf` | 182 KB | merges with Central → `public/certificates/fssai-licenses.pdf` |
| `gst-registration.pdf` | 472 KB | copy as-is → `public/certificates/gst-registration.pdf` |
| `export-house-certificate.pdf` | 60 KB | copy as-is → `public/certificates/export-house-certificate.pdf` |
| `iso-certificate.pdf` | 584 KB | copy as-is → `public/certificates/iso-certificate.pdf` |

### `staged-assets/icon-preview-iterations/`
Three HTML preview files recording the design iterations. Open in a browser to inspect.

| File | Purpose |
|---|---|
| `01-dna-helix-sanity-check.html` | Locked DNA design at 48/96 px in both modes. Reference for Variant B stroke-based exception. |
| `02-icon-revisions-round-2.html` | Round-2 preview of Oncology / Respiratory / Sexual Wellness etc. (historical reference). |
| `03-all-13-icons-preview-round-3.html` | **CURRENT — awaiting approval.** Full 4×3+CTA grid in both modes + 96 px detail strip of 7 changed icons + Antifungal A/B comparison. SVG bodies in the JS `icons` object are the exact ones to paste into `CategoryIcons.tsx` after approval. |

---

## 10 · Path conventions

- Working tree root: `/home/claude/phase1/`
- Prior-conversation transcripts: `/mnt/transcripts/` (accessible via `view` and `bash_tool`)
- Skills: `/mnt/skills/public/*` (read-only)
- User-provided inputs: `/mnt/user-data/uploads/` (read-only)
- Handoff outputs (zips, previews): `/mnt/user-data/outputs/`

## 11 · Tool-use notes

- `visualize:show_widget` **times out frequently** on this project (long SVG payloads). Workaround: write standalone HTML to `/mnt/user-data/outputs/` and call `present_files`. All three icon previews use this pattern.
- `node_modules` is **absent** from the repo — team runs `npm install` before `npm run build`.
- Image compression for Pujya portrait used PIL with `optimize=True, progressive=True, quality=85`.

---

*End of SESSION_STATE.md. Continue from §8, "Open items", first sub-bullet.*
